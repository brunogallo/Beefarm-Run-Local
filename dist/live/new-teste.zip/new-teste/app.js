(function() {
    var e = {
        3266: function(e, a, t) {
            "use strict";
            t.r(a);
            var i = t(8081)
              , o = t.n(i)
              , n = t(3645)
              , s = t.n(n)
              , r = t(9632)
              , l = s()(o());
            l.i(r.Z),
            l.push([e.id, "*{margin:0;padding:0;-webkit-touch-callout:none;-webkit-user-select:none;-moz-user-select:none;user-select:none;a,button,img,input,textarea{-webkit-tap-highlight-color:rgba(255,255,255,0)}}#app{width:100%;height:100%;box-sizing:border-box;font-family:mini;color:#fff;font-weight:700;text-align:center;overflow:hidden}.logo{width:240px;position:absolute;top:10px;left:180px}.logo_mobile{width:120px;position:absolute;top:30px;left:20px}.btnBg{color:#fff;line-height:60px;word-spacing:5px;background:url(https://farm-res.s3.ap-southeast-1.amazonaws.com/web/assets/btn_bg.png);background-size:100% 100%;background-repeat:no-repeat;cursor:pointer}.btnBg:hover{transform:scale(1.1);background:url(https://farm-res.s3.ap-southeast-1.amazonaws.com/web/assets/btnPass_bg.png);background-size:100% 100%;background-repeat:no-repeat}.btnChooseBg{background:url(https://farm-res.s3.ap-southeast-1.amazonaws.com/web/assets/btnCheck_bg.png);background-size:100% 100%;background-repeat:no-repeat;cursor:pointer}.whiteBg{border:2px solid #fff;box-shadow:0 0 8px 0 rgba(0,0,0,.5);border-radius:10px}.mask{background:rgba(0,0,0,.7);position:fixed;top:0;right:0;bottom:0;left:0;z-index:99999}.laoding{margin-top:15%}.laoding_mobile{margin-top:40%}.w20margin{width:20%;margin:auto}.w25margin{width:25%;margin:auto}.w30{width:30%}.w30margin{width:30%;margin:auto}.w35{width:35%}.w35margin{width:35%;margin:auto}.w40margin{width:40%;margin:auto}.w50margin{width:50%;margin:auto}.w55margin{width:55%;margin:auto}.w60margin{width:60%;margin:auto}.w65{width:65%}.w65margin{width:65%;margin:auto}.w70{width:70%}.w70margin{width:70%;margin:auto}.w75{width:75%}.w75margin{width:75%;margin:auto}.w80{width:80%}.w80margin{width:80%;margin:auto}.w82{width:82%}.w83{width:83%}.w85{width:85%}.w85margin{width:85%;margin:auto}.w94margin{width:94%;margin:auto}.w100{width:100%}.fl{display:flex}.flbetween,.flitem{display:flex;align-items:center}.flbetween,.flbetween_item{justify-content:space-between}.flbetween_item{display:flex}.flcenter{align-items:center}.flcenter,.flcenter_item{display:flex;justify-content:center}.flaround{align-items:center}.flaround,.flaround_item{display:flex;justify-content:space-around}.flleft{justify-content:left}.flleft,.flright{display:flex;align-items:center}.flright{justify-content:right}.flevenly{display:flex;justify-content:space-evenly;align-items:center}.flwarp_around{justify-content:space-around}.flwarp_around,.flwarpcenter{display:flex;flex-wrap:wrap;align-items:center}.flwarpcenter{justify-content:center}.flwarpcenter_item{display:flex;justify-content:center;flex-wrap:wrap}.flwarpbetween{display:flex;flex-wrap:wrap;justify-content:space-between;align-items:center}.margintop_10{margin-top:10px}.margintop_20{margin-top:20px}.margintop_30{margin-top:30px}.margintop_40{margin-top:40px}.marginTB10{margin:10px 0}.marginTB15{margin:15px 0}.marginTB20{margin:20px 0}.margin_20{margin:20px auto}.margin_30{margin:30px auto}.margin_60{margin:60px auto}.marginTB30{margin:30px 0}.padding_10{padding:10px}.padding_20{padding:20px}.paddingLR10{padding:0 10px}.paddingLR20{padding:0 20px}.fontWeight_normal{font-weight:400}.white_box{background-color:#fff;border-radius:16px;padding:20px}.text-cut{text-overflow:ellipsis;white-space:nowrap;overflow:hidden}.text-cut2{-webkit-line-clamp:2}.text-cut2,.text-cut3{overflow:hidden;display:-webkit-box;-webkit-box-orient:vertical;word-break:break-all;text-overflow:ellipsis}.text-cut3{-webkit-line-clamp:3}.text-cut5{-webkit-line-clamp:5}.text-cut5,.text-cut7{overflow:hidden;display:-webkit-box;-webkit-box-orient:vertical;word-break:break-all;text-overflow:ellipsis}.text-cut7{-webkit-line-clamp:7}.text-cut8{display:-webkit-box;-webkit-box-orient:vertical;-webkit-line-clamp:8}.text-cut8,.text-cutNULL{overflow:hidden;word-break:break-all;text-overflow:ellipsis}.textCenter{text-align:center}.textLeft{text-align:left}", ""]),
            a["default"] = l
        },
        9632: function(e, a, t) {
            "use strict";
            var i = t(8081)
              , o = t.n(i)
              , n = t(3645)
              , s = t.n(n)
              , r = s()(o());
            r.push([e.id, 'body,html{width:100%;overflow-x:hidden;font:.83333vw arial}blockquote,body,button,dd,div,dl,dt,fieldset,h1,h2,h3,h4,h5,h6,hr,input,lengend,li,ol,p,pre,td,textarea,th,ul{margin:0;padding:0;font-size:100%;font:inherit;vertical-align:baseline}a:focus{outline:none}body,button,input,select,textarea{font:12px/1 Microsoft YaHei,Tahoma,Helvetica,Arial,"\\5b8b\\4f53",sans-serif}a,body{color:#666}h1{font-size:18px}h2{font-size:16px}h3{font-size:14px}h4,h5,h6{font-size:100%}h1,h2,h3,h4,h5,h6{font-weight:400}address,b,cite,dfn,em,i,var{font-style:normal}code,kbd,pre,samp,tt{font-family:Courier New,Courier,monospace}small{font-size:12px}ol,ul{list-style:none}option,select{-webkit-user-select:none;-moz-user-select:none;-o-user-select:none;user-select:none}[contenteditable=true],input,textarea{-webkit-user-select:auto!important;-moz-user-select:auto!important;-o-user-select:auto!important;user-select:auto!important}a,s{text-decoration:none;outline:none;blur:expression(this.onFocus=this.blur());-webkit-tap-highlight-color:rgba(0,0,0,0);-webkit-tap-highlight-color:transparent}abbr[title],acronym[title]{border-bottom:1px dotted;cursor:help}q:after,q:before{content:""}legend{color:#000}fieldset,img{border:none}button,input,select,textarea{font-size:100%}table{border-collapse:collapse;border-spacing:0}table td,table th{border:1px solid #ddd}hr{border:none;height:1px}button,button:focus,input,input:focus,textarea,textarea:focus{outline:none;border:none}html{overflow-y:scroll}li{+vertical-align:top;_vertical-align:top}li *{*zoom:1}*{box-sizing:border-box;-webkit-box-sizing:border-box}img{vertical-align:middle;*vertical-align:top}input{vertical-align:middle}input[type=number]{-moz-appearance:textfield}input[type=number]::-webkit-inner-spin-button,input[type=number]::-webkit-outer-spin-button{-webkit-appearance:none;margin:0}.fl,.fl-a,.fl-li li{float:left;_display:inline}.fr,.fr-a,.fr-li li{float:right;_display:inline}.w1200{width:1200px;margin:0 auto}.padd{padding:.1px}.opacity{filter:alpha(opacity=80);-moz-opacity:.8;-khtml-opacity:8}.cb:after{content:".";display:block;height:0;overflow:hidden;visibility:hidden;clear:both}.ib{display:inline-block;*display:inline;*zoom:1}', ""]),
            a["Z"] = r
        },
        1156: function(e, a, t) {
            "use strict";
            t.r(a);
            var i = t(8081)
              , o = t.n(i)
              , n = t(3645)
              , s = t.n(n)
              , r = s()(o());
            r.push([e.id, "@font-face{font-family:font4;src:url(https://farm-res.s3.ap-southeast-1.amazonaws.com/web/assets/CSS/%E8%BF%B7%E4%BD%A0%E7%B2%97%E7%AD%92%E5%9C%86.TTF);font-weight:400;font-style:normal}", ""]),
            a["default"] = r
        },
        2537: function(e, a, t) {
            "use strict";
            t.r(a);
            var i = t(8081)
              , o = t.n(i)
              , n = t(3645)
              , s = t.n(n)
              , r = s()(o());
            r.push([e.id, ".bottomBox_web[data-v-6ead3ed4]{position:relative;height:480px}.bottomBox_web .cat[data-v-6ead3ed4]{position:absolute;top:-142px;left:10px}.bottomBox_web .miners[data-v-6ead3ed4]{position:absolute;top:-147px;right:50px}.bottomBox_web .bottom[data-v-6ead3ed4]{width:100%;height:800px;background-color:#30047f;background:url(https://farm-res.s3.ap-southeast-1.amazonaws.com/web/assets/bottom_bg.png);background-size:cover;background-repeat:no-repeat;position:absolute;bottom:0;left:0;color:#fff;padding-top:350px}.bottomBox_web .bottom .bottom_title[data-v-6ead3ed4]{font-size:50px}.bottomBox_web .bottom .bottom_content[data-v-6ead3ed4]{font-size:30px}.bottomBox_web .bottom .downGame[data-v-6ead3ed4]{width:50%;margin:30px auto}.bottomBox_web .bottom .downGame div[data-v-6ead3ed4]{width:22%;height:80px;line-height:68px;color:#33344d;font-size:22px;padding-left:2.1%;cursor:pointer}.bottomBox_web .bottom .downGame .webGame[data-v-6ead3ed4]{background:url(https://farm-res.s3.ap-southeast-1.amazonaws.com/web/assets/web_bg.png);background-size:100% 80%;background-repeat:no-repeat}.bottomBox_web .bottom .downGame .webGame[data-v-6ead3ed4]:hover{background:url(https://farm-res.s3.ap-southeast-1.amazonaws.com/web/assets/web_hover.png);background-size:100% 80%;background-repeat:no-repeat}.bottomBox_web .bottom .downGame .androidGame[data-v-6ead3ed4]{background:url(https://farm-res.s3.ap-southeast-1.amazonaws.com/web/assets/android_bg.png);background-size:100% 80%;background-repeat:no-repeat}.bottomBox_web .bottom .downGame .androidGame[data-v-6ead3ed4]:hover{background:url(https://farm-res.s3.ap-southeast-1.amazonaws.com/web/assets/android_hover.png);background-size:100% 80%;background-repeat:no-repeat}.bottomBox_web .bottom .downGame .iosGame[data-v-6ead3ed4]{background:url(https://farm-res.s3.ap-southeast-1.amazonaws.com/web/assets/ios_bg.png);background-size:100% 80%;background-repeat:no-repeat}.bottomBox_web .bottom .downGame .iosGame[data-v-6ead3ed4]:hover{background:url(https://farm-res.s3.ap-southeast-1.amazonaws.com/web/assets/ios_hover.png);background-size:100% 80%;background-repeat:no-repeat}.bottomBox_web .bottom .download[data-v-6ead3ed4]{width:136px;height:136px;padding:6px 5px;margin:auto;background-color:#fff}.bottomBox_mobile[data-v-6ead3ed4]{position:relative}.bottomBox_mobile .bottom[data-v-6ead3ed4]{width:100%;height:380px;background-color:#30047f;background:url(https://farm-res.s3.ap-southeast-1.amazonaws.com/web/assets/mobile/bottom_bg_mobile.png);background-size:cover;background-repeat:no-repeat;position:absolute;bottom:0;left:0;color:#fff;padding:120px 0 40px 0}.bottomBox_mobile .bottom .bottom_title[data-v-6ead3ed4]{font-size:30px}.bottomBox_mobile .bottom .bottom_content[data-v-6ead3ed4]{font-size:15px}.bottomBox_mobile .bottom .downGame div[data-v-6ead3ed4]{width:50%;height:80px;line-height:65px;color:#33344d;font-size:22px;padding-left:5%;cursor:pointer}.bottomBox_mobile .bottom .downGame .webGame[data-v-6ead3ed4]{background:url(https://farm-res.s3.ap-southeast-1.amazonaws.com/web/assets/web_bg.png);background-size:100% 80%;background-repeat:no-repeat}.bottomBox_mobile .bottom .downGame .androidGame[data-v-6ead3ed4]{background:url(https://farm-res.s3.ap-southeast-1.amazonaws.com/web/assets/android_bg.png);background-size:100% 80%;background-repeat:no-repeat}.bottomBox_mobile .bottom .downGame .iosGame[data-v-6ead3ed4]{background:url(https://farm-res.s3.ap-southeast-1.amazonaws.com/web/assets/ios_bg.png);background-size:100% 80%;background-repeat:no-repeat}.bottomBox_mobile .bottom .download[data-v-6ead3ed4]{width:136px;height:136px;padding:6px 5px;margin:auto;background-color:#fff}", ""]),
            a["default"] = r
        },
        5441: function(e, a, t) {
            "use strict";
            t.r(a);
            var i = t(8081)
              , o = t.n(i)
              , n = t(3645)
              , s = t.n(n)
              , r = s()(o());
            r.push([e.id, ".header_web[data-v-61ba947b]{width:100%;position:relative;font-family:mini;font-size:20px;z-index:10}.header_web .navbar[data-v-61ba947b]{height:50px;padding:0 20px;background-color:#fff;border-top-left-radius:30px;border-bottom-left-radius:30px;position:fixed;top:40px;right:0;box-shadow:0 0 8px 0 rgba(0,0,0,.5)}.header_web .navbar .titleBox[data-v-61ba947b]{line-height:50px}.header_web .navbar .headerTitle[data-v-61ba947b]{color:#33344d;cursor:pointer;margin:0 10px}.header_web .navbar .headerTitle[data-v-61ba947b]:hover{color:#f74da5}.header_web .navbar .headerTitleChoose[data-v-61ba947b]{color:#f74da5;cursor:pointer;margin:0 10px}.header_web .navbar .outImg[data-v-61ba947b]{width:180px;position:relative}.header_web .navbar .outImg div[data-v-61ba947b]{width:35px;height:35px;background-size:cover!important;background-repeat:no-repeat!important;cursor:pointer}.header_web .navbar .outImg div[data-v-61ba947b]:hover{transform:scale(1.1)}.header_web .navbar .playNow[data-v-61ba947b]{min-width:220px;height:75px;padding-top:10px;line-height:25px;position:fixed;top:28px;right:-40px;cursor:pointer}.header_mobile[data-v-61ba947b]{width:100%;position:relative;font-family:mini;font-size:20px;z-index:10}.header_mobile .navbar[data-v-61ba947b]{padding:0 20px;height:45px;background-color:#fff;border-top-left-radius:30px;border-bottom-left-radius:30px;position:fixed;top:40px;right:0;box-shadow:0 0 8px 0 rgba(0,0,0,.5)}.header_mobile .navbar .navIcon[data-v-61ba947b]{font-size:40px;color:#f74da5}.header_mobile .navbar div[data-v-61ba947b]{width:40px;height:40px;background-size:cover!important;background-repeat:no-repeat!important}.header_mobile .closee[data-v-61ba947b]{width:50px;height:50px;border-radius:50%;line-height:50px;background-color:#fff;font-size:30px;font-weight:700;color:#f74da5;margin-top:20px;margin-left:70%}.header_mobile .mobile_logo[data-v-61ba947b]{width:150px;margin:40px auto 30px}.header_mobile .titleBox[data-v-61ba947b]{font-size:25px}.header_mobile .titleBox .headerTitle[data-v-61ba947b]{margin:30px 0}.header_mobile .titleBox .headerTitleChoose[data-v-61ba947b]{color:#f74da5;margin:30px 0}.header_mobile .titleBox .playNow[data-v-61ba947b]{width:80%;height:70px;padding-top:10px;line-height:25px;margin:auto;font-size:20px}.login_box[data-v-61ba947b]{min-width:380px}.login_box .login_box_web[data-v-61ba947b]{color:#fff;font-size:25px;position:relative}.login_box .login_box_web .guanbi[data-v-61ba947b]{width:40px;height:40px;margin-left:92%;margin-top:-10px;line-height:40px;border-radius:50%;background-color:#fff;font-size:30px;font-weight:700;color:#f74da5;cursor:pointer}.login_box .login_box_web .login_phone[data-v-61ba947b]{min-width:40%;max-width:40%;font-size:24px;text-align:right}.login_box .login_box_web .code[data-v-61ba947b]{width:60%;height:45px;background-color:#fff;color:#000;margin:20px 0 20px 10px;border-radius:30px!important}.login_box .login_box_web .code .send_code[data-v-61ba947b]{min-width:120px;padding:0 5px;height:41px;line-height:40px;border-radius:30px;background-color:#f74da5;color:#fff;font-size:12px;cursor:pointer;text-align:center;margin-right:5px}.login_box .login_box_web .code .send_code[data-v-61ba947b]:hover{background-color:#49afdd;transform:scale(1.1);box-shadow:0 0 8px 0 rgba(0,0,0,.5)}.login_box .login_box_web .login_btn[data-v-61ba947b]{width:240px;padding:0 10px;margin:auto;height:75px;font-size:22px;border-radius:30px;line-height:75px;cursor:pointer}.login_box .login_box_web .zhuce[data-v-61ba947b]{margin-top:20px}.login_box .login_box_web .zhuce div[data-v-61ba947b]{width:70px;height:65px;cursor:pointer;background-size:cover;background-repeat:no-repeat}.login_box .login_box_mobile[data-v-61ba947b]{color:#fff;font-size:20px;position:relative}.login_box .login_box_mobile .guanbi[data-v-61ba947b]{width:35px;height:35px;line-height:38px;border-radius:50%;margin-left:90%;margin-top:-30px;background-color:#fff;font-size:30px;font-weight:700;color:#f74da5}.login_box .login_box_mobile .code[data-v-61ba947b]{color:#33344d;margin:20px auto}.login_box .login_box_mobile .code .send_code[data-v-61ba947b]{width:200px;height:45px;margin-left:10px;line-height:40px;background-color:#f74da5;border-radius:30px;font-size:12px;cursor:pointer;color:#fff}.login_box .login_box_mobile .login_btn[data-v-61ba947b]{width:220px;margin:auto;height:70px;font-size:22px;border-radius:30px;line-height:70px;color:#fff}.login_box .login_box_mobile .zhuce[data-v-61ba947b]{margin-top:20px}.login_box .login_box_mobile .zhuce img[data-v-61ba947b]{width:55px}.google[data-v-61ba947b]{background:url(https://farm-res.s3.ap-southeast-1.amazonaws.com/web/assets/icon/google1.png)}.google[data-v-61ba947b]:hover{background:url(https://farm-res.s3.ap-southeast-1.amazonaws.com/web/assets/icon/google2.png)}.line[data-v-61ba947b]{background:url(https://farm-res.s3.ap-southeast-1.amazonaws.com/web/assets/icon/line1.png)}.line[data-v-61ba947b]:hover{background:url(https://farm-res.s3.ap-southeast-1.amazonaws.com/web/assets/icon/line2.png)}.tiwtter[data-v-61ba947b]{background:url(https://farm-res.s3.ap-southeast-1.amazonaws.com/web/assets/icon/tiwtter1.png)}.tiwtter[data-v-61ba947b]:hover{background:url(https://farm-res.s3.ap-southeast-1.amazonaws.com/web/assets/icon/tiwtter2.png)}.telegram[data-v-61ba947b]{background:url(https://farm-res.s3.ap-southeast-1.amazonaws.com/web/assets/icon/telegram1.png)}.telegram[data-v-61ba947b]:hover{background:url(https://farm-res.s3.ap-southeast-1.amazonaws.com/web/assets/icon/telegram2.png)}.metaMask[data-v-61ba947b]{background:url(https://farm-res.s3.ap-southeast-1.amazonaws.com/web/assets/icon/metaMask1.png)}.metaMask[data-v-61ba947b]:hover{background:url(https://farm-res.s3.ap-southeast-1.amazonaws.com/web/assets/icon/metaMask2.png)}.facebook[data-v-61ba947b]{background:url(https://farm-res.s3.ap-southeast-1.amazonaws.com/web/assets/icon/facebook1.png)}.facebook[data-v-61ba947b]:hover{background:url(https://farm-res.s3.ap-southeast-1.amazonaws.com/web/assets/icon/facebook2.png)}.lang[data-v-61ba947b]{margin-left:2px;background:url(https://farm-res.s3.ap-southeast-1.amazonaws.com/web/assets/icon/lang1.png);position:relative}.lang[data-v-61ba947b]:hover{background:url(https://farm-res.s3.ap-southeast-1.amazonaws.com/web/assets/icon/lang2.png)}.lang_change[data-v-61ba947b]{position:absolute;top:50px;left:63%}.lang_change p[data-v-61ba947b]{padding:5px;margin:5px auto;height:45%;line-height:40px;background-color:#f74da5;border-radius:5px;cursor:pointer}.lang_change p[data-v-61ba947b]:hover{transform:scale(1.1)}", ""]),
            a["default"] = r
        },
        4169: function(e, a, t) {
            "use strict";
            t.r(a);
            var i = t(8081)
              , o = t.n(i)
              , n = t(3645)
              , s = t.n(n)
              , r = s()(o());
            r.push([e.id, "[contenteditable=true],input,textarea{-webkit-user-select:auto!important;-moz-user-select:auto!important;-o-user-select:auto!important;user-select:auto!important}.el-input__inner{border-radius:30px!important;background-color:#fff!important;border:none!important;color:#33344d!important;font-size:16px}.el-drawer__header{display:none!important}.el-dialog__header{background-color:#8459fe;border-radius:10px;display:none}.el-dialog,.el-dialog__body{border-radius:20px!important}.el-dialog__body{padding:30px 20px 30px 20px!important;background-color:#8459fe;border:2px solid #fff}.el-loading-mask{border-radius:40px!important}.el-select--medium{vertical-align:bottom!important}.el-select-dropdown__item{text-align:center}.el-drawer{background-color:#8459fe!important}.el-scrollbar .el-scrollbar__bar{opacity:1!important}", ""]),
            a["default"] = r
        },
        9029: function(e, a, t) {
            "use strict";
            t.r(a);
            var i = t(8081)
              , o = t.n(i)
              , n = t(3645)
              , s = t.n(n)
              , r = s()(o());
            r.push([e.id, ".game_web[data-v-69125d5a]{width:100%;height:193vh;background:url(https://farm-res.s3.ap-southeast-1.amazonaws.com/web/assets/game_bg.jpg);background-size:cover;background-repeat:no-repeat;font-size:20px;overflow:hidden;padding-top:160px;position:relative}.game_web .game_title[data-v-69125d5a]{font-size:35px}.game_web .carousel .carousel_item[data-v-69125d5a]{width:40%;height:500px;background-color:#fff;border-radius:18px}.game_web .carousel .carousel_item img[data-v-69125d5a]{width:100%}.game_web .carousel .carousel_item .carousel_content[data-v-69125d5a]{padding:0 20px;color:#33344d;font-size:15px}.game_web .carousel .carousel_item .carousel_content .carousel_title[data-v-69125d5a]{font-size:20px}.game_web .carousel .indicator[data-v-69125d5a]{margin:30px auto;padding-bottom:40px}.game_web .carousel .indicator .indicator_item[data-v-69125d5a]{width:18px;height:18px;border:2px solid #fff;border-radius:50%;margin:0 10px;cursor:pointer}.game_web .carousel .indicator .indicator_choose[data-v-69125d5a]{background-color:#fff}.game_web .carousel .indicator .direction_img[data-v-69125d5a]{width:40px;height:40px;cursor:pointer;background:url(https://farm-res.s3.ap-southeast-1.amazonaws.com/web/assets/right.png);background-size:cover;background-repeat:no-repeat}.game_web .carousel .indicator .direction_img[data-v-69125d5a]:hover{background:url(https://farm-res.s3.ap-southeast-1.amazonaws.com/web/assets/right_hover.png);background-size:cover;background-repeat:no-repeat}.game_web .new_box[data-v-69125d5a]{width:100%;height:1000px;color:#33344d;font-size:15px}.game_web .new_box .newBack[data-v-69125d5a]{width:100%;height:1000px;background-size:100% 88%!important;background-repeat:no-repeat!important;position:relative}.game_web .new_box .newBack .new_logo[data-v-69125d5a]{width:200px;position:absolute;top:-60px;right:20px}.game_web .new_box .newBack .newContent[data-v-69125d5a]{width:650px;padding:20px;line-height:20px;position:absolute;top:150px;right:-10px;background-color:#fff;color:#33344d}.game_web .new_box .newBack .newContent .new_title[data-v-69125d5a]{font-size:20px}.game_web .new_box .newBack .newContent .newIndicator[data-v-69125d5a]{width:50%}.game_web .new_box .newBack .newContent .newIndicator .indicator_item[data-v-69125d5a]{width:18px;height:18px;background-color:#fdbacb;border-radius:50%;margin:0 10px;cursor:pointer}.game_web .new_box .newBack .newContent .newIndicator .indicator_choose[data-v-69125d5a],.game_web .new_box .newBack .newContent .newIndicator .indicator_item[data-v-69125d5a]:hover{background-color:#f65285}.game_web .new_box .newBack .newContent .newIndicator .direction_img[data-v-69125d5a]{width:40px;height:40px;cursor:pointer;background:url(https://farm-res.s3.ap-southeast-1.amazonaws.com/web/assets/right.png);background-size:cover;background-repeat:no-repeat}.game_web .new_box .newBack .newContent .newIndicator .direction_img[data-v-69125d5a]:hover{background:url(https://farm-res.s3.ap-southeast-1.amazonaws.com/web/assets/right_hover.png);background-size:cover;background-repeat:no-repeat}.game_mobile[data-v-69125d5a]{width:100%;background:url(https://farm-res.s3.ap-southeast-1.amazonaws.com/web/assets/game_bg.jpg);background-size:cover;background-repeat:no-repeat;font-size:20px;overflow:hidden;padding:160px 0 200px 0;position:relative}.game_mobile .game_title[data-v-69125d5a]{font-size:30px}.game_mobile .carousel[data-v-69125d5a]{width:95%;margin:auto}.game_mobile .carousel .carousel_item[data-v-69125d5a]{width:100%;height:400px;background-color:#fff;border-radius:18px}.game_mobile .carousel .carousel_item img[data-v-69125d5a]{width:100%}.game_mobile .carousel .carousel_item .carousel_content[data-v-69125d5a]{padding:0 20px;color:#33344d;font-size:15px}.game_mobile .carousel .carousel_item .carousel_content .carousel_title[data-v-69125d5a]{font-size:20px}.game_mobile .carousel .indicator[data-v-69125d5a]{padding-bottom:20px}.game_mobile .carousel .indicator .indicator_item[data-v-69125d5a]{width:20px;height:20px;border:2px solid #fff;border-radius:50%;margin:0 10px;cursor:pointer}.game_mobile .carousel .indicator .indicator_choose[data-v-69125d5a]{background-color:#fff}.game_mobile .carousel .indicator .direction_img[data-v-69125d5a]{width:50px;height:50px;cursor:pointer;background:url(https://farm-res.s3.ap-southeast-1.amazonaws.com/web/assets/right.png);background-size:cover;background-repeat:no-repeat}.game_mobile .new_box[data-v-69125d5a]{width:95%;margin:auto;color:#33344d;font-size:15px}.game_mobile .new_box .newContent[data-v-69125d5a]{line-height:20px}.game_mobile .new_box .newContent .newContent_item[data-v-69125d5a]{width:100%;height:375px;background-color:#fff;margin:50px 0;padding:20px 0 0 0;border:0}.game_mobile .new_box .newContent .newContent_item img[data-v-69125d5a]{width:100%;margin-top:20px;border-radius:17px}.game_mobile .new_box .newContent .new_title[data-v-69125d5a]{font-size:20px}", ""]),
            a["default"] = r
        },
        5799: function(e, a, t) {
            "use strict";
            t.r(a);
            var i = t(8081)
              , o = t.n(i)
              , n = t(3645)
              , s = t.n(n)
              , r = s()(o());
            r.push([e.id, ".home_web[data-v-62cb1345]{width:100%;height:380vh;background:url(https://farm-res.s3.ap-southeast-1.amazonaws.com/web/assets/home_bg.jpg);background-size:cover;background-repeat:no-repeat;font-size:20px;overflow:hidden;position:relative}.home_web .pinkColor[data-v-62cb1345]{padding:0 20px;color:#f2246f;font-size:20px}.home_web .animationStart[data-v-62cb1345]{animation:imgSc-62cb1345 1.5s linear .2s}.home_web .content_bg[data-v-62cb1345]{width:100%;height:100vh}.home_web .content_bg .logoImg[data-v-62cb1345]{width:100%;padding-top:100px}.home_web .content_bg .logoImg .contentLogo[data-v-62cb1345]{width:50%;height:80vh;animation:imgSc-62cb1345 1.2s linear .2s}.home_web .content_bg .btnBox[data-v-62cb1345]{margin-top:-60px;animation:imgSc-62cb1345 .8s linear .2s}.home_web .content_bg .btnBox .playGame[data-v-62cb1345]{min-width:240px;padding:0 20px;height:60px;line-height:25px;margin:0 20px;color:#f74da5;background-color:#fff;border-radius:30px}.home_web .content_activity[data-v-62cb1345]{width:100%}.home_web .content_activity .activity[data-v-62cb1345]{width:400px;height:500px;background-color:#fff;border:none;border-radius:17px;color:#f74da5;margin:5px 15px}.home_web .content_activity .activity img[data-v-62cb1345]{width:100%;height:60%}.home_web .content_deal[data-v-62cb1345]{width:80%;height:110px;overflow:hidden;background-color:#8459fe;font-size:17px}.home_web .content_deal .horn[data-v-62cb1345]{width:75px;margin:0 10px}.home_web .content_deal .deal[data-v-62cb1345]{margin:10px}.home_web .content_market[data-v-62cb1345]{height:810px;background-color:#f5f6fa;color:#33344d}.home_web .content_market .sellIcon[data-v-62cb1345]{width:50px;margin-left:20px}.home_web .content_market .currency[data-v-62cb1345]{width:180px;height:35px;margin:0 20px;border-radius:30px;line-height:35px;background-color:#fff}.home_web .content_market .currency img[data-v-62cb1345]{width:35px;margin-right:10%}.home_web .content_market .sellOut[data-v-62cb1345]{width:180px;height:65px}.home_web .content_market .btnLine div[data-v-62cb1345]{width:180px;height:60px;margin:10px 0}.home_web .content_market .btnLine .line_k[data-v-62cb1345]{width:130px;height:30px;margin:10px auto;color:red;font-size:16px}.home_web .content_market .btnLine .line_k img[data-v-62cb1345]{width:100px;margin-right:10px}.home_web .content_market .prop_type[data-v-62cb1345]{height:120px;position:relative;overflow:hidden;margin-top:30px}.home_web .content_market .prop_type .prop_item[data-v-62cb1345]{width:100px;height:120px;line-height:50px;margin-right:10px;cursor:pointer;background:url(https://farm-res.s3.ap-southeast-1.amazonaws.com/web/assets/prop_bg.png);background-size:100% 77.5%;background-repeat:no-repeat;border-radius:50%;color:red}.home_web .content_market .prop_type .prop_item img[data-v-62cb1345]{width:65px;height:65px;border-radius:50%;margin-top:15px}.home_web .content_market .prop_type .prop_item[data-v-62cb1345]:hover{background:url(https://farm-res.s3.ap-southeast-1.amazonaws.com/web/assets/prop_hover.png);background-size:100% 77.5%;background-repeat:no-repeat;transform:scale(1.1)}.home_web .content_market .prop_type .propChoose[data-v-62cb1345]{background:url(https://farm-res.s3.ap-southeast-1.amazonaws.com/web/assets/prop_choose.png);background-size:100% 77.5%;background-repeat:no-repeat}.home_web .introduction_game[data-v-62cb1345]{width:100%;height:500px;position:relative}.home_web .introduction_game .iconOne[data-v-62cb1345]{width:150px;height:150px;margin-top:-120px;margin-right:100px;position:absolute;top:0;right:150px}.home_web .introduction_game .introduction_title[data-v-62cb1345]{font-size:55px;color:#fff}.home_web .introduction_game .introduction_info[data-v-62cb1345]{margin-top:50px}.home_web .introduction_game .introduction_info div[data-v-62cb1345]{min-width:20%;padding:0 20px;height:60px;background-color:#fff;border-radius:30px;font-size:18px;line-height:25px;padding-top:5px;color:#78798d}.home_web .introduction_game .market_deal[data-v-62cb1345]{height:520px;border-radius:20px;background-color:#fff;display:flex;border:none;color:#78798d}.home_web .introduction_game .market_deal img[data-v-62cb1345]{width:70%;height:100%}.home_web .introduction_game .market_deal .deal_text[data-v-62cb1345]{width:30%;padding:40px;position:relative;text-align:left;line-height:35px}.home_web .introduction_game .market_deal .deal_text img[data-v-62cb1345]{width:20px;margin:0 20px 0 60px}.home_web .introduction_game .market_deal .deal_text .deal_title[data-v-62cb1345]{font-size:25px;color:#33344d;text-align:center;margin-bottom:10px}.home_web .introduction_game .market_deal .zhDeal[data-v-62cb1345]{line-height:60px}.home_web .introduction_game .market_deal .manor[data-v-62cb1345]{width:280px;height:80px;line-height:78px;margin:40px auto 300px;font-size:21px;text-align:center}.home_web .introduction_game .market_deal .inDeal[data-v-62cb1345]{width:280px;height:80px;line-height:20px;padding:20px 0;margin:40px auto 300px;font-size:18px;text-align:center}.home_web .downGame div[data-v-62cb1345]{width:150px;height:60px;line-height:50px;color:#33344d;font-size:18px;cursor:pointer;padding-left:15px}.home_web .downGame .webGame[data-v-62cb1345]{position:absolute;top:120px;right:-22px;background:url(https://farm-res.s3.ap-southeast-1.amazonaws.com/web/assets/web_bg.png);background-size:100% 80%;background-repeat:no-repeat}.home_web .downGame .webGame[data-v-62cb1345]:hover{background:url(https://farm-res.s3.ap-southeast-1.amazonaws.com/web/assets/web_hover.png);background-size:100% 80%;background-repeat:no-repeat}.home_web .downGame .androidGame[data-v-62cb1345]{position:absolute;top:180px;right:-22px;background:url(https://farm-res.s3.ap-southeast-1.amazonaws.com/web/assets/android_bg.png);background-size:100% 80%;background-repeat:no-repeat}.home_web .downGame .androidGame[data-v-62cb1345]:hover{background:url(https://farm-res.s3.ap-southeast-1.amazonaws.com/web/assets/android_hover.png);background-size:100% 80%;background-repeat:no-repeat}.home_web .downGame .iosGame[data-v-62cb1345]{position:absolute;top:240px;right:-22px;background:url(https://farm-res.s3.ap-southeast-1.amazonaws.com/web/assets/ios_bg.png);background-size:100% 80%;background-repeat:no-repeat}.home_web .downGame .iosGame[data-v-62cb1345]:hover{background:url(https://farm-res.s3.ap-southeast-1.amazonaws.com/web/assets/ios_hover.png);background-size:100% 80%;background-repeat:no-repeat}.home_web .downQr[data-v-62cb1345]{width:110px;height:108px;padding:4px 5px;border:2px solid #fff;background-color:#fff;border-radius:10px;position:absolute;top:300px;right:-3px}.home_mobile[data-v-62cb1345]{width:100%;background:url(https://farm-res.s3.ap-southeast-1.amazonaws.com/web/assets/mobile/home_bg_mobile.jpg);background-size:cover;background-repeat:no-repeat;font-size:20px}.home_mobile .pinkColor[data-v-62cb1345]{color:#f2246f;font-size:20px;padding:0 10px}.home_mobile .animationStart[data-v-62cb1345]{animation:animation-62cb1345 1.5s linear .2s}@keyframes animation-62cb1345{to{-webkit-transform:translateY(0) scale(1);opacity:1}40%{-webkit-transform:translateY(-5px) scale(1)}0%{-webkit-transform:translateY(5px) scale(0)}}.home_mobile .content_bg[data-v-62cb1345]{height:470px;position:relative}.home_mobile .content_bg .contentLogo[data-v-62cb1345]{width:100%;position:absolute;top:100px;left:5%;animation:imgSc-62cb1345 1.2s linear .2s}@keyframes imgSc-62cb1345{to{-webkit-transform:translateY(0) scale(1)}40%{-webkit-transform:translateY(-15px) scale(1)}0%{-webkit-transform:translateY(5px) scale(0)}}.home_mobile .content_bg .contentLogo_height[data-v-62cb1345]{width:100%;height:350px}.home_mobile .content_bg .btnBox[data-v-62cb1345]{animation-name:my;animation:imgSc-62cb1345 .8s linear .2s}.home_mobile .content_bg .btnBox .playGame[data-v-62cb1345]{width:200px;height:75px;line-height:80px}.home_mobile .content_activity[data-v-62cb1345]{width:100%;height:420px;overflow:hidden}.home_mobile .content_activity .activity[data-v-62cb1345]{width:300px;height:390px;padding:0 0 20px 0;overflow:hidden;background-color:#fff;border:none;border-radius:17px;color:#f74da5;margin:10px}.home_mobile .content_activity .activity img[data-v-62cb1345]{width:100%;height:60%}.home_mobile .content_deal[data-v-62cb1345]{width:100%;height:110px;overflow:hidden;background-color:#8459fe;font-size:16px}.home_mobile .content_deal .horn[data-v-62cb1345]{width:55px;margin:0 10px}.home_mobile .content_deal .deal[data-v-62cb1345]{margin:15px 5px}.home_mobile .content_market[data-v-62cb1345]{background-color:#f5f6fa;color:#33344d}.home_mobile .content_market .sellIcon[data-v-62cb1345]{width:40px;margin-left:10px}.home_mobile .content_market .currency[data-v-62cb1345]{width:35%;height:35px;margin:0 10px;border-radius:30px;line-height:35px;background-color:#fff}.home_mobile .content_market .currency img[data-v-62cb1345]{width:30px;margin-right:10%}.home_mobile .content_market .sellOut[data-v-62cb1345]{padding:0 20px;height:55px;line-height:55px}.home_mobile .content_market .btnLine div[data-v-62cb1345]{width:50%;height:55px}.home_mobile .content_market .line_k[data-v-62cb1345]{height:30px;margin:10px;font-size:16px}.home_mobile .content_market .line_k img[data-v-62cb1345]{width:100px;margin-right:10px}.home_mobile .content_market .prop_type[data-v-62cb1345]{height:120px;position:relative;overflow:hidden;margin-top:30px}.home_mobile .content_market .prop_type .prop_item[data-v-62cb1345]{width:80px;line-height:50px;margin-right:10px;color:red}.home_mobile .content_market .prop_type .prop_item img[data-v-62cb1345]{width:55px;height:55px;border-radius:50%;margin-top:15px}.home_mobile .content_market .prop_type .prop_img[data-v-62cb1345]{width:100%;height:80px;background:url(https://farm-res.s3.ap-southeast-1.amazonaws.com/web/assets/prop_bg.png);background-size:100% 100%;background-repeat:no-repeat}.home_mobile .content_market .prop_type .propChoose[data-v-62cb1345]{background:url(https://farm-res.s3.ap-southeast-1.amazonaws.com/web/assets/prop_choose.png);background-size:100% 100%;background-repeat:no-repeat}.home_mobile .introduction_game[data-v-62cb1345]{width:100%;position:relative}.home_mobile .introduction_game .iconOne[data-v-62cb1345]{width:85px;height:100px;position:absolute;top:-50px;right:10px}.home_mobile .introduction_game .iconOne img[data-v-62cb1345]{width:100%;height:100%}.home_mobile .introduction_game .introduction_title[data-v-62cb1345]{font-size:20px;color:#fff;padding-top:50px}.home_mobile .introduction_game .introduction_info[data-v-62cb1345]{margin-top:40px}.home_mobile .introduction_game .introduction_info div[data-v-62cb1345]{width:30%;height:50px;padding-top:5px;background-color:#fff;line-height:20px;border-radius:30px;font-size:14px;color:#78798d}.home_mobile .introduction_game .market_deal[data-v-62cb1345]{width:100%;height:630px;background-color:#fff;border:none;border-radius:0;color:#78798d}.home_mobile .introduction_game .market_deal img[data-v-62cb1345]{width:100%;height:32%}.home_mobile .introduction_game .market_deal .deal_text[data-v-62cb1345]{width:100%;line-height:28px;font-size:13px}.home_mobile .introduction_game .market_deal .deal_text img[data-v-62cb1345]{width:20px;margin:0 10px 0 0}.home_mobile .introduction_game .market_deal .deal_text .deal_title[data-v-62cb1345]{font-size:20px;color:#33344d;margin-top:30px}.home_mobile .introduction_game .market_deal .manor[data-v-62cb1345]{width:260px;height:80px;line-height:78px;margin:20px 0 300px 60px;font-size:21px}", ""]),
            a["default"] = r
        },
        9459: function(e, a, t) {
            "use strict";
            t.r(a);
            var i = t(8081)
              , o = t.n(i)
              , n = t(3645)
              , s = t.n(n)
              , r = s()(o());
            r.push([e.id, ".question_web[data-v-f0d20430]{width:100%;height:150vh;background:url(https://farm-res.s3.ap-southeast-1.amazonaws.com/web/assets/question_bg.jpg);background-size:100% 110%;background-repeat:no-repeat;font-size:20px;overflow:hidden;position:relative}.question_web .question_title[data-v-f0d20430]{padding-top:160px;font-size:40px}.question_web .down[data-v-f0d20430]{transform:rotate(180deg)}.question_web .question_box[data-v-f0d20430]{padding:20px 20px 150px 20px;background-color:#fff;position:relative}.question_web .question_box .question_logo[data-v-f0d20430]{width:150px;position:absolute;top:-114px;right:20px}.question_web .question_box .problem_item[data-v-f0d20430]{text-align:left;margin-bottom:10px;color:#777a8b;font-size:18px;line-height:25px}.question_web .question_box .problem_item .problem_title[data-v-f0d20430]{padding:10px;font-size:18px;color:#33344d;border:1px solid #e2e2e2;margin:15px 0;cursor:pointer}.question_web .question_box .problem_item .down_img[data-v-f0d20430]{width:20px}.question_mobile[data-v-f0d20430]{width:100%;background:url(https://farm-res.s3.ap-southeast-1.amazonaws.com/web/assets/mobile/question_bg_mobile.jpg);background-size:100% 110%;background-repeat:no-repeat;font-size:20px;overflow:hidden;position:relative;padding-bottom:300px}.question_mobile .question_title[data-v-f0d20430]{padding-top:160px;font-size:32px}.question_mobile .down[data-v-f0d20430]{transform:rotate(180deg)}.question_mobile .question_box[data-v-f0d20430]{width:96%;min-height:800px;margin:30px auto;background-color:#fff;position:relative}.question_mobile .question_box .question_logo[data-v-f0d20430]{width:80px;position:absolute;top:-63px;right:20px}.question_mobile .question_box .problem_item[data-v-f0d20430]{width:100%;text-align:left;margin-bottom:10px;color:#777a8b;font-size:18px;line-height:25px}.question_mobile .question_box .problem_item .problem_title[data-v-f0d20430]{padding:10px;font-size:18px;color:#33344d;border-top:1px solid #e2e2e2;border-bottom:1px solid #e2e2e2;margin:15px 0}.question_mobile .question_box .problem_item .down_img[data-v-f0d20430]{width:20px}", ""]),
            a["default"] = r
        },
        8537: function(e, a, t) {
            "use strict";
            var i = t(144)
              , o = function() {
                var e = this
                  , a = e._self._c;
                return e.operaterId ? a("div", {
                    attrs: {
                        id: "app"
                    }
                }, [a("Header"), a("router-view"), a("Bottom")], 1) : e._e()
            }
              , n = []
              , s = (t(7658),
            t(7918))
              , r = t.n(s)
              , l = function() {
                var e = this
                  , a = e._self._c;
                return a("div", [a("el-row", {
                    staticClass: "hidden-xs-only",
                    attrs: {
                        gutter: 0
                    }
                }, [a("div", {
                    staticClass: "bottomBox_web"
                }, [a("div", {
                    staticClass: "bottom textCenter"
                }, [a("img", {
                    staticClass: "cat",
                    attrs: {
                        src: "https://farm-res.s3.ap-southeast-1.amazonaws.com/web/assets/cat.png",
                        alt: ""
                    }
                }), a("img", {
                    staticClass: "miners",
                    attrs: {
                        src: "https://farm-res.s3.ap-southeast-1.amazonaws.com/web/assets/miners.png",
                        alt: ""
                    }
                }), a("div", {
                    staticClass: "bottom_title margin_30"
                }, [e._v(e._s(e.$t("trade")))]), a("div", {
                    staticClass: "bottom_content margin_30"
                }, [e._v(e._s(e.$t("download_family")))]), a("div", {
                    staticClass: "downGame flaround textCenter"
                }, [a("div", {
                    staticClass: "webGame",
                    on: {
                        click: function(a) {
                            return e.bottpmOpenWebGame("phone")
                        }
                    }
                }, [e._v("WEB")]), a("div", {
                    staticClass: "androidGame",
                    on: {
                        click: function(a) {
                            return e.bottomDownGameNow(2)
                        }
                    }
                }, [e._v("Android")]), a("div", {
                    staticClass: "iosGame",
                    on: {
                        click: function(a) {
                            return e.bottomDownGameNow(3)
                        }
                    }
                }, [e._v("IOS")])]), a("div", {
                    staticClass: "download whiteBg"
                }, [a("div", {
                    ref: "qrCodeDiv",
                    attrs: {
                        id: "qrCode"
                    }
                })])])])]), a("el-row", {
                    staticClass: "hidden-sm-and-up",
                    attrs: {
                        gutter: 0
                    }
                }, [a("div", {
                    staticClass: "bottomBox_mobile"
                }, [a("div", {
                    staticClass: "bottom textCenter"
                }, [a("div", {
                    staticClass: "bottom_title margin_30"
                }, [e._v(e._s(e.$t("trade")))]), a("div", {
                    staticClass: "bottom_content margin_30"
                }, [e._v(e._s(e.$t("download_family")))]), a("div", {
                    staticClass: "downGame flaround textCenter"
                }, [e.androidShow ? a("div", {
                    staticClass: "androidGame",
                    on: {
                        click: function(a) {
                            return e.bottomDownGameNow(2)
                        }
                    }
                }, [e._v("Android")]) : e._e(), e.iosShow ? a("div", {
                    staticClass: "iosGame",
                    on: {
                        click: function(a) {
                            return e.bottomDownGameNow(3)
                        }
                    }
                }, [e._v("IOS")]) : e._e()])])])])], 1)
            }
              , d = []
              , u = t(3874)
              , c = t.n(u);
            function m(e, a) {
                var t;
                a = a || 200;
                return function() {
                    var i = this
                      , o = arguments;
                    t && clearTimeout(t),
                    t = setTimeout((function() {
                        t = null,
                        e.apply(i, o)
                    }
                    ), a)
                }
            }
            var g = t(9669)
              , p = t.n(g)
              , h = t(4720)
              , b = t.n(h);
            const _ = {
                mapAK: "",
                header: {
                    "Content-Type": "text/html; charset=UTF-8"
                },
                dataType: "json",
                responseType: "text"
            }
              , f = p().create({
                baseURL: _.url
            });
            function w(e, a, t={}) {
                return t.data = t.data || {},
                _.header.Authorization = localStorage.getItem("token"),
                t.header = Object.assign(_.header, t.header),
                f({
                    method: e,
                    url: a,
                    headers: t.header,
                    dataType: t.dataType || _.dataType,
                    responseType: t.responseType || _.responseType,
                    data: t.data,
                    params: "GET" === e || "DELETE" === e ? t.data : null,
                    paramsSerializer: t.paramsSerializer
                })
            }
            f.interceptors.request.use((e=>e), (e=>Promise.reject(e))),
            f.interceptors.response.use((e=>{
                switch (e.status) {
                case 0:
                case 200:
                    return e.data;
                case 500:
                    return Promise.reject(e.data);
                default:
                    return Promise.reject(e.data)
                }
            }
            ), (e=>{
                let {message: a} = e;
                "ERR_BAD_RESPONSE" == a.code || (a.includes("ETIMEDOUT") ? h.Message.error("网络请求超时，请检查网络") : a.includes("Request failed with status code"))
            }
            ));
            const v = (e,a)=>w("GET", e, a);
            function x(e) {
                return v("http://192.168.15.24:9002/https://www.littlebeefarm.net/api/getIdByInviteCode?invite_code=" + e, {
                    data: {}
                })
            }
            function y(e) {
                return v("http://192.168.15.24:9002/https://www.littlebeefarm.net/api/register?code=" + e.code + "&agent_id=" + e.agent_id + "&mobile=" + e.mobile + "&operater_id=" + e.operater_id + "&time=" + e.time + "&invite_code=" + e.invite_code + "&i=" + e.i + "&s=" + e.s + "&t=" + e.t + "&language_id=" + e.language_id + "&url=" + e.url, {
                    data: {}
                })
            }
            function k(e) {
                return v("http://192.168.15.24:9002/https://www.littlebeefarm.net/api/setVisitCount?operater_id=" + e.operater_id, {
                    data: {}
                })
            }
            function C(e) {
                return v("http://192.168.15.24:9002/https://www.littlebeefarm.net/api/getNoticeData?operater_id=" + e.operater_id, {
                    data: {}
                })
            }
            function N(e) {
                return v("http://192.168.15.24:9002/https://www.littlebeefarm.net/api/getMarketOrder?operater_id=" + e.operater_id + "&size=" + e.size + "&page=" + e.page, {
                    data: {}
                })
            }
            function I(e) {
                return v("http://192.168.15.24:9002/https://www.littlebeefarm.net/api/echarts?operater_id=" + e.operater_id + "&item_id=" + e.item_id, {
                    data: {}
                })
            }
            function S(e) {
                return v("http://192.168.15.24:9002/https://www.littlebeefarm.net/api/getWebInfo?operater_id=" + e.operater_id, {
                    data: {}
                })
            }
            function $(e) {
                return v("http://192.168.15.24:9002/https://www.littlebeefarm.net/api/getOpenInstallConfig?operater_id=" + e.operater_id, {
                    data: {}
                })
            }
            function z(e) {
                return v("http://192.168.15.24:9002/https://www.littlebeefarm.net/api/checkOperator?operater_id=" + e.operater_id + "&agent_id=" + e.agent_id, {
                    data: {}
                })
            }
            function D(e) {
                return v("http://192.168.15.24:9002/https://www.littlebeefarm.net/api/getDomainInfo?domain=" + e.domain, {
                    data: {}
                })
            }
            function B(e) {
                return v("http://192.168.15.24:9002/https://www.littlebeefarm.net/api/sendEmailCode?email=" + e.email + "&agent_id=" + e.agent_id + "&operater_id=" + e.operater_id + "&language_id=" + e.language_id, {
                    data: {}
                })
            }
            var L = {
                data() {
                    return {
                        language: sessionStorage.getItem("local"),
                        showHomeManor: !1,
                        androidShow: !1,
                        iosShow: !1
                    }
                },
                mounted() {
                    let e = "https://" + document.domain;
                    this.bindQRCode(e),
                    this.getPhoneInfo()
                },
                methods: {
                    getAgengtOperaNo() {
                        let e = this.setValue("agent_id")
                          , a = this.setValue("operater_id");
                        z({
                            agent_id: Number(e),
                            operater_id: Number(a)
                        }).then((e=>{
                            200 != e.code && (this.$message.error(e.msg),
                            this.urlFalse = !0)
                        }
                        ))
                    },
                    getOpeninstallList() {
                        let e = this.setValue("operater_id");
                        $({
                            operater_id: e
                        }).then((e=>{
                            200 == e.code && e.data ? this.getPhoneInfo(e.data) : (this.urlFalse = !0,
                            this.bindQRCode())
                        }
                        ))
                    },
                    bindQRCode(e) {
                        let a = "";
                        document.getElementById("qrCode").innerHTML = "",
                        D({
                            domain: e
                        }).then((t=>{
                            if (200 == t.code) {
                                let i = ""
                                  , o = ""
                                  , n = "";
                                i = this.setValue("operater_id") ? this.setValue("operater_id") : t.data.operater_id,
                                o = this.setValue("agent_id") ? this.setValue("agent_id") : t.data.agent_id,
                                n = this.setValue("language_id") ? this.setValue("language_id") : t.data.language_id,
                                a = this.setValue("invite") && this.setValue("inviter_id") ? e + `#/home?operater_id=${i}&agent_id=${o}&language_id=${n}&invite=${this.setValue("invite")}&inviter_id=${this.setValue("inviter_id")}` : this.setValue("invite") ? e + `#/home?operater_id=${i}&agent_id=${o}&language_id=${n}&invite=${this.setValue("invite")}` : this.setValue("inviter_id") ? e + `#/home?operater_id=${i}&agent_id=${o}&language_id=${n}&inviter_id=${this.setValue("inviter_id")}` : e + `#/home?operater_id=${i}&agent_id=${o}&language_id=${n}`
                            } else
                                a = window.location.href;
                            new (c())(this.$refs.qrCodeDiv,{
                                text: a,
                                width: 120,
                                height: 120,
                                colorDark: "#333333",
                                colorLight: "#ffffff",
                                correctLevel: c().CorrectLevel.L
                            })
                        }
                        ))
                    },
                    getPhoneInfo(e) {
                        var a = t(2437)
                          , i = new a(navigator.userAgent);
                        "AndroidOS" == i.os() ? (this.androidShow = !0,
                        this.iosShow = !1) : "iOS" == i.os() && (this.androidShow = !1,
                        this.iosShow = !0)
                    },
                    bottpmOpenWebGame(e) {
                        this.$parent.$children.map(((a,t)=>{
                            a.openWebGame && this.$parent.$children[t].openWebGame(e)
                        }
                        ))
                    },
                    bottomDownGameNow: m((function(e, a, t) {
                        this.$parent.$children.map(((a,t)=>{
                            a.openWebGame && this.$parent.$children[t].downGameNow(e)
                        }
                        ))
                    }
                    ), 1e3),
                    setValue(e) {
                        return this.getUrlParameter(e) ? this.getUrlParameter(e) : this.getLcolaOneUrlData(e) ? this.getLcolaOneUrlData(e) : this.getLcolaUrlData(e) ? this.getLcolaUrlData(e) : ""
                    },
                    getUrlParameter(e) {
                        let a = new Object;
                        return a = this.GetRequest(),
                        a[e] || ""
                    },
                    GetRequest() {
                        var e = window.location.href
                          , a = new Object;
                        let t = this.$route.path + "?";
                        if (-1 != e.indexOf(t)) {
                            let t = e.substr(0)
                              , o = t.split("?")
                              , n = o[1].split("&");
                            for (var i = 0; i < n.length; i++)
                                a[n[i].split("=")[0]] = unescape(n[i].split("=")[1])
                        }
                        return a
                    },
                    getLcolaUrlData(e) {
                        var a = sessionStorage.getItem("url")
                          , t = new Object;
                        if (a) {
                            if (-1 != a.indexOf("?")) {
                                let e = a.substr(0)
                                  , o = e.split("?")
                                  , n = o[1].split("&");
                                for (var i = 0; i < n.length; i++)
                                    t[n[i].split("=")[0]] = unescape(n[i].split("=")[1])
                            }
                            let o = new Object;
                            return o = t,
                            o[e] || ""
                        }
                    },
                    getLcolaOneUrlData(e) {
                        var a = sessionStorage.getItem("oneUrl")
                          , t = new Object;
                        if (a) {
                            if (-1 != a.indexOf("?")) {
                                let e = a.substr(0)
                                  , o = e.split("?")
                                  , n = o[1].split("&");
                                for (var i = 0; i < n.length; i++)
                                    t[n[i].split("=")[0]] = unescape(n[i].split("=")[1])
                            }
                            let o = new Object;
                            return o = t,
                            o[e] || ""
                        }
                    }
                }
            }
              , U = L
              , T = (t(7421),
            t(1001))
              , q = (0,
            T.Z)(U, l, d, !1, null, "6ead3ed4", null)
              , O = q.exports
              , G = function() {
                var e = this
                  , a = e._self._c;
                return a("div", [a("el-row", {
                    staticClass: "hidden-xs-only",
                    attrs: {
                        gutter: 0
                    }
                }, [a("div", {
                    staticClass: "header_web"
                }, [a("div", {
                    staticClass: "navbar"
                }, [a("div", {
                    staticClass: "titleBox flevenly"
                }, [e._l(e.titleData, (function(t, i) {
                    return a("div", {
                        key: i,
                        class: e.chooseHeaderIndex == i ? "headerTitleChoose" : "headerTitle",
                        on: {
                            click: function(a) {
                                return e.jumpLcation(t, i)
                            }
                        }
                    }, [a("span", [e._v(e._s(e.$t(`${t}`)))])])
                }
                )), a("div", {
                    staticClass: "outImg flitem"
                }, [a("div", {
                    staticClass: "google",
                    on: {
                        click: function(a) {
                            return e.gameOutUrl("google")
                        }
                    }
                }), a("div", {
                    staticClass: "line",
                    on: {
                        click: function(a) {
                            return e.gameOutUrl("line")
                        }
                    }
                }), a("div", {
                    staticClass: "telegram",
                    on: {
                        click: function(a) {
                            return e.gameOutUrl("telegram")
                        }
                    }
                }), a("div", {
                    staticClass: "facebook",
                    on: {
                        click: function(a) {
                            return e.gameOutUrl("facebook")
                        }
                    }
                }), a("div", {
                    staticClass: "lang",
                    on: {
                        click: function(a) {
                            e.langShow = !e.langShow
                        }
                    }
                })]), e.langShow ? a("div", {
                    staticClass: "lang_change"
                }, [a("p", {
                    on: {
                        click: function(a) {
                            return e.chooseLang("en_us")
                        }
                    }
                }, [e._v("English")]), a("p", {
                    on: {
                        click: function(a) {
                            return e.chooseLang("in_hi")
                        }
                    }
                }, [e._v("Indonesian")]), a("p", {
                    on: {
                        click: function(a) {
                            return e.chooseLang("es_es")
                        }
                    }
                }, [e._v("Spanish")])]) : e._e(), a("div", {
                    staticStyle: {
                        width: "160px"
                    }
                })], 2), e.showLoginId ? a("div", {
                    staticClass: "playNow btnBg",
                    on: {
                        click: e.outLogin
                    }
                }, [a("p", [e._v("ID:" + e._s(e.showLoginId))]), a("p", [e._v(e._s(e.$t("outlogin")))])]) : a("div", {
                    staticClass: "playNow btnBg",
                    staticStyle: {
                        "line-height": "55px"
                    },
                    on: {
                        click: function(a) {
                            return e.openWebGame("email")
                        }
                    }
                }, [a("p", [e._v(e._s(e.$t("login_game")))])])])])]), a("el-row", {
                    staticClass: "hidden-sm-and-up",
                    attrs: {
                        gutter: 0
                    }
                }, [a("div", {
                    staticClass: "header_mobile"
                }, [a("div", {
                    staticClass: "navbar flitem"
                }, [a("div", {
                    staticClass: "google",
                    on: {
                        click: function(a) {
                            return e.gameOutUrl("google")
                        }
                    }
                }), a("div", {
                    staticClass: "line",
                    on: {
                        click: function(a) {
                            return e.gameOutUrl("line")
                        }
                    }
                }), a("div", {
                    staticClass: "telegram",
                    on: {
                        click: function(a) {
                            return e.gameOutUrl("telegram")
                        }
                    }
                }), a("div", {
                    staticClass: "facebook",
                    on: {
                        click: function(a) {
                            return e.gameOutUrl("facebook")
                        }
                    }
                }), a("i", {
                    staticClass: "navIcon el-icon-s-fold",
                    on: {
                        click: function(a) {
                            e.drawerShow = !e.drawerShow
                        }
                    }
                })]), a("el-drawer", {
                    attrs: {
                        visible: e.drawerShow,
                        direction: e.menuDirection,
                        modal: !1,
                        size: "60%",
                        "before-close": e.drawerClose
                    },
                    on: {
                        "update:visible": function(a) {
                            e.drawerShow = a
                        }
                    }
                }, [a("div", {
                    staticClass: "closee",
                    on: {
                        click: e.drawerClose
                    }
                }, [a("i", {
                    staticClass: "el-icon-close"
                })]), a("img", {
                    staticClass: "mobile_logo",
                    attrs: {
                        src: "https://farm-res.s3.ap-southeast-1.amazonaws.com/web/assets/LOGO.png",
                        alt: ""
                    }
                }), a("div", {
                    staticClass: "titleBox"
                }, [a("el-select", {
                    ref: "select",
                    staticStyle: {
                        "max-width": "170px"
                    },
                    on: {
                        change: function(a) {
                            return e.chooseLang(e.language)
                        }
                    },
                    model: {
                        value: e.language,
                        callback: function(a) {
                            e.language = a
                        },
                        expression: "language"
                    }
                }, [a("el-option", {
                    staticStyle: {
                        margin: "10px 0"
                    },
                    attrs: {
                        label: "English",
                        value: "en_us"
                    }
                }), a("el-option", {
                    staticStyle: {
                        margin: "10px 0"
                    },
                    attrs: {
                        label: "Indonesia",
                        value: "in_hi"
                    }
                }), a("el-option", {
                    staticStyle: {
                        margin: "10px 0"
                    },
                    attrs: {
                        label: "Spanish",
                        value: "es_es"
                    }
                })], 1), e._l(e.titleData, (function(t, i) {
                    return a("div", {
                        key: i,
                        class: e.chooseHeaderIndex == i ? "headerTitleChoose" : "headerTitle",
                        on: {
                            click: function(a) {
                                return e.jumpLcation(t, i)
                            }
                        }
                    }, [a("span", [e._v(e._s(e.$t(`${t}`)))])])
                }
                )), e.showLoginId ? a("div", {
                    staticClass: "playNow btnBg",
                    on: {
                        click: function(a) {
                            return e.outLogin()
                        }
                    }
                }, [a("p", [e._v(e._s(e.showLoginId))]), a("p", [e._v(e._s(e.$t("outlogin")))])]) : a("div", {
                    staticClass: "playNow btnBg",
                    staticStyle: {
                        "line-height": "55px"
                    },
                    on: {
                        click: function(a) {
                            return e.openWebGame("email")
                        }
                    }
                }, [a("p", [e._v(e._s(e.$t("login_game")))])])], 2)])], 1)]), a("div", {
                    staticClass: "login_box"
                }, [a("el-row", {
                    staticClass: "hidden-xs-only",
                    attrs: {
                        gutter: 0
                    }
                }, [a("el-dialog", {
                    staticStyle: {
                        "border-radius": "10px"
                    },
                    attrs: {
                        visible: e.loginVisible,
                        width: "750px",
                        "before-close": e.handleClose,
                        "close-on-click-modal": !1,
                        top: "300px"
                    },
                    on: {
                        "update:visible": function(a) {
                            e.loginVisible = a
                        }
                    }
                }, [a("div", {
                    staticClass: "login_box_web"
                }, [e.top_id ? a("div", {
                    staticStyle: {
                        "margin-bottom": "10px",
                        "text-align": "center"
                    }
                }, [e._v(" " + e._s(e.$t("superior")) + "ID:" + e._s(e.top_id))]) : e._e(), a("div", {
                    staticClass: "guanbi",
                    on: {
                        click: e.handleClose
                    }
                }, [a("i", {
                    staticClass: "el-icon-close"
                })]), a("div", {
                    staticClass: "w90margin flcenter margintop_30"
                }, [a("div", {
                    staticClass: "login_phone"
                }, [e._v(e._s(e.$t("email")))]), a("el-input", {
                    staticStyle: {
                        width: "60%",
                        "margin-left": "10px"
                    },
                    attrs: {
                        type: "email",
                        placeholder: e.$t("email"),
                        maxlength: "40",
                        oninput: "if(value.length > 40) value=value.slice(0, 40)"
                    },
                    model: {
                        value: e.form.email,
                        callback: function(a) {
                            e.$set(e.form, "email", a)
                        },
                        expression: "form.email"
                    }
                })], 1), a("div", {
                    staticClass: "w90margin flcenter"
                }, [a("div", {
                    staticClass: "login_phone"
                }, [e._v(e._s(e.$t("verification_code")))]), a("div", {
                    staticClass: "code flbetween"
                }, [a("el-input", {
                    attrs: {
                        placeholder: e.$t("please_code"),
                        oninput: "if(value.length > 6) value=value.slice(0, 6)"
                    },
                    model: {
                        value: e.form.code,
                        callback: function(a) {
                            e.$set(e.form, "code", a)
                        },
                        expression: "form.code"
                    }
                }), a("div", {
                    staticClass: "send_code",
                    on: {
                        click: e.sendCode
                    }
                }, [a("p", [e._v(e._s(0 == e.time ? e.$t("get_code") : 60 == e.time ? e.$t("get_again") : `(${e.time})`))])])], 1)]), a("div", {
                    directives: [{
                        name: "loading",
                        rawName: "v-loading",
                        value: e.loginLoading,
                        expression: "loginLoading"
                    }],
                    staticClass: "login_btn btnBg",
                    on: {
                        click: function(a) {
                            return e.registered()
                        }
                    }
                }, [e._v(e._s(e.$t("register_now")))]), a("div", {
                    staticClass: "zhuce flaround margin_top_20"
                }, [a("div", {
                    staticClass: "google",
                    on: {
                        click: function(a) {
                            return e.gameOutUrl("google")
                        }
                    }
                }), a("div", {
                    staticClass: "line",
                    on: {
                        click: function(a) {
                            return e.gameOutUrl("line")
                        }
                    }
                }), a("div", {
                    staticClass: "telegram",
                    on: {
                        click: function(a) {
                            return e.gameOutUrl("telegram")
                        }
                    }
                }), a("div", {
                    staticClass: "facebook",
                    on: {
                        click: function(a) {
                            return e.gameOutUrl("facebook")
                        }
                    }
                })])])])], 1), a("el-row", {
                    staticClass: "hidden-sm-and-up",
                    attrs: {
                        gutter: 0
                    }
                }, [a("el-dialog", {
                    attrs: {
                        visible: e.loginShowVisible,
                        width: "90%",
                        "before-close": e.handleClose,
                        "close-on-click-modal": !1,
                        top: "180px"
                    },
                    on: {
                        "update:visible": function(a) {
                            e.loginShowVisible = a
                        }
                    }
                }, [a("div", {
                    staticClass: "login_box_mobile"
                }, [e.top_id ? a("div", {
                    staticStyle: {
                        "margin-bottom": "10px"
                    }
                }, [e._v(e._s(e.$t("superior")) + "ID:" + e._s(e.top_id))]) : a("div", {
                    staticStyle: {
                        height: "30px",
                        "font-size": "25px"
                    }
                }, [e._v(e._s(e.$t("email")))]), a("div", {
                    staticClass: "guanbi",
                    on: {
                        click: e.handleClose
                    }
                }, [a("i", {
                    staticClass: "el-icon-close"
                })]), a("div", {
                    staticClass: "flcenter marginTB20"
                }, [a("el-input", {
                    staticStyle: {
                        "margin-left": "10px"
                    },
                    attrs: {
                        maxlength: 11,
                        placeholder: e.$t("email"),
                        maxlength: "40",
                        oninput: "if(value.length > 40) value=value.slice(0, 40)"
                    },
                    model: {
                        value: e.form.email,
                        callback: function(a) {
                            e.$set(e.form, "email", a)
                        },
                        expression: "form.email"
                    }
                })], 1), a("div", {
                    staticClass: "code flbetween"
                }, [a("el-input", {
                    attrs: {
                        maxlength: 6,
                        placeholder: e.$t("please_code")
                    },
                    model: {
                        value: e.form.code,
                        callback: function(a) {
                            e.$set(e.form, "code", a)
                        },
                        expression: "form.code"
                    }
                }), a("div", {
                    staticClass: "send_code whiteBg",
                    on: {
                        click: e.sendCode
                    }
                }, [a("p", [e._v(e._s(0 == e.time ? e.$t("get_code") : 60 == e.time ? e.$t("get_again") : `(${e.time})`))])])], 1), a("div", {
                    staticClass: "login_btn btnBg",
                    on: {
                        click: function(a) {
                            return e.registered()
                        }
                    }
                }, [e._v(e._s(e.$t("register_now")))]), a("div", {
                    staticClass: "zhuce flaround margin_top_20"
                }, [a("div", {
                    staticClass: "google",
                    on: {
                        click: function(a) {
                            return e.gameOutUrl("google")
                        }
                    }
                }), a("div", {
                    staticClass: "line",
                    on: {
                        click: function(a) {
                            return e.gameOutUrl("line")
                        }
                    }
                }), a("div", {
                    staticClass: "telegram",
                    on: {
                        click: function(a) {
                            return e.gameOutUrl("telegram")
                        }
                    }
                }), a("div", {
                    staticClass: "facebook",
                    on: {
                        click: function(a) {
                            return e.gameOutUrl("facebook")
                        }
                    }
                })])])])], 1)], 1)], 1)
            }
              , M = []
              , A = (t(541),
            JSON.parse('[{"language_id":"","Countryname":"Hong Kong, China","codeNumber":"852"},{"language_id":"","Countryname":"Angola","codeNumber":"244"},{"language_id":"","Countryname":"Afghanistan","codeNumber":"93"},{"language_id":"","Countryname":"Albania","codeNumber":"355"},{"language_id":"","Countryname":"Algeria","codeNumber":"213"},{"language_id":"","Countryname":"Republic of Andorra","codeNumber":"376"},{"language_id":"","Countryname":"Anguilla island","codeNumber":"1264"},{"language_id":"","Countryname":"Antigua and Barbuda","codeNumber":"1268"},{"language_id":"","Countryname":"Argentina","codeNumber":"54"},{"language_id":"","Countryname":"Armenia","codeNumber":"374"},{"language_id":"","Countryname":"Ascension","codeNumber":"247"},{"language_id":"","Countryname":"Australia","codeNumber":"61"},{"language_id":"","Countryname":"Austria","codeNumber":"43"},{"language_id":"","Countryname":"Azerbaijan","codeNumber":"994"},{"language_id":"","Countryname":"Bahamas","codeNumber":"1242"},{"language_id":"","Countryname":"Bahrain","codeNumber":"973"},{"language_id":"","Countryname":"Bangladesh","codeNumber":"880"},{"language_id":"","Countryname":"Barbados","codeNumber":"1246"},{"language_id":"","Countryname":"Belarus","codeNumber":"375"},{"language_id":"nl_be","Countryname":"Belgium","codeNumber":"32"},{"language_id":"","Countryname":"Belize","codeNumber":"501"},{"language_id":"","Countryname":"Benin","codeNumber":"229"},{"language_id":"","Countryname":"Bermuda","codeNumber":"1441"},{"language_id":"","Countryname":"Bolivia","codeNumber":"591"},{"language_id":"","Countryname":"Botswana","codeNumber":"267"},{"language_id":"","Countryname":"Brazil","codeNumber":"55"},{"language_id":"","Countryname":"Brunei","codeNumber":"673"},{"language_id":"","Countryname":"Bulgaria","codeNumber":"359"},{"language_id":"","Countryname":"Burkina Faso","codeNumber":"226"},{"language_id":"","Countryname":"Burundi","codeNumber":"257"},{"language_id":"","Countryname":"Cameroon","codeNumber":"237"},{"language_id":"en_us","Countryname":"United States","codeNumber":"1"},{"language_id":"","Countryname":"Cayman Islands","codeNumber":"1345"},{"language_id":"","Countryname":"Central African Republic","codeNumber":"236"},{"language_id":"","Countryname":"Chad","codeNumber":"235"},{"language_id":"","Countryname":"Chile","codeNumber":"56"},{"language_id":"","Countryname":"Colombia","codeNumber":"57"},{"language_id":"","Countryname":"Congo","codeNumber":"242"},{"language_id":"","Countryname":"Cook Islands","codeNumber":"682"},{"language_id":"","Countryname":"Costa Rica","codeNumber":"506"},{"language_id":"","Countryname":"Cuba","codeNumber":"53"},{"language_id":"","Countryname":"Cyprus","codeNumber":"357"},{"language_id":"cs_cz","Countryname":"Czech Republic","codeNumber":"420"},{"language_id":"da_dk","Countryname":"Denmark","codeNumber":"45"},{"language_id":"","Countryname":"Djibouti","codeNumber":"253"},{"language_id":"","Countryname":"Ecuador","codeNumber":"593"},{"language_id":"","Countryname":"Egypt","codeNumber":"20"},{"language_id":"","Countryname":"El Salvador","codeNumber":"503"},{"language_id":"","Countryname":"Estonia","codeNumber":"372"},{"language_id":"","Countryname":"Ethiopia","codeNumber":"251"},{"language_id":"","Countryname":"Fiji","codeNumber":"679"},{"language_id":"fi_fi","Countryname":"Finland","codeNumber":"358"},{"language_id":"fr_fr","Countryname":"France","codeNumber":"33"},{"language_id":"","Countryname":"French Guiana","codeNumber":"594"},{"language_id":"","Countryname":"Gabon","codeNumber":"241"},{"language_id":"","Countryname":"Gambia","codeNumber":"220"},{"language_id":"","Countryname":"Georgia","codeNumber":"995"},{"language_id":"de_de","Countryname":"Germany","codeNumber":"49"},{"language_id":"","Countryname":"Ghana","codeNumber":"233"},{"language_id":"","Countryname":"Gibraltar","codeNumber":"350"},{"language_id":"el_gr","Countryname":"Greece","codeNumber":"30"},{"language_id":"","Countryname":"Grenada","codeNumber":"1473"},{"language_id":"","Countryname":"Guam","codeNumber":"1671"},{"language_id":"","Countryname":"Guatemala","codeNumber":"502"},{"language_id":"","Countryname":"guinea","codeNumber":"224"},{"language_id":"","Countryname":"Guyana","codeNumber":"592"},{"language_id":"","Countryname":"Haiti","codeNumber":"509"},{"language_id":"","Countryname":"Honduras","codeNumber":"504"},{"language_id":"hu_hu","Countryname":"Hungary","codeNumber":"36"},{"language_id":"","Countryname":"Iceland","codeNumber":"354"},{"language_id":"","Countryname":"India","codeNumber":"91"},{"language_id":"","Countryname":"Indonesia","codeNumber":"62"},{"language_id":"","Countryname":"Iran","codeNumber":"98"},{"language_id":"","Countryname":"Iraq","codeNumber":"964"},{"language_id":"","Countryname":"Ireland","codeNumber":"353"},{"language_id":"he_il","Countryname":"Israel","codeNumber":"972"},{"language_id":"it_it","Countryname":"Italy","codeNumber":"39"},{"language_id":"","Countryname":"Jamaica","codeNumber":"1876"},{"language_id":"ja_jp","Countryname":"Japan","codeNumber":"81"},{"language_id":"","Countryname":"Jordan","codeNumber":"962"},{"language_id":"ru_ru","Countryname":"Russia","codeNumber":"7"},{"language_id":"","Countryname":"Kenya","codeNumber":"254"},{"language_id":"ko_kr","Countryname":"Korea","codeNumber":"82"},{"language_id":"","Countryname":"Kuwait","codeNumber":"965"},{"language_id":"","Countryname":"Kyrgyzstan","codeNumber":"996"},{"language_id":"","Countryname":"Laos","codeNumber":"856"},{"language_id":"","Countryname":"Latvia","codeNumber":"371"},{"language_id":"","Countryname":"Lebanon","codeNumber":"961"},{"language_id":"","Countryname":"Lesotho","codeNumber":"266"},{"language_id":"","Countryname":"Liberia","codeNumber":"231"},{"language_id":"","Countryname":"Libya","codeNumber":"218"},{"language_id":"","Countryname":"Liechtenstein","codeNumber":"423"},{"language_id":"","Countryname":"Lithuania","codeNumber":"370"},{"language_id":"","Countryname":"Luxembourg","codeNumber":"352"},{"language_id":"","Countryname":"Macao (China)","codeNumber":"853"},{"language_id":"","Countryname":"Madagascar","codeNumber":"261"},{"language_id":"","Countryname":"Malawi","codeNumber":"265"},{"language_id":"","Countryname":"Malaysia","codeNumber":"60"},{"language_id":"","Countryname":"Maldives","codeNumber":"960"},{"language_id":"","Countryname":"Mali","codeNumber":"223"},{"language_id":"","Countryname":"Malta","codeNumber":"356"},{"language_id":"","Countryname":"Mariana Islands","codeNumber":"1670"},{"language_id":"","Countryname":"Martinique","codeNumber":"596"},{"language_id":"","Countryname":"Mauritius","codeNumber":"230"},{"language_id":"","Countryname":"Mexico","codeNumber":"52"},{"language_id":"","Countryname":"Moldova","codeNumber":"373"},{"language_id":"","Countryname":"Monaco","codeNumber":"377"},{"language_id":"","Countryname":"Mongolia","codeNumber":"976"},{"language_id":"","Countryname":"Montserrat","codeNumber":"1664"},{"language_id":"","Countryname":"Morocco","codeNumber":"212"},{"language_id":"","Countryname":"Mozambique","codeNumber":"258"},{"language_id":"","Countryname":"Namibia","codeNumber":"264"},{"language_id":"","Countryname":"Nauru","codeNumber":"674"},{"language_id":"","Countryname":"Nepal","codeNumber":"977"},{"language_id":"","Countryname":"Netherlands Antilles","codeNumber":"599"},{"language_id":"nl_nl","Countryname":"Netherlands","codeNumber":"31"},{"language_id":"","Countryname":"New Zealand","codeNumber":"64"},{"language_id":"","Countryname":"Nicaragua","codeNumber":"505"},{"language_id":"","Countryname":"Niger","codeNumber":"227"},{"language_id":"","Countryname":"Nigeria","codeNumber":"234"},{"language_id":"","Countryname":"North Korea","codeNumber":"850"},{"language_id":"no_no","Countryname":"Norway","codeNumber":"47"},{"language_id":"","Countryname":"Oman","codeNumber":"968"},{"language_id":"","Countryname":"Pakistan","codeNumber":"92"},{"language_id":"","Countryname":"Panama","codeNumber":"507"},{"language_id":"","Countryname":"Papua New Guinea","codeNumber":"675"},{"language_id":"","Countryname":"Paraguay","codeNumber":"595"},{"language_id":"","Countryname":"Peru","codeNumber":"51"},{"language_id":"","Countryname":"Philippines","codeNumber":"63"},{"language_id":"pl_pl","Countryname":"Poland","codeNumber":"48"},{"language_id":"","Countryname":"French Polynesia","codeNumber":"689"},{"language_id":"pt_pt","Countryname":"Portugal","codeNumber":"351"},{"language_id":"","Countryname":"Puerto Rico","codeNumber":"1787"},{"language_id":"","Countryname":"Qatar","codeNumber":"974"},{"language_id":"","Countryname":"Reunion","codeNumber":"262"},{"language_id":"","Countryname":"Romania","codeNumber":"40"},{"language_id":"ru_ru","Countryname":"Russia","codeNumber":"7"},{"language_id":"","Countryname":"Saint Lucia","codeNumber":"1758"},{"language_id":"","Countryname":"Saint Vincent island","codeNumber":"1784"},{"language_id":"","Countryname":"Eastern Samoa (United States)","codeNumber":"684"},{"language_id":"","Countryname":"Western Samoa","codeNumber":"685"},{"language_id":"","Countryname":"San Marino","codeNumber":"378"},{"language_id":"","Countryname":" Sao Tome and Principe","codeNumber":"239"},{"language_id":"","Countryname":"Saudi Arabia","codeNumber":"966"},{"language_id":"","Countryname":"Senegal","codeNumber":"221"},{"language_id":"","Countryname":"Seychelles","codeNumber":"248"},{"language_id":"","Countryname":"Sierra Leone","codeNumber":"232"},{"language_id":"","Countryname":"Singapore","codeNumber":"65"},{"language_id":"","Countryname":"Slovakia","codeNumber":"421"},{"language_id":"sl_sl","Countryname":"Slovenia","codeNumber":"386"},{"language_id":"","Countryname":"Solomon Islands","codeNumber":"677"},{"language_id":"","Countryname":"Somalia","codeNumber":"252"},{"language_id":"","Countryname":"South Africa","codeNumber":"27"},{"language_id":"es_es","Countryname":"Spain","codeNumber":"34"},{"language_id":"","Countryname":"Sri Lanka","codeNumber":"94"},{"language_id":"","Countryname":"Sudan","codeNumber":"249"},{"language_id":"","Countryname":"Suriname","codeNumber":"597"},{"language_id":"","Countryname":"Eswatini","codeNumber":"268"},{"language_id":"sv_se","Countryname":"Sweden","codeNumber":"46"},{"language_id":"","Countryname":"Switzerland","codeNumber":"41"},{"language_id":"","Countryname":"Syria","codeNumber":"963"},{"language_id":"","Countryname":"Taiwan Province (China)","codeNumber":"886"},{"language_id":"","Countryname":"Tajikistan","codeNumber":"992"},{"language_id":"","Countryname":"Tanzania","codeNumber":"255"},{"language_id":"","Countryname":"Togo","codeNumber":"228"},{"language_id":"","Countryname":"Tonga","codeNumber":"676"},{"language_id":"","Countryname":"Trinidad and Tobago","codeNumber":"1868"},{"language_id":"","Countryname":"Tunisia","codeNumber":"216"},{"language_id":"tr_tr","Countryname":"turkey","codeNumber":"90"},{"language_id":"","Countryname":"Turkmenistan","codeNumber":"993"},{"language_id":"","Countryname":"Uganda","codeNumber":"256"},{"language_id":"","Countryname":"Ukraine","codeNumber":"380"},{"language_id":"","Countryname":"UK","codeNumber":"44"},{"language_id":"en_us","Countryname":"United States","codeNumber":"1"},{"language_id":"","Countryname":"Uruguay","codeNumber":"598"},{"language_id":"","Countryname":"Uzbekistan","codeNumber":"998"},{"language_id":"","Countryname":"Venezuela","codeNumber":"58"},{"language_id":"","Countryname":"Vietnam","codeNumber":"84"},{"language_id":"","Countryname":"Yemen","codeNumber":"967"},{"language_id":"","Countryname":"Yugoslavia","codeNumber":"381"},{"language_id":"","Countryname":"Zimbabwe","codeNumber":"263"},{"language_id":"","Countryname":"Zambia","codeNumber":"260"},{"language_id":"","Countryname":"Diego Garcia island","codeNumber":"246"},{"language_id":"","Countryname":"Aruba","codeNumber":"297"},{"language_id":"","Countryname":"Bhutan","codeNumber":"975"},{"language_id":"","Countryname":"Bosnia and Herzegovina","codeNumber":"387"},{"language_id":"","Countryname":"Cape Verde","codeNumber":"238"},{"language_id":"","Countryname":"Comoros","codeNumber":"269"},{"language_id":"","Countryname":"DRC","codeNumber":"243"},{"language_id":"","Countryname":"Republic of Croatia","codeNumber":"385"},{"language_id":"","Countryname":"Dominican Republic","codeNumber":"1809"},{"language_id":"","Countryname":"Equatorial Guinea","codeNumber":"240"},{"language_id":"","Countryname":"Falkland Islands","codeNumber":"500"},{"language_id":"","Countryname":"Faroe Islands","codeNumber":"298"},{"language_id":"","Countryname":"Greenland","codeNumber":"299"},{"language_id":"","Countryname":"Guadeloupe island","codeNumber":"590"},{"language_id":"","Countryname":"Guinea Bissau","codeNumber":"245"},{"language_id":"","Countryname":"Macedonia","codeNumber":"389"},{"language_id":"","Countryname":"Mauritania","codeNumber":"222"},{"language_id":"","Countryname":"Federated States of Micronesia","codeNumber":"691"},{"language_id":"","Countryname":"Montenegro","codeNumber":"382"},{"language_id":"","Countryname":"New Caledonia","codeNumber":"687"},{"language_id":"","Countryname":"Norfolk Island","codeNumber":"6723"},{"language_id":"","Countryname":"Palau","codeNumber":"680"},{"language_id":"","Countryname":"Palestine","codeNumber":"970"},{"language_id":"","Countryname":"Republic of Rwanda","codeNumber":"250"},{"language_id":"","Countryname":"Saint Kitts and Nevis","codeNumber":"1869"},{"language_id":"","Countryname":"Serbia","codeNumber":"381"},{"language_id":"","Countryname":"South Sudan","codeNumber":"211"},{"language_id":"","Countryname":"Vanuatu","codeNumber":"678"},{"language_id":"","Countryname":"British Virgin Islands","codeNumber":"1809"},{"language_id":"","Countryname":"Republic of C ô te d\'Ivoire","codeNumber":"225"},{"language_id":"","Countryname":"Dominica","codeNumber":"1767"},{"language_id":"","Countryname":"East Timor","codeNumber":"670"},{"language_id":"","Countryname":"state of Eritrea","codeNumber":"291"},{"language_id":"","Countryname":"Wallis and Futuna Islands","codeNumber":"681"},{"language_id":"","Countryname":"Virgin Islands (United States)","codeNumber":"1340"},{"language_id":"","Countryname":"Tuvalu","codeNumber":"688"},{"language_id":"","Countryname":"Turks and Caicos Islands","codeNumber":"1809"},{"language_id":"","Countryname":"Tokelau","codeNumber":"690"},{"language_id":"","Countryname":"Marshall Islands","codeNumber":"692"},{"language_id":"","Countryname":"Kiribati","codeNumber":"686"},{"language_id":"","Countryname":"Hawaii","codeNumber":"1808"},{"language_id":"","Countryname":"Saint Pierre island and Miquelon island","codeNumber":"508"},{"language_id":"","Countryname":"Niue","codeNumber":"683"},{"language_id":"","Countryname":"St. Helena","codeNumber":"290"},{"language_id":"","Countryname":"Vatican","codeNumber":"379"},{"language_id":"","Countryname":"Wake Island (United States)","codeNumber":"1808"}]'))
              , V = t(8495)
              , P = t.n(V)
              , j = t(2300)
              , E = (t(9755),
            {
                name: "Header",
                data() {
                    return {
                        iframeUrl: "",
                        chooseHeaderIndex: 0,
                        menuDirection: "rtl",
                        titleData: ["home", "game", "question"],
                        drawerShow: !1,
                        loginVisible: !1,
                        loginShowVisible: !1,
                        language: sessionStorage.getItem("local"),
                        langShow: !1,
                        Android: !1,
                        ios: !1,
                        loginLoading: !1,
                        areaData: [],
                        form: {
                            area_code: "",
                            showarea_code: "",
                            phone: "",
                            code: "",
                            email: ""
                        },
                        top_id: "",
                        time: 0,
                        timeTwo: "",
                        sendTime: "",
                        jumpGameUrl: "",
                        signKey: "8p83fwh50kpcuj25",
                        phoneUrl: "",
                        webUrl: "",
                        androidUrl: "",
                        iosUrl: "",
                        showLoginId: "",
                        startTime: sessionStorage.getItem("startTime"),
                        codeType: !1
                    }
                },
                mounted() {
                    this.init()
                },
                methods: {
                    init() {
                        let e = window.location.href;
                        e.split("__cf_chl_rt_tk")[1] && e.split("#/home?")[1] && (window.location.href = e.split("__cf_chl_rt_tk")[0] + "#/home?" + e.split("#/home?")[1]),
                        e.split("?mibextid")[1] && e.split("#/home?")[1] && (window.location.href = "/#/home?" + e.split("#/home?")[1]),
                        e.split("?fbclid")[1] && e.split("#/home?")[1] && (window.location.href = "/#/home?" + e.split("#/home?")[1]),
                        this.advance(),
                        this.nowPage(),
                        this.whetherLogin(),
                        this.countriesList(),
                        this.timeMounted(),
                        this.getInviteCode(),
                        this.getPhoneInfo(),
                        this.getOpeninstallList(),
                        this.getLanguageUrl()
                    },
                    advance() {
                        this.setValue("s") && this.setValue("t") && this.setValue("user_id") ? (sessionStorage.setItem("outUrlType", this.setValue("t")),
                        sessionStorage.getItem("loginId") || this.registered()) : (sessionStorage.removeItem("oneUrl"),
                        sessionStorage.removeItem("outUrlType"),
                        sessionStorage.getItem("url") || sessionStorage.setItem("url", window.location.href))
                    },
                    nowPage() {
                        "/home" == this.$route.path || "/" == this.$route.path ? this.chooseHeaderIndex = 0 : "/game" == this.$route.path ? this.chooseHeaderIndex = 1 : this.chooseHeaderIndex = 2
                    },
                    isConsistent() {
                        let e = sessionStorage.getItem("oneUrl") || sessionStorage.getItem("url")
                          , a = window.location.href
                          , t = []
                          , i = [];
                        t = e.split("?"),
                        i = a.split("?"),
                        i[1] != t[1] && (sessionStorage.getItem("oneUrl") && sessionStorage.setItem("oneUrl", window.location.href),
                        sessionStorage.setItem("url", window.location.href),
                        this.outLogin())
                    },
                    whetherLogin() {
                        sessionStorage.getItem("loginId") && (this.showLoginId = sessionStorage.getItem("loginId"))
                    },
                    getOpeninstallList() {
                        let e = this.setValue("operater_id");
                        e && $({
                            operater_id: e
                        }).then((e=>{
                            200 == e.code && e.data && (e.data.android_url && (this.androidUrl = e.data.android_url),
                            e.data.web_url && (this.webUrl = e.data.web_url),
                            e.data.ios_url && (this.iosUrl = e.data.ios_url))
                        }
                        ))
                    },
                    getPhoneInfo() {
                        var e = t(2437)
                          , a = new e(navigator.userAgent);
                        "AndroidOS" == a.os() ? (this.Android = !0,
                        this.ios = !1) : "iOS" == a.os() ? (this.ios = !0,
                        this.Android = !1) : (this.ios = !1,
                        this.Android = !1)
                    },
                    countriesList() {
                        let e = A.sort((function(e, a) {
                            return e.codeNumber - a.codeNumber
                        }
                        ));
                        e.splice(1, 2),
                        this.areaData = e
                    },
                    cancalReadOnly(e) {
                        this.$refs.select && this.$nextTick((()=>{
                            if (!e) {
                                const {select: e} = this.$refs
                                  , a = e.$el.querySelector(".el-input__inner");
                                a.removeAttribute("readonly")
                            }
                        }
                        ))
                    },
                    chooseAera(e) {
                        this.form.showarea_code = "+" + e,
                        this.form.area_code = e
                    },
                    chooseLang(e) {
                        this.langShow = !1,
                        this.language = e,
                        this.$i18n.locale = e,
                        this.dealData = [],
                        sessionStorage.setItem("local", e),
                        this.$parent.$children.map(((a,t)=>{
                            a.homeChangeDeal && this.$parent.$children[t].homeChangeDeal(e),
                            a.gameChangeDeal && this.$parent.$children[t].gameChangeDeal(e),
                            a.questionChangeDeal && this.$parent.$children[t].questionChangeDeal(e)
                        }
                        ))
                    },
                    jumpLcation: m((function(e, a) {
                        this.chooseHeaderIndex = a,
                        document.documentElement.scrollTop = 0,
                        this.$router.push({
                            path: e,
                            query: this.$route.query
                        }),
                        this.drawerClose(),
                        this.handleClose()
                    }
                    ), 200),
                    gameOutUrl(e) {
                        sessionStorage.setItem("oneUrl", window.location.href),
                        sessionStorage.getItem("loginId") ? alert(this.$t("login_ing")) : window.location.href = "https://transfer.manor888.com?type=" + e
                    },
                    async getETH() {
                        if (!window.ethereum)
                            return alert(this.$t("please_install_wallet"));
                        window.web3 = new (r())(ethereum);
                        var e = window.web3;
                        await ethereum.enable();
                        var a = await e.eth.getAccounts()
                          , t = a[0];
                        console.log(t, 1)
                    },
                    openWebGame(e) {
                        if (this.dealUrlParm(),
                        this.showLoginId) {
                            let e = ""
                              , a = this.setValue("user_id") || sessionStorage.getItem("phoneCode")
                              , t = sessionStorage.getItem("outUrlType") || "email"
                              , i = parseInt((new Date).getTime() / 1e3);
                              console.log(P()),
                              console.log(this.jumpGameUrl),
                            e = "&s=" + P()(String(a) + String(i) + this.signKey) + "&i=" + a + "&time=" + i + "&t=" + t + "&gallo="+(String(a) + String(i) + this.signKey),
                            this.isUrl()
                            //this.isUrl(this.webUrl, this.jumpGameUrl + e)
                        } else
                            this.Android || this.ios ? (this.loginShowVisible = !0,
                            this.loginVisible = !1) : (this.loginVisible = !0,
                            this.loginShowVisible = !1)
                    },
                    dealUrlParm() {
                        let e = {}
                          , a = (parseInt((new Date).getTime() / 1e3),
                        this.setValue("agent_id"))
                          , t = this.setValue("operater_id")
                          , i = sessionStorage.getItem("topId")
                          , o = this.setValue("invite")
                          , n = this.setValue("language_id");
                        this.setValue("s"),
                        this.setValue("i"),
                        this.setValue("time"),
                        this.setValue("t");
                        e = {
                            operater_id: t,
                            agent_id: a,
                            language_id: n,
                            invite: o,
                            inviter_id: i
                        },
                        this.jumpGameUrl = encodeURIComponent(j.DS.encode(JSON.stringify(e)))
                    },
                    downGameNow(e) {
                        let a = parseInt((new Date).getTime() / 1e3)
                          , t = "8p83fwh50kpcuj25"
                          , i = ""
                          , o = ""
                          , n = ""
                          , s = ""
                          , r = this.setValue("agent_id")
                          , l = this.setValue("operater_id")
                          , d = sessionStorage.getItem("topId")
                          , u = this.setValue("invite")
                          , c = this.setValue("language_id");
                        i = {
                            operater_id: l,
                            agent_id: r,
                            language_id: c,
                            invite: u,
                            inviter_id: d,
                            url: sessionStorage.getItem("outUrlType") ? sessionStorage.getItem("oneUrl") : window.location.href
                        },
                        sessionStorage.getItem("outUrlType") ? (n = this.setValue("user_id"),
                        s = sessionStorage.getItem("outUrlType")) : (n = sessionStorage.getItem("phoneCode"),
                        s = "email"),
                        o = "&s=" + P()(String(n) + String(a) + t) + "&i=" + n + "&time=" + a + "&t=" + s;
                        let m = "";
                        if (m = sessionStorage.getItem("loginId") ? encodeURIComponent(j.DS.encode(JSON.stringify(i))) + o : encodeURIComponent(j.DS.encode(JSON.stringify(i))),
                        sessionStorage.getItem("loginId"))
                            switch (e) {
                            case 1:
                                this.isUrl(this.webUrl, m);
                                break;
                            case 2:
                                this.isUrl(this.androidUrl, m);
                                break;
                            case 3:
                                this.isUrl(this.iosUrl, m);
                                break
                            }
                        else
                            switch (e) {
                            case 1:
                                this.isUrl(this.webUrl, m);
                                break;
                            case 2:
                                this.isUrl(this.androidUrl, m);
                                break;
                            case 3:
                                this.isUrl(this.iosUrl, m);
                                break
                            }
                    },
                    downGame(e) {
                        if (this.showLoginId) {
                            let a = {}
                              , t = parseInt((new Date).getTime() / 1e3)
                              , i = "8p83fwh50kpcuj25"
                              , o = ""
                              , n = ""
                              , s = ""
                              , r = this.setValue("agent_id")
                              , l = this.setValue("operater_id")
                              , d = sessionStorage.getItem("topId")
                              , u = this.setValue("invite")
                              , c = this.setValue("language_id");
                            a = {
                                operater_id: l,
                                agent_id: r,
                                language_id: c,
                                invite: u,
                                inviter_id: d,
                                url: sessionStorage.getItem("outUrlType") ? sessionStorage.getItem("oneUrl") : window.location.href
                            },
                            sessionStorage.getItem("outUrlType") ? (n = this.setValue("user_id"),
                            s = sessionStorage.getItem("outUrlType")) : (n = this.form.showarea_code + String(this.form.phone),
                            s = "email"),
                            o = "&s=" + P()(String(n) + String(t) + i) + "&i=" + n + "&time=" + t + "&t=" + s;
                            let m = "";
                            switch (m = sessionStorage.getItem("loginId") ? encodeURIComponent(j.DS.encode(JSON.stringify(a))) + o : encodeURIComponent(j.DS.encode(JSON.stringify(a))),
                            e) {
                            case 1:
                                this.isUrl(this.webUrl, m);
                                break;
                            case 2:
                                this.isUrl(this.androidUrl, m);
                                break;
                            case 3:
                                this.isUrl(this.iosUrl, m);
                                break
                            }
                        } else
                            this.Android || this.ios ? (this.loginShowVisible = !0,
                            this.loginVisible = !1,
                            this.drawerShow = !1,
                            e = this.Android ? 2 : 3) : (this.loginVisible = !0,
                            this.loginShowVisible = !1)
                    },
                    isUrl(e, a) {
                        if (!e)
                            return this.setValue("operater_id") ? this.$message.error(this.$t("network_download")) : this.$message.error(this.$t("illegal_connection"));
                        this.copy(a),
                        this.Android ? window.open(e + a) : window.location.href = e + a
                    },
                    getInviteCode() {
                        let e = this.setValue("invite");
                        e && x(e).then((e=>{
                            200 == e.code && (this.top_id = e.data.invite_uid,
                            sessionStorage.setItem("topId", e.data.invite_uid))
                        }
                        ))
                    },
                    sendCode: m((function(e, a) {
                        if (this.sendTime)
                            return !1;
                        if (0 != this.time && 60 != this.time)
                            return !1;
                        0 == this.time && (this.time = 59);
                        let t = /^([a-zA-Z]|[0-9])(\w|\-)+@[a-zA-Z0-9]+\.([a-zA-Z]{2,4})$/;
                        if (!t.test(this.form.email))
                            return this.$message.error(this.$t("please_sure_email"));
                        this.getCode(),
                        this.sendTime = setInterval((()=>{
                            this.time--,
                            this.time <= 0 && (this.time = 0,
                            clearInterval(this.sendTime),
                            this.sendTime = "")
                        }
                        ), 1e3)
                    }
                    ), 200),
                    getCode: m((function(e, a) {
                        let t = this
                          , i = t.setValue("agent_id")
                          , o = t.setValue("operater_id");
                        if (!i)
                            return t.$message.error(t.$t("channel_exception"));
                        if (!o)
                            return t.$message.error(t.$t("operator_exception"));
                        let n = /^([a-zA-Z]|[0-9])(\w|\-)+@[a-zA-Z0-9]+\.([a-zA-Z]{2,4})$/;
                        if (!n.test(this.form.email))
                            return this.$message.error(this.$t("please_sure_email"));
                        B({
                            email: t.form.email,
                            agent_id: i,
                            operater_id: o,
                            mobile_prefix: t.form.showarea_code,
                            language_id: sessionStorage.getItem("local")
                        }).then((e=>{
                            200 == e.code ? (t.codeType = !0,
                            t.$message.success(t.$t("send_code"))) : t.$message.error(e.msg)
                        }
                        ))
                    }
                    ), 1e3),
                    registered: m((function() {
                        if (this.loginLoading)
                            return !1;
                        let e = this.setValue("agent_id")
                          , a = this.setValue("operater_id")
                          , t = this.setValue("invite")
                          , i = this.setValue("time")
                          , o = this.setValue("s")
                          , n = ""
                          , s = "";
                        if (sessionStorage.getItem("outUrlType"))
                            s = sessionStorage.getItem("oneUrl");
                        else {
                            let e = /^([a-zA-Z]|[0-9])(\w|\-)+@[a-zA-Z0-9]+\.([a-zA-Z]{2,4})$/;
                            if (!e.test(this.form.email))
                                return this.$message.error(this.$t("please_sure_email"));
                            if (!this.codeType)
                                return this.loginLoading = !1,
                                this.$message.error(this.$t("failed_send_code"));
                            sessionStorage.removeItem("outUrlType"),
                            sessionStorage.removeItem("oneUrl"),
                            sessionStorage.setItem("phoneCode", this.form.email),
                            s = window.location.href
                        }
                        return e ? a ? (this.loginLoading = !0,
                        n = this.setValue("user_id") && this.setValue("user_id").split("#")[0] ? this.setValue("user_id").split("#")[0] : this.setValue("user_id") && !this.setValue("user_id").split("#")[0] ? this.setValue("user_id") : sessionStorage.getItem("phoneCode"),
                        void y({
                            code: this.form.code || "",
                            mobile: this.form.phone || "",
                            agent_id: e,
                            operater_id: a,
                            invite_code: t,
                            i: n,
                            t: sessionStorage.getItem("outUrlType") || "email",
                            time: i,
                            s: o,
                            language_id: sessionStorage.getItem("local"),
                            url: encodeURIComponent(s)
                        }).then((e=>{
                            this.loginLoading = !1,
                            200 == e.code ? (this.$message.success(this.$t("login_success")),
                            this.showLoginId = e.data.userId,
                            sessionStorage.setItem("startTime", (new Date).getTime()),
                            sessionStorage.setItem("loginId", e.data.userId),
                            this.timeMounted(),
                            this.handleClose()) : this.$message.error(e.msg)
                        }
                        ))) : this.$message.error(this.$t("operator_exception")) : this.$message.error(this.$t("channel_exception"))
                    }
                    ), 1e3),
                    outLogin() {
                        clearInterval(this.timeTwo),
                        this.timeTwo = "",
                        this.time = 0,
                        this.form.phone = "",
                        this.form.code = "",
                        this.jumpGameUrl = "",
                        this.codeType = !1,
                        sessionStorage.removeItem("loginId"),
                        sessionStorage.removeItem("phoneCode"),
                        sessionStorage.removeItem("outUrlType"),
                        sessionStorage.removeItem("startTime"),
                        sessionStorage.removeItem("topId"),
                        this.showLoginId = "",
                        sessionStorage.getItem("oneUrl") && (window.location.href = sessionStorage.getItem("oneUrl"),
                        sessionStorage.removeItem("oneUrl"))
                    },
                    getLanguageUrl() {
                        let e = this.setValue("language_id");
                        e && (this.areaData.map(((a,t)=>{
                            a.language_id == e && (this.areaData.unshift(this.areaData.splice(t, 1)[0]),
                            this.form.area_code = this.areaData[0].codeNumber,
                            this.form.showarea_code = "+" + this.areaData[0].codeNumber)
                        }
                        )),
                        sessionStorage.getItem("local") || this.chooseLang(e))
                    },
                    getCookie(e) {
                        if (0 == document.cookie.length)
                            return "";
                        for (var a = e + "=", t = document.cookie.split(";"), i = 0; i < t.length; i++) {
                            var o = t[i].trim();
                            if (0 == o.indexOf(a))
                                return unescape(o.substring(a.length, o.length))
                        }
                        return ""
                    },
                    copy(e) {
                        let a = document.createElement("input");
                        a.value = e,
                        document.body.appendChild(a),
                        a.select(),
                        document.execCommand("Copy"),
                        document.body.removeChild(a)
                    },
                    timeMounted() {
                        if (sessionStorage.getItem("startTime")) {
                            let e = (new Date).getTime() - sessionStorage.getItem("startTime");
                            this.timeTwo = setInterval((()=>{
                                e > 18e5 && (this.$message.error(this.$t("login_timeout")),
                                this.outLogin())
                            }
                            ), 1e3)
                        }
                    },
                    handleClose() {
                        this.loginVisible = !1,
                        this.loginShowVisible = !1
                    },
                    drawerClose() {
                        this.drawerShow = !1
                    },
                    setValue(e) {
                        return this.getUrlParameter(e) ? this.getUrlParameter(e) : this.getLcolaOneUrlData(e) ? this.getLcolaOneUrlData(e) : this.getLcolaUrlData(e) ? this.getLcolaUrlData(e) : ""
                    },
                    getUrlParameter(e) {
                        let a = new Object;
                        return a = this.GetRequest(),
                        a[e] || ""
                    },
                    GetRequest() {
                        var e = window.location.href
                          , a = new Object;
                        let t = this.$route.path + "?";
                        if (-1 != e.indexOf(t)) {
                            let t = e.substr(0)
                              , o = t.split("?")
                              , n = o[1].split("&");
                            for (var i = 0; i < n.length; i++)
                                a[n[i].split("=")[0]] = unescape(n[i].split("=")[1])
                        }
                        return a
                    },
                    getLcolaUrlData(e) {
                        var a = sessionStorage.getItem("url")
                          , t = new Object;
                        if (a) {
                            if (-1 != a.indexOf("?")) {
                                let e = a.substr(0)
                                  , o = e.split("?")
                                  , n = o[1].split("&");
                                for (var i = 0; i < n.length; i++)
                                    t[n[i].split("=")[0]] = unescape(n[i].split("=")[1])
                            }
                            let o = new Object;
                            return o = t,
                            o[e] || ""
                        }
                    },
                    getLcolaOneUrlData(e) {
                        var a = sessionStorage.getItem("oneUrl")
                          , t = new Object;
                        if (a) {
                            if (-1 != a.indexOf("?")) {
                                let e = a.substr(0)
                                  , o = e.split("?")
                                  , n = o[1].split("&");
                                for (var i = 0; i < n.length; i++)
                                    t[n[i].split("=")[0]] = unescape(n[i].split("=")[1])
                            }
                            let o = new Object;
                            return o = t,
                            o[e] || ""
                        }
                    }
                }
            })
              , W = E
              , F = (t(348),
            t(8747),
            (0,
            T.Z)(W, G, M, !1, null, "61ba947b", null))
              , R = F.exports
              , H = {
                name: "App",
                components: {
                    Bottom: O,
                    Header: R
                },
                data() {
                    return {
                        firstComeIn: !1,
                        operaterId: ""
                    }
                },
                created() {
                    this.nowUrlPath();
                    let e = "https://" + document.domain;
                    this.getUrlParameter("operater_id") && this.getUrlParameter("agent_id") && this.getUrlParameter("language_id") ? (this.operaterId = this.setValue("operater_id"),
                    sessionStorage.getItem("firstComeIn") || (this.addAccessNumber(),
                    sessionStorage.setItem("firstComeIn", !0))) : this.addDomainInfo(e)
                },
                mounted() {
                    window.close = function() {
                        localStorage.clear(),
                        sessionStorage.clear();
                        var e = window.sessionStorage;
                        e.removeItem("loginId"),
                        e.removeItem("local"),
                        e.removeItem("phoneCode"),
                        e.removeItem("outUrlType"),
                        e.removeItem("startTime"),
                        e.removeItem("topId"),
                        e.removeItem("url"),
                        sessionStorage.getItem("oneUrl") && (window.location.href = e.getItem("oneUrl"),
                        e.removeItem("oneUrl"))
                    }
                },
                methods: {
                    nowUrlPath() {
                        "/" != this.$route.path && "/home" != this.$route.path && "/game" != this.$route.path && "/question" != this.$route.path && this.$router.push({
                            path: "home?" + this.$route.path.split("/")[1],
                            query: this.$route.query
                        })
                    },
                    addDomainInfo(e) {
                        D({
                            domain: e
                        }).then((a=>{
                            if (200 == a.code) {
                                let t = ""
                                  , i = ""
                                  , o = "";
                                t = this.setValue("operater_id") ? this.setValue("operater_id") : a.data.operater_id,
                                i = this.setValue("agent_id") ? this.setValue("agent_id") : a.data.agent_id,
                                o = this.setValue("language_id") ? this.setValue("language_id") : a.data.language_id,
                                sessionStorage.setItem("url", e + `?operater_id=${t}&agent_id=${i}&language_id=${o}`),
                                sessionStorage.setItem("local", o),
                                this.operaterId = t,
                                this.$i18n.locale = o,
                                sessionStorage.getItem("firstComeIn") || (this.addAccessNumber(),
                                sessionStorage.setItem("firstComeIn", !0))
                            }
                        }
                        ))
                    },
                    addAccessNumber() {
                        let e = this.setValue("operater_id");
                        k({
                            operater_id: e
                        }).then((e=>{
                            200 != e.code && this.$message.error(e.msg)
                        }
                        ))
                    },
                    setValue(e) {
                        return this.getUrlParameter(e) ? this.getUrlParameter(e) : this.getLcolaData(e) ? this.getLcolaData(e) : ""
                    },
                    getUrlParameter(e) {
                        let a = new Object;
                        return a = this.GetRequest(),
                        a[e] || ""
                    },
                    GetRequest() {
                        var e = window.location.href
                          , a = new Object;
                        let t = this.$route.path + "?";
                        if (-1 != e.indexOf(t)) {
                            let t = e.substr(0)
                              , o = t.split("?")
                              , n = o[1].split("&");
                            for (var i = 0; i < n.length; i++)
                                a[n[i].split("=")[0]] = unescape(n[i].split("=")[1])
                        }
                        return a
                    },
                    getLcolaData(e) {
                        var a = sessionStorage.getItem("url")
                          , t = new Object;
                        if (a) {
                            if (-1 != a.indexOf("?")) {
                                let e = a.substr(0)
                                  , o = e.split("?")
                                  , n = o[1].split("&");
                                for (var i = 0; i < n.length; i++)
                                    t[n[i].split("=")[0]] = unescape(n[i].split("=")[1])
                            }
                            let o = new Object;
                            return o = t,
                            o[e] || ""
                        }
                    }
                }
            }
              , Z = H
              , K = (t(636),
            (0,
            T.Z)(Z, o, n, !1, null, null, null))
              , J = K.exports
              , Y = (t(2578),
            t(4912),
            t(9219),
            t(7822))
              , Q = t(8345)
              , X = function() {
                var e = this
                  , a = e._self._c;
                return a("div", [a("el-row", {
                    staticClass: "hidden-xs-only",
                    attrs: {
                        gutter: 0
                    }
                }, [a("div", {
                    staticClass: "home_web"
                }, [a("img", {
                    staticClass: "logo",
                    attrs: {
                        src: "https://farm-res.s3.ap-southeast-1.amazonaws.com/web/assets/LOGO.png",
                        alt: ""
                    }
                }), a("div", {
                    staticClass: "downGame"
                }, [a("div", {
                    staticClass: "webGame",
                    on: {
                        click: function(a) {
                            return e.homeOpenWebGame("phone")
                        }
                    }
                }, [e._v("WEB")]), a("div", {
                    staticClass: "androidGame",
                    on: {
                        click: function(a) {
                            return e.homeDownGameNow(2)
                        }
                    }
                }, [e._v("Android")]), a("div", {
                    staticClass: "iosGame",
                    on: {
                        click: function(a) {
                            return e.homeDownGameNow(3)
                        }
                    }
                }, [e._v("IOS")])]), a("div", {
                    staticClass: "downQr"
                }, [a("div", {
                    ref: "qrCodeDiv",
                    attrs: {
                        id: "qrCode"
                    }
                })]), a("div", {
                    staticClass: "content_bg"
                }, [a("img", {
                    staticClass: "contentLogo",
                    attrs: {
                        src: "https://farm-res.s3.ap-southeast-1.amazonaws.com/web/assets/content_logo.png",
                        alt: ""
                    }
                }), a("div", {
                    staticClass: "btnBox flcenter"
                }, [a("div", {
                    staticClass: "playGame whiteBg"
                }, [a("p", [e._v(e._s(e.showData[0] || 0))]), a("p", {
                    staticStyle: {
                        color: "#78798d"
                    }
                }, [e._v(e._s(e.$t("all_visitors")))])]), a("div", {
                    staticClass: "playGame whiteBg"
                }, [a("p", [e._v(e._s(e.showData[1] || 0))]), a("p", {
                    staticStyle: {
                        color: "#78798d"
                    }
                }, [e._v(e._s(e.$t("all_withdrawal")))])]), a("div", {
                    staticClass: "playGame whiteBg"
                }, [a("p", [e._v(e._s(e.showData[2] || 0))]), a("p", {
                    staticStyle: {
                        color: "#78798d"
                    }
                }, [e._v(e._s(e.$t("quarterly_new_users")))])])])]), e.activityData.length > 0 && e.activityData.length < 4 ? a("div", {
                    staticClass: "content_activity w80margin flcenter"
                }, e._l(e.activityData, (function(t, i) {
                    return a("div", {
                        key: i,
                        staticClass: "activity whiteBg"
                    }, [a("img", {
                        attrs: {
                            src: t.pic || "https://farm-res.s3.ap-southeast-1.amazonaws.com/web/assets/gonggao.png",
                            alt: ""
                        }
                    }), a("div", {
                        staticClass: "padding_20 textLeft"
                    }, [a("p", [e._v(e._s(t.send_time))]), a("p", {
                        staticClass: "text-cut7",
                        staticStyle: {
                            "margin-top": "10px",
                            color: "#33344D"
                        }
                    }, [e._v(e._s(t.content))])])])
                }
                )), 0) : e._e(), e.activityData.length > 3 ? a("div", {
                    staticClass: "content_activity w80margin"
                }, [a("vue-seamless-scroll", {
                    staticClass: "seamless-warp2",
                    attrs: {
                        data: e.activityData,
                        "class-option": e.activityLeft
                    }
                }, [a("ul", {
                    staticClass: "flitem"
                }, e._l(e.activityData, (function(t, i) {
                    return a("li", {
                        key: i,
                        staticClass: "activity whiteBg",
                        staticStyle: {
                            display: "inline-block"
                        },
                        attrs: {
                            "data-index": i
                        }
                    }, [a("img", {
                        attrs: {
                            src: t.pic || "https://farm-res.s3.ap-southeast-1.amazonaws.com/web/assets/gonggao.png",
                            alt: ""
                        }
                    }), a("div", {
                        staticClass: "padding_10 textLeft",
                        staticStyle: {
                            width: "100%",
                            height: "40%"
                        }
                    }, [a("p", [e._v(e._s(t.send_time))]), a("p", {
                        staticClass: "text-cut7",
                        staticStyle: {
                            "margin-top": "10px",
                            color: "#33344D",
                            overflow: "hidden"
                        }
                    }, [e._v(e._s(t.content))])])])
                }
                )), 0)])], 1) : e._e(), a("div", {
                    staticClass: "content_deal whiteBg textLeft w80margin padding_10 margin_30 flitem"
                }, [a("img", {
                    staticClass: "horn",
                    attrs: {
                        src: "https://farm-res.s3.ap-southeast-1.amazonaws.com/web/assets/horn.png",
                        alt: ""
                    }
                }), a("vue-seamless-scroll", {
                    staticClass: "seamless-warp2",
                    attrs: {
                        data: e.dealData,
                        "class-option": e.dealLeft
                    }
                }, ["zh_cn" == e.language ? a("div", {
                    staticClass: "item"
                }, e._l(e.dealData, (function(t, i) {
                    return a("div", {
                        key: i,
                        staticClass: "deal"
                    }, [e._v(" " + e._s(e.hideName(t.nickname)) + " 以"), a("span", {
                        staticStyle: {
                            color: "#e37135",
                            "font-weight": "600"
                        }
                    }, [e._v(e._s(t.price))]), a("span", {
                        directives: [{
                            name: "show",
                            rawName: "v-show",
                            value: -2 == t.price_mode_id,
                            expression: "item.price_mode_id==-2"
                        }]
                    }, [e._v(e._s(e.$t("shell_coin")))]), a("span", {
                        directives: [{
                            name: "show",
                            rawName: "v-show",
                            value: -7 == t.price_mode_id,
                            expression: "item.price_mode_id==-7"
                        }]
                    }, [e._v(e._s(e.$t("gem")))]), e._v(" 的价格出售了 " + e._s(t.num) + "份 " + e._s(t.message[e.language]) + " ,获得价值"), a("span", {
                        staticStyle: {
                            color: "#92ff64"
                        }
                    }, [e._v(" " + e._s(e.keepFour(t.price / t.rate)) + " USDT")]), e._v("的 "), a("span", {
                        directives: [{
                            name: "show",
                            rawName: "v-show",
                            value: -2 == t.price_mode_id,
                            expression: "item.price_mode_id==-2"
                        }]
                    }, [e._v(e._s(e.$t("shell_coin")))]), a("span", {
                        directives: [{
                            name: "show",
                            rawName: "v-show",
                            value: -7 == t.price_mode_id,
                            expression: "item.price_mode_id==-7"
                        }]
                    }, [e._v(e._s(e.$t("gem")))])])
                }
                )), 0) : a("div", {
                    staticClass: "item"
                }, e._l(e.dealData, (function(t, i) {
                    return a("div", {
                        key: i,
                        staticClass: "deal"
                    }, [e._v(" " + e._s(e.hideName(t.nickname)) + " sold "), a("span", {
                        staticStyle: {
                            color: "#e37135",
                            "font-weight": "600"
                        }
                    }, [e._v(e._s(t.price) + " ")]), a("span", {
                        directives: [{
                            name: "show",
                            rawName: "v-show",
                            value: -2 == t.price_mode_id,
                            expression: "item.price_mode_id==-2"
                        }]
                    }, [e._v(e._s(e.$t("shell_coin")))]), a("span", {
                        directives: [{
                            name: "show",
                            rawName: "v-show",
                            value: -7 == t.price_mode_id,
                            expression: "item.price_mode_id==-7"
                        }]
                    }, [e._v(e._s(e.$t("gem")))]), e._v(" at the price of " + e._s(t.num) + " getting " + e._s(t.message[e.language]) + " "), a("span", {
                        staticStyle: {
                            color: "#92ff64"
                        }
                    }, [e._v("of the value " + e._s(e.keepFour(t.price / t.rate)) + " USDT ")]), a("span", {
                        directives: [{
                            name: "show",
                            rawName: "v-show",
                            value: -2 == t.price_mode_id,
                            expression: "item.price_mode_id==-2"
                        }]
                    }, [e._v(e._s(e.$t("shell_coin")))]), a("span", {
                        directives: [{
                            name: "show",
                            rawName: "v-show",
                            value: -7 == t.price_mode_id,
                            expression: "item.price_mode_id==-7"
                        }]
                    }, [e._v(e._s(e.$t("gem")))])])
                }
                )), 0)])], 1), a("div", {
                    staticClass: "content_market w80margin whiteBg textLeft padding_20"
                }, [a("p", {
                    staticClass: "marginTB10"
                }, [e._v(e._s(e.$t("market_tips")))]), a("div", {
                    staticClass: "flitem"
                }, [a("p", [e._v(e._s(e.$t("today_price")) + ":")]), a("img", {
                    staticClass: "sellIcon",
                    attrs: {
                        src: e.sellIcon,
                        alt: ""
                    }
                }), a("div", {
                    staticClass: "currency text-cut"
                }, [-2 == e.currencyMoment ? a("img", {
                    attrs: {
                        src: "https://farm-res.s3.ap-southeast-1.amazonaws.com/web/assets/shell.png",
                        alt: ""
                    }
                }) : a("img", {
                    attrs: {
                        src: "https://farm-res.s3.ap-southeast-1.amazonaws.com/web/assets/gem.png",
                        alt: ""
                    }
                }), e._v(" " + e._s(e.currencyPrice) + " ")]), a("div", {
                    staticClass: "sellOut btnBg textCenter",
                    on: {
                        click: function(a) {
                            return e.homeOpenWebGame("phone")
                        }
                    }
                }, [e._v(e._s(e.$t("sell")))])]), a("div", {
                    staticClass: "flbetween"
                }, [e.iosShow || e.androidShow ? e._e() : a("div", {
                    staticStyle: {
                        width: "95%",
                        height: "500px"
                    }
                }, [a("echart", {
                    attrs: {
                        title: e.$t("selling_price"),
                        graphType: e.marketIndex,
                        graphData: 1 == e.marketIndex ? e.graphDataDay : 2 == e.marketIndex ? e.graphDataMonth : e.graphDataYear
                    }
                })], 1), a("div", {
                    staticClass: "btnLine textCenter"
                }, [a("div", {
                    staticClass: "btnBg",
                    class: 1 == e.marketIndex ? "btnChooseBg" : "",
                    on: {
                        click: function(a) {
                            return e.chooseGrapgData(1)
                        }
                    }
                }, [e._v(e._s(e.$t("days")) + " K")]), a("div", {
                    staticClass: "btnBg",
                    class: 2 == e.marketIndex ? "btnChooseBg" : "",
                    on: {
                        click: function(a) {
                            return e.chooseGrapgData(2)
                        }
                    }
                }, [e._v(e._s(e.$t("months")) + " K")]), a("div", {
                    staticClass: "btnBg",
                    class: 3 == e.marketIndex ? "btnChooseBg" : "",
                    on: {
                        click: function(a) {
                            return e.chooseGrapgData(3)
                        }
                    }
                }, [e._v(e._s(e.$t("years")) + " K")]), 1 != e.marketIndex ? a("div", {
                    staticClass: "line_k flbetween"
                }, [a("img", {
                    attrs: {
                        src: "https://farm-res.s3.ap-southeast-1.amazonaws.com/web/assets/red_line.png",
                        alt: ""
                    }
                }), a("span", [e._v("MIN")])]) : e._e(), 1 != e.marketIndex ? a("div", {
                    staticClass: "line_k flbetween"
                }, [a("img", {
                    attrs: {
                        src: "https://farm-res.s3.ap-southeast-1.amazonaws.com/web/assets/green_line.png",
                        alt: ""
                    }
                }), a("span", [e._v("MAX")])]) : e._e()])]), a("div", {
                    staticClass: "prop_type w83",
                    on: {
                        click: e.chooseProp
                    }
                }, [a("vue-seamless-scroll", {
                    staticClass: "seamless-warp2",
                    attrs: {
                        data: e.propDataList,
                        "class-option": e.optionLeft
                    }
                }, [a("ul", {
                    staticClass: "flitem"
                }, e._l(e.propDataList, (function(t, i) {
                    return a("li", {
                        key: i,
                        staticClass: "prop_item textCenter",
                        class: e.propIndex == i ? "propChoose" : "",
                        staticStyle: {
                            display: "inline-block"
                        },
                        attrs: {
                            "data-index": i
                        }
                    }, [a("img", {
                        attrs: {
                            src: t.icon,
                            alt: ""
                        }
                    }), a("p", {
                        staticClass: "w100 text-cut"
                    }, [e._v(e._s(t.item_price))])])
                }
                )), 0)])], 1)]), a("div", {
                    staticClass: "introduction_game"
                }, [a("div", {
                    staticClass: "iconOne"
                }, [a("img", {
                    attrs: {
                        src: "https://farm-res.s3.ap-southeast-1.amazonaws.com/web/assets/animal1.png",
                        alt: ""
                    }
                })]), a("div", {
                    staticStyle: {
                        height: "160px"
                    }
                }), a("div", {
                    staticClass: "introduction_title w80margin margin_30"
                }, [e._v(e._s(e.$t("content_introduce")))]), a("div", {
                    staticClass: "introduction_info w80margin flaround textCenter"
                }, e._l(e.allData, (function(t, i) {
                    return a("div", {
                        key: i,
                        staticClass: "whiteBg"
                    }, [a("p", {
                        staticClass: "pinkColor text-cut"
                    }, [0 == i ? a("span", [e._v("+")]) : e._e(), 2 == i ? a("span", [e._v("$")]) : e._e(), e._v(" " + e._s(t.data || 1e7) + " ")]), a("p", [0 == i ? a("span", [e._v(e._s(e.$t("user")))]) : e._e(), 1 == i ? a("span", [e._v(e._s(e.$t("countries")))]) : e._e(), 2 == i ? a("span", [e._v(e._s(e.$t("volume")))]) : e._e()])])
                }
                )), 0), a("div", {
                    staticClass: "market_deal whiteBg w80margin margin_30"
                }, [a("img", {
                    attrs: {
                        src: "https://farm-res.s3.ap-southeast-1.amazonaws.com/web/assets/market_deal_bg.png",
                        alt: ""
                    }
                }), a("div", {
                    staticClass: "deal_text textCenter",
                    class: "zh_cn" == e.language ? "zhDeal" : ""
                }, [a("p", {
                    staticClass: "deal_title"
                }, [e._v(e._s(e.$t("free_market")))]), a("p", {
                    staticClass: "flitem"
                }, [a("img", {
                    attrs: {
                        src: "https://farm-res.s3.ap-southeast-1.amazonaws.com/web/assets/pink_yuan.png",
                        alt: ""
                    }
                }), e._v(e._s(e.$t("store_buy")))]), a("p", {
                    staticClass: "flitem"
                }, [a("img", {
                    attrs: {
                        src: "https://farm-res.s3.ap-southeast-1.amazonaws.com/web/assets/pink_yuan.png",
                        alt: ""
                    }
                }), e._v(e._s(e.$t("fram_pasture")))]), a("p", {
                    staticClass: "flitem"
                }, [a("img", {
                    attrs: {
                        src: "https://farm-res.s3.ap-southeast-1.amazonaws.com/web/assets/pink_yuan.png",
                        alt: ""
                    }
                }), e._v(e._s(e.$t("free_product")))]), a("div", {
                    staticClass: "btnBg w55margin",
                    class: "en_us" == e.language ? "manor" : "inDeal",
                    staticStyle: {
                        "z-index": "1000"
                    },
                    on: {
                        click: function(a) {
                            return e.homeOpenWebGame("phone")
                        }
                    }
                }, [e._v(" " + e._s(e.$t("manor")) + " ")])])])])])]), a("el-row", {
                    staticClass: "hidden-sm-and-up",
                    attrs: {
                        gutter: 0
                    }
                }, [a("div", {
                    staticClass: "home_mobile"
                }, [a("img", {
                    staticClass: "logo_mobile",
                    attrs: {
                        src: "https://farm-res.s3.ap-southeast-1.amazonaws.com/web/assets/LOGO.png",
                        alt: ""
                    }
                }), a("div", {
                    staticClass: "content_bg"
                }, [a("img", {
                    staticClass: "contentLogo",
                    attrs: {
                        src: "https://farm-res.s3.ap-southeast-1.amazonaws.com/web/assets/content_logo.png",
                        alt: ""
                    }
                }), a("div", {
                    staticClass: "contentLogo_height"
                }), a("div", {
                    staticClass: "btnBox flcenter"
                }, [e.iosShow ? a("div", {
                    staticClass: "playGame btnBg",
                    on: {
                        click: function(a) {
                            return e.copy()
                        }
                    }
                }, [e._v(" IOS ")]) : e._e(), e.androidShow ? a("div", {
                    staticClass: "playGame btnBg",
                    on: {
                        click: function(a) {
                            return e.homeDownGameNow(2)
                        }
                    }
                }, [e._v(" Android ")]) : e._e()])]), e.activityData.length > 0 ? a("div", {
                    staticClass: "content_activity"
                }, [a("vue-seamless-scroll", {
                    staticClass: "seamless-warp2",
                    attrs: {
                        data: e.activityData,
                        "class-option": e.activityLeft
                    }
                }, [a("ul", {
                    staticClass: "flitem"
                }, e._l(e.activityData, (function(t, i) {
                    return a("li", {
                        key: i,
                        staticClass: "activity whiteBg",
                        staticStyle: {
                            display: "inline-block"
                        },
                        attrs: {
                            "data-index": i
                        }
                    }, [a("img", {
                        attrs: {
                            src: t.pic || "https://farm-res.s3.ap-southeast-1.amazonaws.com/web/assets/gonggao.png",
                            alt: ""
                        }
                    }), a("div", {
                        staticClass: "padding_10 textLeft"
                    }, [a("p", [e._v(e._s(t.send_time))]), a("p", {
                        staticClass: "text-cut5",
                        staticStyle: {
                            "margin-top": "10px",
                            color: "#33344D"
                        }
                    }, [e._v(e._s(t.content))])])])
                }
                )), 0)])], 1) : e._e(), a("div", {
                    staticClass: "content_deal whiteBg textLeft padding_10 margin_30 flitem"
                }, [a("img", {
                    staticClass: "horn",
                    attrs: {
                        src: "https://farm-res.s3.ap-southeast-1.amazonaws.com/web/assets/horn.png",
                        alt: ""
                    }
                }), a("vue-seamless-scroll", {
                    staticClass: "seamless-warp2",
                    attrs: {
                        data: e.dealData,
                        "class-option": e.dealLeft
                    }
                }, ["zh_cn" == e.language ? a("div", {
                    staticClass: "item"
                }, e._l(e.dealData, (function(t, i) {
                    return a("div", {
                        key: i,
                        staticClass: "deal"
                    }, [e._v(" " + e._s(e.hideName(t.nickname)) + " 以"), a("span", {
                        staticStyle: {
                            color: "#e37135"
                        }
                    }, [e._v(e._s(t.price))]), a("span", {
                        directives: [{
                            name: "show",
                            rawName: "v-show",
                            value: -2 == t.price_mode_id,
                            expression: "item.price_mode_id==-2"
                        }]
                    }, [e._v(e._s(e.$t("shell_coin")))]), a("span", {
                        directives: [{
                            name: "show",
                            rawName: "v-show",
                            value: -7 == t.price_mode_id,
                            expression: "item.price_mode_id==-7"
                        }]
                    }, [e._v(e._s(e.$t("gem")))]), e._v(" 的价格出售了 " + e._s(t.num) + "份 " + e._s(t.message[e.language]) + " ,获得价值"), a("span", {
                        staticStyle: {
                            color: "#92ff64"
                        }
                    }, [e._v(" " + e._s(e.keepFour(t.price / t.rate)) + " USDT")]), e._v("的 "), a("span", {
                        directives: [{
                            name: "show",
                            rawName: "v-show",
                            value: -2 == t.price_mode_id,
                            expression: "item.price_mode_id==-2"
                        }]
                    }, [e._v(e._s(e.$t("shell_coin")))]), a("span", {
                        directives: [{
                            name: "show",
                            rawName: "v-show",
                            value: -7 == t.price_mode_id,
                            expression: "item.price_mode_id==-7"
                        }]
                    }, [e._v(e._s(e.$t("gem")))])])
                }
                )), 0) : a("div", {
                    staticClass: "item"
                }, e._l(e.dealData, (function(t, i) {
                    return a("div", {
                        key: i,
                        staticClass: "deal"
                    }, [e._v(" " + e._s(e.hideName(t.nickname)) + " sold "), a("span", {
                        staticStyle: {
                            color: "#e37135"
                        }
                    }, [e._v(e._s(t.price) + " ")]), a("span", {
                        directives: [{
                            name: "show",
                            rawName: "v-show",
                            value: -2 == t.price_mode_id,
                            expression: "item.price_mode_id==-2"
                        }]
                    }, [e._v(e._s(e.$t("shell_coin")))]), a("span", {
                        directives: [{
                            name: "show",
                            rawName: "v-show",
                            value: -7 == t.price_mode_id,
                            expression: "item.price_mode_id==-7"
                        }]
                    }, [e._v(e._s(e.$t("gem")))]), e._v(" at the price of " + e._s(t.num) + " getting " + e._s(t.message[e.language]) + " "), a("span", {
                        staticStyle: {
                            color: "#92ff64"
                        }
                    }, [e._v("of the value " + e._s(e.keepFour(t.price / t.rate)) + " USDT ")]), a("span", {
                        directives: [{
                            name: "show",
                            rawName: "v-show",
                            value: -2 == t.price_mode_id,
                            expression: "item.price_mode_id==-2"
                        }]
                    }, [e._v(e._s(e.$t("shell_coin")))]), a("span", {
                        directives: [{
                            name: "show",
                            rawName: "v-show",
                            value: -7 == t.price_mode_id,
                            expression: "item.price_mode_id==-7"
                        }]
                    }, [e._v(e._s(e.$t("gem")))])])
                }
                )), 0)])], 1), a("div", {
                    staticClass: "content_market whiteBg textLeft"
                }, [a("div", {
                    staticClass: "padding_10"
                }, [a("p", {
                    staticClass: "marginTB10"
                }, [e._v(e._s(e.$t("market_tips")))]), a("div", {
                    staticClass: "flitem"
                }, [a("p", [e._v(e._s(e.$t("today_price")) + ":")]), a("img", {
                    staticClass: "sellIcon",
                    attrs: {
                        src: e.sellIcon,
                        alt: ""
                    }
                }), a("div", {
                    staticClass: "currency text-cut"
                }, [-2 == e.currencyMoment ? a("img", {
                    attrs: {
                        src: "https://farm-res.s3.ap-southeast-1.amazonaws.com/web/assets/shell.png",
                        alt: ""
                    }
                }) : a("img", {
                    attrs: {
                        src: "https://farm-res.s3.ap-southeast-1.amazonaws.com/web/assets/gem.png",
                        alt: ""
                    }
                }), e._v(" " + e._s(e.currencyPrice) + " ")]), a("div", {
                    staticClass: "sellOut btnBg textCenter",
                    on: {
                        click: function(a) {
                            return e.homeOpenWebGame("phone")
                        }
                    }
                }, [e._v(e._s(e.$t("sell")))])])]), a("div", {
                    staticClass: "textCenter"
                }, [a("div", {
                    staticClass: "btnLine textCenter flaround"
                }, [a("div", {
                    staticClass: "btnBg",
                    class: 1 == e.marketIndex ? "btnChooseBg" : "",
                    on: {
                        click: function(a) {
                            return e.chooseGrapgData(1)
                        }
                    }
                }, [e._v(e._s(e.$t("days")) + " K")]), a("div", {
                    staticClass: "btnBg",
                    class: 2 == e.marketIndex ? "btnChooseBg" : "",
                    on: {
                        click: function(a) {
                            return e.chooseGrapgData(2)
                        }
                    }
                }, [e._v(e._s(e.$t("months")) + " K")]), a("div", {
                    staticClass: "btnBg",
                    class: 3 == e.marketIndex ? "btnChooseBg" : "",
                    on: {
                        click: function(a) {
                            return e.chooseGrapgData(3)
                        }
                    }
                }, [e._v(e._s(e.$t("years")) + " K")])]), a("div", {
                    staticClass: "flcenter"
                }, [a("div", {
                    staticClass: "line_k flbetween"
                }, [a("img", {
                    attrs: {
                        src: "https://farm-res.s3.ap-southeast-1.amazonaws.com/web/assets/red_line.png",
                        alt: ""
                    }
                }), a("span", [e._v("MIN")])]), 1 != e.marketIndex ? a("div", {
                    staticClass: "line_k flbetween"
                }, [a("img", {
                    attrs: {
                        src: "https://farm-res.s3.ap-southeast-1.amazonaws.com/web/assets/green_line.png",
                        alt: ""
                    }
                }), a("span", [e._v("MAX")])]) : e._e()]), e.iosShow || e.androidShow ? a("div", {
                    staticStyle: {
                        width: "100%",
                        height: "300px"
                    }
                }, [a("echart", {
                    attrs: {
                        title: e.$t("selling_price"),
                        graphType: e.marketIndex,
                        graphData: 1 == e.marketIndex ? e.graphDataDay : 2 == e.marketIndex ? e.graphDataMonth : e.graphDataYear
                    }
                })], 1) : e._e()]), a("div", {
                    staticClass: "prop_type",
                    on: {
                        click: e.chooseProp
                    }
                }, [a("vue-seamless-scroll", {
                    staticClass: "seamless-warp2",
                    attrs: {
                        data: e.propDataList,
                        "class-option": e.optionLeft
                    }
                }, [a("ul", {
                    staticClass: "flitem"
                }, e._l(e.propDataList, (function(t, i) {
                    return a("li", {
                        key: i,
                        staticClass: "prop_item textCenter",
                        staticStyle: {
                            display: "inline-block"
                        },
                        attrs: {
                            "data-index": i
                        }
                    }, [a("div", {
                        staticClass: "prop_img",
                        class: e.propIndex == i ? "propChoose" : ""
                    }, [a("img", {
                        attrs: {
                            src: t.icon,
                            alt: ""
                        }
                    })]), a("p", {
                        staticClass: "w100 text-cut"
                    }, [e._v(e._s(t.item_price))])])
                }
                )), 0)])], 1)]), a("div", {
                    staticClass: "introduction_game"
                }, [a("div", {
                    staticClass: "iconOne"
                }, [a("img", {
                    attrs: {
                        src: "https://farm-res.s3.ap-southeast-1.amazonaws.com/web/assets/animal1.png",
                        alt: ""
                    }
                })]), a("div", {
                    staticClass: "introduction_title"
                }, [e._v(e._s(e.$t("content_introduce")))]), a("div", {
                    staticClass: "introduction_info flaround textCenter"
                }, e._l(e.allData, (function(t, i) {
                    return a("div", {
                        key: i,
                        staticClass: "whiteBg"
                    }, [a("p", {
                        staticClass: "pinkColor text-cut"
                    }, [0 == i ? a("span", [e._v("+")]) : e._e(), 2 == i ? a("span", [e._v("$")]) : e._e(), e._v(" " + e._s(t.data || 1e7) + " ")]), a("p", {
                        staticClass: "text-cut"
                    }, [0 == i ? a("span", [e._v(e._s(e.$t("user")))]) : e._e(), 1 == i ? a("span", [e._v(e._s(e.$t("countries")))]) : e._e(), 2 == i ? a("span", [e._v(e._s(e.$t("volume")))]) : e._e()])])
                }
                )), 0), a("div", {
                    staticClass: "market_deal margin_30"
                }, [a("img", {
                    attrs: {
                        src: "https://farm-res.s3.ap-southeast-1.amazonaws.com/web/assets/market_deal_bg.png",
                        alt: ""
                    }
                }), a("div", {
                    staticClass: "deal_text textCenter"
                }, [a("p", {
                    staticClass: "deal_title"
                }, [e._v(e._s(e.$t("free_market")))]), a("p", [e._v(e._s(e.$t("store_buy")))]), a("p", [e._v(e._s(e.$t("fram_pasture")))]), a("p", [e._v(e._s(e.$t("free_product")))]), a("div", {
                    staticClass: "manor w55margin"
                })])])])])])], 1)
            }
              , ee = []
              , ae = t(7418)
              , te = t.n(ae)
              , ie = function() {
                var e = this
                  , a = e._self._c;
                return a("div", {
                    staticClass: "echart marginTB10",
                    staticStyle: {
                        width: "100%",
                        height: "100%"
                    },
                    attrs: {
                        id: "mychart"
                    }
                })
            }
              , oe = []
              , ne = {
                data() {
                    return {
                        DateData: [],
                        MinData: [],
                        MaxData: []
                    }
                },
                props: {
                    graphData: {
                        type: Array
                    },
                    graphType: {
                        type: Number
                    },
                    title: {
                        type: String
                    }
                },
                watch: {
                    graphData() {
                        this.DateData = [],
                        this.MinData = [],
                        this.MaxData = [],
                        this.graphData && this.refreshData()
                    },
                    graphType() {}
                },
                mounted() {
                    this.initEcharts()
                },
                methods: {
                    refreshData() {
                        this.graphData.map((e=>{
                            this.DateData.push(e.Date),
                            this.MinData.push(e.MinPrice),
                            1 != this.graphType && this.MaxData.push(e.MaxPrice)
                        }
                        )),
                        this.initEcharts()
                    },
                    initEcharts() {
                        var e = document.getElementById("mychart")
                          , a = Y.init(e);
                        window.addEventListener("resize", (()=>{
                            a.resize()
                        }
                        )),
                        a.setOption({
                            title: {
                                text: this.title
                            },
                            tooltip: {
                                trigger: "axis",
                                axisPointer: {
                                    type: "cross",
                                    label: {
                                        backgroundColor: "#6a7985"
                                    }
                                }
                            },
                            grid: {
                                left: "3%",
                                right: "4%",
                                bottom: "3%",
                                containLabel: !0
                            },
                            xAxis: [{
                                type: "category",
                                boundaryGap: !1,
                                data: this.DateData
                            }],
                            yAxis: [{
                                type: "value"
                            }],
                            series: [{
                                name: "MIN",
                                type: "line",
                                itemStyle: {
                                    color: "red"
                                },
                                data: this.MinData
                            }, {
                                name: "MAX",
                                type: "line",
                                stack: "Total",
                                itemStyle: {
                                    color: "green"
                                },
                                data: this.MaxData
                            }]
                        })
                    },
                    getWeekDataList() {
                        let e = 864e5
                          , a = new Date
                          , t = a.getDay() || 7
                          , i = new Date(a.getTime() - e * (t - 1))
                          , o = [];
                        for (let n = 0; n < 7; n++) {
                            let a = new Date(i.getTime() + n * e)
                              , t = (a.getFullYear(),
                            a.getMonth() + 1 < 10 ? "0" + (a.getMonth() + 1) : a.getMonth() + 1)
                              , s = a.getDate() < 10 ? "0" + a.getDate() : a.getDate();
                            o[n] = `${t}/${s}`
                        }
                        return o
                    }
                }
            }
              , se = ne
              , re = (0,
            T.Z)(se, ie, oe, !1, null, null, null)
              , le = re.exports
              , de = {
                components: {
                    vueSeamlessScroll: te(),
                    Echart: le,
                    Bottom: O
                },
                data() {
                    return {
                        language: sessionStorage.getItem("local"),
                        activityData: [],
                        dealData: [],
                        marketIndex: 1,
                        propDataList: [],
                        propIndex: -1,
                        sellIcon: "https://farm-phpadmin.c98.xyz/icon/item/101.png",
                        androidShow: !1,
                        iosShow: !1,
                        currencyMoment: -2,
                        currencyPrice: 15.26,
                        allData: [{
                            data: ""
                        }, {
                            data: "190+"
                        }, {
                            data: "65345345454"
                        }],
                        graphDataDay: [],
                        graphDataMonth: [],
                        graphDataYear: [],
                        showData: [],
                        showLoginId: "",
                        iosUrl: ""
                    }
                },
                computed: {
                    hideName(e) {
                        return e=>{
                            if (e) {
                                let a = e.slice(0, 2)
                                  , t = e.slice(-2);
                                return a + "****" + t
                            }
                        }
                    },
                    keepFour(e) {
                        return e=>(e = Number(e),
                        1e4 * e.toFixed(4) / 1e4)
                    },
                    dealLeft() {
                        return {
                            step: .3,
                            limitMoveNum: this.dealData.length,
                            hoverStop: !1,
                            direction: 1,
                            openWatch: !0,
                            openTouch: !1,
                            singleHeight: 0,
                            singleWidth: 0,
                            waitTime: 1e3
                        }
                    },
                    activityLeft() {
                        return {
                            step: .2,
                            limitMoveNum: this.activityData.length,
                            hoverStop: !0,
                            direction: 2,
                            openWatch: !0,
                            openTouch: !1,
                            singleHeight: 0,
                            singleWidth: 0,
                            waitTime: 8e3
                        }
                    },
                    optionLeft() {
                        return {
                            step: .3,
                            limitMoveNum: this.propDataList.length,
                            hoverStop: !1,
                            direction: 2,
                            openWatch: !0,
                            openTouch: !1,
                            singleHeight: 0,
                            singleWidth: 0,
                            waitTime: 1e3
                        }
                    }
                },
                mounted() {
                    this.init()
                },
                methods: {
                    init() {
                        this.homeBindQRCode(),
                        this.getGraphList(),
                        this.getPropList(),
                        this.getDealList(),
                        this.whetherLogin(),
                        this.getActivityList(),
                        this.getPhoneInfo(),
                        this.getOpeninstallList()
                    },
                    whetherLogin() {
                        sessionStorage.getItem("loginId") && (this.showLoginId = sessionStorage.getItem("loginId"))
                    },
                    homeBindQRCode() {
                        let e = ""
                          , a = "https://" + document.domain;
                        document.getElementById("qrCode").innerHTML = "",
                        D({
                            domain: a
                        }).then((t=>{
                            if (200 == t.code) {
                                let i = ""
                                  , o = ""
                                  , n = "";
                                i = this.setValue("operater_id") ? this.setValue("operater_id") : t.data.operater_id,
                                o = this.setValue("agent_id") ? this.setValue("agent_id") : t.data.agent_id,
                                n = this.setValue("language_id") ? this.setValue("language_id") : t.data.language_id,
                                e = this.setValue("invite") && this.setValue("inviter_id") ? a + `#/home?operater_id=${i}&agent_id=${o}&language_id=${n}&invite=${this.setValue("invite")}&inviter_id=${this.setValue("inviter_id")}` : this.setValue("invite") ? a + `#/home?operater_id=${i}&agent_id=${o}&language_id=${n}&invite=${this.setValue("invite")}` : this.setValue("inviter_id") ? a + `#/home?operater_id=${i}&agent_id=${o}&language_id=${n}&inviter_id=${this.setValue("inviter_id")}` : a + `#/home?operater_id=${i}&agent_id=${o}&language_id=${n}`
                            } else
                                e = window.location.href;
                            new (c())(this.$refs.qrCodeDiv,{
                                text: e,
                                width: 95,
                                height: 95,
                                colorDark: "#333333",
                                colorLight: "#ffffff",
                                correctLevel: c().CorrectLevel.L
                            })
                        }
                        ))
                    },
                    scrollFn() {
                        var e = document.querySelector(".animationBox");
                        window.onscroll = function() {
                            var a = document.body.scrollTop || window.pageYOffset || document.documentElement.scrollTop;
                            a >= 800 && e.classList.add("animationStart")
                        }
                    },
                    getPropList() {
                        let e = this.setValue("operater_id");
                        e && S({
                            operater_id: e
                        }).then((e=>{
                            200 == e.code ? (this.propDataList = e.data.item_data,
                            e.data.all_reg_count < 1e6 && (e.data.all_reg_count = 1e6),
                            this.allData[0].data = e.data.all_reg_count,
                            this.allData[2].data = e.data.get_market_order_count,
                            this.showData.push(e.data.visit_count, e.data.get_cash_money, e.data.quarter_reg_count)) : this.$message.error(e.msg)
                        }
                        ))
                    },
                    chooseProp(e) {
                        const a = e.target.closest(".prop_item");
                        if (a) {
                            const {index: e} = a.dataset;
                            this.sellIcon = this.propDataList[e].icon,
                            this.propIndex = e,
                            this.getGraphList(this.propDataList[e].item_id)
                        }
                    },
                    getGraphList(e) {
                        let a = this
                          , t = this.setValue("operater_id");
                        t && I({
                            operater_id: t,
                            item_id: e || 101
                        }).then((e=>{
                            200 == e.code ? (e.data.today_data && (a.currencyMoment = e.data.today_data.currency_mode_id,
                            a.currencyPrice = e.data.today_data.price),
                            e.data.data && (a.graphDataDay = e.data.data.DayPrice,
                            a.graphDataMonth = e.data.data.MonthPrice,
                            a.graphDataYear = e.data.data.YearPrice)) : a.$message.error(e.msg)
                        }
                        ))
                    },
                    chooseGrapgData(e) {
                        this.marketIndex = e
                    },
                    getActivityList() {
                        let e = this.setValue("operater_id");
                        e && C({
                            operater_id: e
                        }).then((e=>{
                            200 == e.code ? (this.activityData = [],
                            e.data.length > 3 ? this.activityData = e.data.splice(0, 3) : this.activityData = e.data) : this.$message.error(e.msg)
                        }
                        ))
                    },
                    getDealList() {
                        let e = this.setValue("operater_id");
                        e && N({
                            operater_id: e,
                            page: 1,
                            size: 50
                        }).then((e=>{
                            200 == e.code ? (this.dealData = [],
                            this.dealData = e.data) : this.$message.error(e.msg)
                        }
                        ))
                    },
                    getOpeninstallList() {
                        let e = this.setValue("operater_id");
                        e && $({
                            operater_id: e
                        }).then((e=>{
                            localStorage.removeItem("url"),
                            200 == e.code && e.data && e.data.ios_url && (this.iosUrl = e.data.ios_url)
                        }
                        ))
                    },
                    homeChangeDeal(e) {
                        this.dealData = [],
                        this.language = e,
                        this.getDealList(),
                        this.getGraphList()
                    },
                    getPhoneInfo(e) {
                        var a = t(2437)
                          , i = new a(navigator.userAgent);
                        "AndroidOS" == i.os() ? (this.androidShow = !0,
                        this.iosShow = !1) : "iOS" == i.os() && (this.androidShow = !1,
                        this.iosShow = !0)
                    },
                    homeOpenWebGame(e) {
                        this.$parent.$children.map(((a,t)=>{
                            a.openWebGame && this.$parent.$children[t].openWebGame(e)
                        }
                        ))
                    },
                    homeOutWebGame(e) {
                        this.$parent.$children.map(((e,a)=>{
                            e.outLogin && this.$parent.$children[a].outLogin()
                        }
                        ))
                    },
                    homeDownGameNow: m((function(e, a, t) {
                        (this.Android || this.ios) && (e = this.Android ? 2 : 3),
                        this.$parent.$children.map(((a,t)=>{
                            a.openWebGame && this.$parent.$children[t].downGameNow(e)
                        }
                        ))
                    }
                    ), 1e3),
                    copy() {
                        let e = parseInt((new Date).getTime() / 1e3)
                          , a = "8p83fwh50kpcuj25"
                          , t = ""
                          , i = ""
                          , o = ""
                          , n = ""
                          , s = this.setValue("agent_id")
                          , r = this.setValue("operater_id")
                          , l = this.top_id ? this.top_id : sessionStorage.getItem("topId") ? sessionStorage.getItem("topId") : ""
                          , d = this.setValue("invite")
                          , u = this.setValue("language_id");
                        t = {
                            operater_id: r,
                            agent_id: s,
                            language_id: u,
                            invite: d,
                            inviter_id: l
                        },
                        sessionStorage.getItem("outUrlType") ? (o = this.setValue("user_id"),
                        n = sessionStorage.getItem("outUrlType")) : (o = sessionStorage.getItem("phoneCode"),
                        n = "phone"),
                        i = "&s=" + P()(String(o) + String(e) + a) + "&i=" + o + "&time=" + e + "&t=" + n;
                        var c = "";
                        c = sessionStorage.getItem("loginId") ? encodeURIComponent(j.DS.encode(JSON.stringify(t))) + i : encodeURIComponent(j.DS.encode(JSON.stringify(t)));
                        let m = document.createElement("input");
                        return m.value = c,
                        document.body.appendChild(m),
                        m.select(),
                        navigator.userAgent.match(/(iPhone|iPod|iPad);?/i) && (document.execCommand("Copy") || m.setSelectionRange(0, m.value.length)),
                        document.execCommand("Copy"),
                        document.body.removeChild(m),
                        this.iosUrl ? (window.location.href = this.iosUrl + c,
                        new Promise(((e,a)=>{
                            document.execCommand("Copy") ? e(c) : a(c)
                        }
                        ))) : this.setValue("operater_id") ? this.$message.error(this.$t("network_download")) : this.$message.error(this.$t("illegal_connection"))
                    },
                    setValue(e) {
                        return this.getUrlParameter(e) ? this.getUrlParameter(e) : this.getLcolaOneUrlData(e) ? this.getLcolaOneUrlData(e) : this.getLcolaUrlData(e) ? this.getLcolaUrlData(e) : ""
                    },
                    getLcolaUrlData(e) {
                        var a = sessionStorage.getItem("url")
                          , t = new Object;
                        if (a) {
                            if (-1 != a.indexOf("?")) {
                                let e = a.substr(0)
                                  , o = e.split("?")
                                  , n = o[1].split("&");
                                for (var i = 0; i < n.length; i++)
                                    t[n[i].split("=")[0]] = unescape(n[i].split("=")[1])
                            }
                            let o = new Object;
                            return o = t,
                            o[e] || ""
                        }
                    },
                    getLcolaOneUrlData(e) {
                        var a = sessionStorage.getItem("oneUrl")
                          , t = new Object;
                        if (a) {
                            if (-1 != a.indexOf("?")) {
                                let e = a.substr(0)
                                  , o = e.split("?")
                                  , n = o[1].split("&");
                                for (var i = 0; i < n.length; i++)
                                    t[n[i].split("=")[0]] = unescape(n[i].split("=")[1])
                            }
                            let o = new Object;
                            return o = t,
                            o[e] || ""
                        }
                    },
                    getUrlParameter(e) {
                        let a = new Object;
                        return a = this.GetRequest(),
                        a[e] || ""
                    },
                    GetRequest() {
                        var e = window.location.href
                          , a = new Object;
                        if (-1 != e.indexOf("?")) {
                            let i = e.substr(0)
                              , o = i.split("?")
                              , n = o[1].split("&");
                            for (var t = 0; t < n.length; t++)
                                a[n[t].split("=")[0]] = unescape(n[t].split("=")[1])
                        }
                        return a
                    }
                }
            }
              , ue = de
              , ce = (t(9835),
            (0,
            T.Z)(ue, X, ee, !1, null, "62cb1345", null))
              , me = ce.exports
              , ge = function() {
                var e = this
                  , a = e._self._c;
                return a("div", [a("el-row", {
                    staticClass: "hidden-xs-only",
                    attrs: {
                        gutter: 0
                    }
                }, [a("div", {
                    staticClass: "game_web"
                }, [a("img", {
                    staticClass: "logo",
                    attrs: {
                        src: "https://farm-res.s3.ap-southeast-1.amazonaws.com/web/assets/LOGO.png",
                        alt: ""
                    }
                }), a("div", {
                    staticClass: "carousel w60margin"
                }, [a("div", {
                    staticClass: "game_title textLeft margin_30"
                }, [e._v(e._s(e.$t("game_about")))]), a("el-carousel", {
                    ref: "carouselWeb",
                    attrs: {
                        "indicator-position": "none",
                        arrow: "never",
                        height: "500px"
                    },
                    on: {
                        change: e.changeWebIndic
                    }
                }, e._l(e.carouselWebData, (function(t, i) {
                    return a("el-carousel-item", {
                        key: i
                    }, [a("div", {
                        staticClass: "flbetween"
                    }, e._l(t.oneCarouse, (function(t, i) {
                        return a("div", {
                            key: i,
                            staticClass: "carousel_item textLeft"
                        }, [a("img", {
                            attrs: {
                                src: t.pic,
                                alt: ""
                            }
                        }), a("div", {
                            staticClass: "carousel_content"
                        }, [a("p", {
                            staticClass: "carousel_title marginTB15"
                        }, [e._v(e._s(t.title))]), a("p", {
                            staticClass: "fontWeight_normal"
                        }, [e._v(e._s(t.text))])])])
                    }
                    )), 0)])
                }
                )), 1), a("div", {
                    staticClass: "indicator flbetween w30"
                }, [a("div", {
                    staticClass: "direction_img",
                    staticStyle: {
                        transform: "rotate(180deg)"
                    },
                    on: {
                        click: e.chooseWebPrev
                    }
                }), a("div", {
                    staticClass: "flitem"
                }, e._l(e.carouselWebData.length, (function(t, i) {
                    return a("div", {
                        staticClass: "indicator_item",
                        class: e.chooseWebIndic == i ? "indicator_choose" : "",
                        on: {
                            click: function(a) {
                                return e.chooseIndicatorWeb(i)
                            }
                        }
                    })
                }
                )), 0), a("div", {
                    staticClass: "direction_img",
                    on: {
                        click: e.chooseWebNext
                    }
                })])], 1), a("div", {
                    staticClass: "new_box"
                }, [a("div", {
                    staticClass: "newBack textLeft",
                    style: {
                        background: `url(${e.chooseBackUrl})`
                    }
                }, [a("div", {
                    staticClass: "flbetween_item"
                }, [a("div", {
                    staticClass: "w60margin game_title",
                    staticStyle: {
                        color: "#FFFFFF"
                    }
                }, [e._v(e._s(e.$t("game_features")))]), a("img", {
                    staticClass: "new_logo",
                    attrs: {
                        src: "https://farm-res.s3.ap-southeast-1.amazonaws.com/web/assets/animal3.png",
                        alt: ""
                    }
                })]), a("div", {
                    staticClass: "newContent whiteBg"
                }, [a("el-carousel", {
                    ref: "introduce",
                    attrs: {
                        autoplay: !1,
                        "indicator-position": "none",
                        arrow: "never",
                        height: "300px"
                    }
                }, e._l(e.featuresBgData, (function(t, i) {
                    return a("el-carousel-item", {
                        key: i
                    }, [a("p", {
                        staticClass: "new_title margin_20"
                    }, [e._v(e._s(t.title))]), a("p", {
                        staticClass: "fontWeight_normal"
                    }, [e._v(e._s(t.text))])])
                }
                )), 1), a("div", {
                    staticClass: "newIndicator flbetween w30"
                }, [a("div", {
                    staticClass: "direction_img",
                    staticStyle: {
                        transform: "rotate(180deg)"
                    },
                    on: {
                        click: e.chooseLeft
                    }
                }), a("div", {
                    staticClass: "direction_img",
                    on: {
                        click: e.chooseRight
                    }
                }), a("div", {
                    staticClass: "flitem"
                }, e._l(e.featuresBgData.length, (function(t, i) {
                    return a("div", {
                        staticClass: "indicator_item",
                        class: e.featuresIndex == i ? "indicator_choose" : "",
                        on: {
                            click: function(a) {
                                return e.chooseFimg(i)
                            }
                        }
                    })
                }
                )), 0)])], 1)])])])]), a("el-row", {
                    staticClass: "hidden-sm-and-up",
                    attrs: {
                        gutter: 0
                    }
                }, [a("div", {
                    staticClass: "game_mobile"
                }, [a("img", {
                    staticClass: "logo_mobile",
                    attrs: {
                        src: "https://farm-res.s3.ap-southeast-1.amazonaws.com/web/assets/LOGO.png",
                        alt: ""
                    }
                }), a("div", {
                    staticClass: "carousel"
                }, [a("div", {
                    staticClass: "game_title textLeft margin_30"
                }, [e._v(e._s(e.$t("game_about")))]), a("el-carousel", {
                    ref: "carousel",
                    attrs: {
                        "indicator-position": "none",
                        arrow: "never",
                        height: "440px"
                    },
                    on: {
                        change: e.changeMobIndic
                    }
                }, e._l(e.carouselMobileData, (function(t, i) {
                    return a("el-carousel-item", {
                        key: i,
                        staticClass: "carousel_item textLeft"
                    }, [a("img", {
                        attrs: {
                            src: t.pic,
                            alt: ""
                        }
                    }), a("div", {
                        staticClass: "carousel_content"
                    }, [a("p", {
                        staticClass: "carousel_title marginTB15"
                    }, [e._v(e._s(t.title))]), a("p", {
                        staticClass: "fontWeight_normal"
                    }, [e._v(e._s(t.text))])])])
                }
                )), 1), a("div", {
                    staticClass: "indicator flbetween w50margin"
                }, [a("div", {
                    staticClass: "flitem"
                }, e._l(e.carouselMobileData.length, (function(t, i) {
                    return a("div", {
                        staticClass: "indicator_item",
                        class: e.chooseMobIndic == i ? "indicator_choose" : "",
                        on: {
                            click: function(a) {
                                return e.chooseIndicatorMob(i)
                            }
                        }
                    })
                }
                )), 0)])], 1), a("div", {
                    staticClass: "new_box"
                }, [a("div", {
                    staticClass: "game_title textLeft margin_30",
                    staticStyle: {
                        color: "#FFFFFF"
                    }
                }, [e._v(e._s(e.$t("game_features")))]), a("div", {
                    staticClass: "newContent"
                }, e._l(e.featuresBgData, (function(t, i) {
                    return a("div", {
                        key: i,
                        staticClass: "newContent_item whiteBg"
                    }, [a("p", {
                        staticClass: "new_title margin_20"
                    }, [e._v(e._s(t.title))]), a("p", {
                        staticClass: "fontWeight_normal textLeft paddingLR10"
                    }, [e._v(e._s(t.text))]), a("img", {
                        attrs: {
                            src: t.url,
                            alt: ""
                        }
                    })])
                }
                )), 0)])])])], 1)
            }
              , pe = []
              , he = {
                data() {
                    return {
                        loading: !0,
                        chooseBackUrl: "",
                        chooseWebIndic: 0,
                        chooseMobIndic: 0,
                        chooseIndiCar: 0,
                        featuresIndex: 0,
                        carouselWebData: [{
                            oneCarouse: [{
                                pic: "https://farm-res.s3.ap-southeast-1.amazonaws.com/web/assets/about_game/cultivation.png",
                                title: this.$t("cultivation"),
                                text: this.$t("cultivation_text")
                            }, {
                                pic: "https://farm-res.s3.ap-southeast-1.amazonaws.com/web/assets/about_game/building.png",
                                title: this.$t("building"),
                                text: this.$t("building_text")
                            }]
                        }, {
                            oneCarouse: [{
                                pic: "https://farm-res.s3.ap-southeast-1.amazonaws.com/web/assets/about_game/cultivate.png",
                                title: this.$t("cultivate"),
                                text: this.$t("cultivate_text")
                            }, {
                                pic: "https://farm-res.s3.ap-southeast-1.amazonaws.com/web/assets/about_game/statue.png",
                                title: this.$t("statue"),
                                text: this.$t("statue_text")
                            }]
                        }, {
                            oneCarouse: [{
                                pic: "https://farm-res.s3.ap-southeast-1.amazonaws.com/web/assets/about_game/family.png",
                                title: this.$t("family"),
                                text: this.$t("family_text")
                            }]
                        }],
                        carouselMobileData: [{
                            pic: "https://farm-res.s3.ap-southeast-1.amazonaws.com/web/assets/about_game/cultivation.png",
                            title: this.$t("cultivation"),
                            text: this.$t("cultivation_text")
                        }, {
                            pic: "https://farm-res.s3.ap-southeast-1.amazonaws.com/web/assets/about_game/building.png",
                            title: this.$t("building"),
                            text: this.$t("building_text")
                        }, {
                            pic: "https://farm-res.s3.ap-southeast-1.amazonaws.com/web/assets/about_game/cultivate.png",
                            title: this.$t("cultivate"),
                            text: this.$t("cultivate_text")
                        }, {
                            pic: "https://farm-res.s3.ap-southeast-1.amazonaws.com/web/assets/about_game/statue.png",
                            title: this.$t("statue"),
                            text: this.$t("statue_text")
                        }, {
                            pic: "https://farm-res.s3.ap-southeast-1.amazonaws.com/web/assets/about_game/family.png",
                            title: this.$t("family"),
                            text: this.$t("family_text")
                        }],
                        featuresBgData: [{
                            url: "https://farm-res.s3.ap-southeast-1.amazonaws.com/web/assets/about_game/animal_bg.png",
                            title: this.$t("animal"),
                            text: this.$t("animal_text")
                        }, {
                            url: "https://farm-res.s3.ap-southeast-1.amazonaws.com/web/assets/about_game/pasture_bg.png",
                            title: this.$t("pasture"),
                            text: this.$t("pasture_text")
                        }, {
                            url: "https://farm-res.s3.ap-southeast-1.amazonaws.com/web/assets/about_game/farm_bg.png",
                            title: this.$t("farm"),
                            text: this.$t("farm_text")
                        }, {
                            url: "https://farm-res.s3.ap-southeast-1.amazonaws.com/web/assets/about_game/plant_bg.png",
                            title: this.$t("plant"),
                            text: this.$t("plant_text")
                        }]
                    }
                },
                mounted() {
                    this.loading = !1,
                    this.chooseBackUrl = this.featuresBgData[0].url
                },
                methods: {
                    changeWebIndic(e) {
                        this.chooseWebIndic = e
                    },
                    changeMobIndic(e) {
                        this.chooseMobIndic = e
                    },
                    chooseIndicatorWeb(e) {
                        this.chooseWebIndic = e,
                        this.$refs.carouselWeb.setActiveItem(this.chooseWebIndic)
                    },
                    chooseIndicatorMob: m((function(e, a, t) {
                        this.chooseMobIndic = e,
                        this.$refs.carousel.setActiveItem(this.chooseMobIndic)
                    }
                    ), 200),
                    chooseWebPrev: m((function(e, a) {
                        this.chooseWebIndic < 2 ? (this.chooseWebIndic++,
                        this.$refs.carouselWeb.prev()) : (this.chooseWebIndic = 0,
                        this.$refs.carouselWeb.prev())
                    }
                    ), 200),
                    chooseWebNext: m((function(e, a) {
                        this.chooseWebIndic < 2 ? (this.chooseWebIndic++,
                        this.$refs.carouselWeb.next()) : (this.chooseWebIndic = 0,
                        this.$refs.carouselWeb.next())
                    }
                    ), 200),
                    changeBack(e) {
                        this.chooseBackUrl = e
                    },
                    chooseFimg(e) {
                        this.featuresIndex = e,
                        this.featuresIndex = e,
                        this.chooseBackUrl = this.featuresBgData[e].url,
                        this.$refs.introduce.setActiveItem(this.featuresIndex)
                    },
                    chooseLeft: m((function(e, a) {
                        this.featuresIndex > 0 ? (this.featuresIndex--,
                        this.featuresIndex = this.featuresIndex,
                        this.$refs.introduce.prev(),
                        this.changeBack(this.featuresBgData[this.featuresIndex].url)) : (this.featuresIndex = 3,
                        this.$refs.introduce.prev(),
                        this.changeBack(this.featuresBgData[this.featuresIndex].url))
                    }
                    ), 200),
                    chooseRight: m((function(e, a) {
                        this.featuresIndex < 3 ? (this.featuresIndex++,
                        this.$refs.introduce.next(),
                        this.changeBack(this.featuresBgData[this.featuresIndex].url)) : (this.featuresIndex = 0,
                        this.$refs.introduce.next(),
                        this.changeBack(this.featuresBgData[this.featuresIndex].url))
                    }
                    ), 200),
                    gameChangeDeal() {
                        this.carouselWebData = [{
                            oneCarouse: [{
                                pic: "https://farm-res.s3.ap-southeast-1.amazonaws.com/web/assets/about_game/cultivation.png",
                                title: this.$t("cultivation"),
                                text: this.$t("cultivation_text")
                            }, {
                                pic: "https://farm-res.s3.ap-southeast-1.amazonaws.com/web/assets/about_game/building.png",
                                title: this.$t("building"),
                                text: this.$t("building_text")
                            }]
                        }, {
                            oneCarouse: [{
                                pic: "https://farm-res.s3.ap-southeast-1.amazonaws.com/web/assets/about_game/cultivate.png",
                                title: this.$t("cultivate"),
                                text: this.$t("cultivate_text")
                            }, {
                                pic: "https://farm-res.s3.ap-southeast-1.amazonaws.com/web/assets/about_game/statue.png",
                                title: this.$t("statue"),
                                text: this.$t("statue_text")
                            }]
                        }, {
                            oneCarouse: [{
                                pic: "https://farm-res.s3.ap-southeast-1.amazonaws.com/web/assets/about_game/family.png",
                                title: this.$t("family"),
                                text: this.$t("family_text")
                            }]
                        }],
                        this.carouselMobileData = [{
                            pic: "https://farm-res.s3.ap-southeast-1.amazonaws.com/web/assets/about_game/cultivation.png",
                            title: this.$t("cultivation"),
                            text: this.$t("cultivation_text")
                        }, {
                            pic: "https://farm-res.s3.ap-southeast-1.amazonaws.com/web/assets/about_game/building.png",
                            title: this.$t("building"),
                            text: this.$t("building_text")
                        }, {
                            pic: "https://farm-res.s3.ap-southeast-1.amazonaws.com/web/assets/about_game/cultivate.png",
                            title: this.$t("cultivate"),
                            text: this.$t("cultivate_text")
                        }, {
                            pic: "https://farm-res.s3.ap-southeast-1.amazonaws.com/web/assets/about_game/statue.png",
                            title: this.$t("statue"),
                            text: this.$t("statue_text")
                        }, {
                            pic: "https://farm-res.s3.ap-southeast-1.amazonaws.com/web/assets/about_game/family.png",
                            title: this.$t("family"),
                            text: this.$t("family_text")
                        }],
                        this.featuresBgData = [{
                            url: "https://farm-res.s3.ap-southeast-1.amazonaws.com/web/assets/about_game/animal_bg.png",
                            title: this.$t("animal"),
                            text: this.$t("animal_text")
                        }, {
                            url: "https://farm-res.s3.ap-southeast-1.amazonaws.com/web/assets/about_game/pasture_bg.png",
                            title: this.$t("pasture"),
                            text: this.$t("pasture_text")
                        }, {
                            url: "https://farm-res.s3.ap-southeast-1.amazonaws.com/web/assets/about_game/farm_bg.png",
                            title: this.$t("farm"),
                            text: this.$t("farm_text")
                        }, {
                            url: "https://farm-res.s3.ap-southeast-1.amazonaws.com/web/assets/about_game/plant_bg.png",
                            title: this.$t("plant"),
                            text: this.$t("plant_text")
                        }]
                    }
                }
            }
              , be = he
              , _e = (t(152),
            (0,
            T.Z)(be, ge, pe, !1, null, "69125d5a", null))
              , fe = _e.exports
              , we = function() {
                var e = this
                  , a = e._self._c;
                return a("div", [a("el-row", {
                    staticClass: "hidden-xs-only",
                    attrs: {
                        gutter: 0
                    }
                }, [a("div", {
                    staticClass: "question_web"
                }, [a("img", {
                    staticClass: "logo",
                    attrs: {
                        src: "https://farm-res.s3.ap-southeast-1.amazonaws.com/web/assets/LOGO.png",
                        alt: ""
                    }
                }), a("div", {
                    staticClass: "question_title"
                }, [e._v(e._s(e.$t("question")))]), a("div", {
                    staticClass: "question_box whiteBg w60margin margin_30"
                }, [a("img", {
                    staticClass: "question_logo",
                    attrs: {
                        src: "https://farm-res.s3.ap-southeast-1.amazonaws.com/web/assets/animal4.png",
                        alt: ""
                    }
                }), e._l(e.questionData, (function(t, i) {
                    return a("div", {
                        key: i,
                        staticClass: "problem_item",
                        on: {
                            click: function(a) {
                                return e.chooseItem(i)
                            }
                        }
                    }, [a("div", {
                        staticClass: "problem_title flbetween"
                    }, [a("p", [e._v(e._s(t.title))]), a("img", {
                        staticClass: "down_img",
                        class: e.questionIndex == i ? "down" : "",
                        attrs: {
                            src: "https://farm-res.s3.ap-southeast-1.amazonaws.com/web/assets/down.png",
                            alt: ""
                        }
                    })]), e.questionIndex == i ? a("div", {
                        staticClass: "fontWeight_normal paddingLR20"
                    }, [e._v(" " + e._s(t.text) + " ")]) : e._e()])
                }
                ))], 2)])]), a("el-row", {
                    staticClass: "hidden-sm-and-up",
                    attrs: {
                        gutter: 0
                    }
                }, [a("div", {
                    staticClass: "question_mobile"
                }, [a("img", {
                    staticClass: "logo_mobile",
                    attrs: {
                        src: "https://farm-res.s3.ap-southeast-1.amazonaws.com/web/assets/LOGO.png",
                        alt: ""
                    }
                }), a("div", {
                    staticClass: "question_title"
                }, [e._v(e._s(e.$t("question")))]), a("div", {
                    staticClass: "question_box whiteBg"
                }, [a("img", {
                    staticClass: "question_logo",
                    attrs: {
                        src: "https://farm-res.s3.ap-southeast-1.amazonaws.com/web/assets/animal4.png",
                        alt: ""
                    }
                }), e._l(e.questionData, (function(t, i) {
                    return a("div", {
                        key: i,
                        staticClass: "problem_item",
                        on: {
                            click: function(a) {
                                return e.chooseItem(i)
                            }
                        }
                    }, [a("div", {
                        staticClass: "problem_title flbetween"
                    }, [a("p", [e._v(e._s(t.title))]), a("img", {
                        staticClass: "down_img",
                        class: e.questionIndex == i ? "down" : "",
                        attrs: {
                            src: "https://farm-res.s3.ap-southeast-1.amazonaws.com/web/assets/down.png",
                            alt: ""
                        }
                    })]), e.questionIndex == i ? a("div", {
                        staticClass: "fontWeight_normal paddingLR20"
                    }, [e._v(" " + e._s(t.text) + " ")]) : e._e()])
                }
                ))], 2)])])], 1)
            }
              , ve = []
              , xe = {
                data() {
                    return {
                        questionData: [{
                            title: this.$t("question1"),
                            text: this.$t("answer1")
                        }, {
                            title: this.$t("question2"),
                            text: this.$t("answer2")
                        }, {
                            title: this.$t("question3"),
                            text: this.$t("answer3")
                        }, {
                            title: this.$t("question4"),
                            text: this.$t("answer4")
                        }, {
                            title: this.$t("question5"),
                            text: this.$t("answer5")
                        }, {
                            title: this.$t("question6"),
                            text: this.$t("answer6")
                        }, {
                            title: this.$t("question7"),
                            text: this.$t("answer7")
                        }, {
                            title: this.$t("question8"),
                            text: this.$t("answer8")
                        }, {
                            title: this.$t("question9"),
                            text: this.$t("answer9")
                        }],
                        questionIndex: -1
                    }
                },
                mounted() {},
                methods: {
                    chooseItem(e) {
                        e == this.questionIndex ? this.questionIndex = -1 : this.questionIndex = e
                    },
                    questionChangeDeal() {
                        this.questionData = [{
                            title: this.$t("question1"),
                            text: this.$t("answer1")
                        }, {
                            title: this.$t("question2"),
                            text: this.$t("answer2")
                        }, {
                            title: this.$t("question3"),
                            text: this.$t("answer3")
                        }, {
                            title: this.$t("question4"),
                            text: this.$t("answer4")
                        }, {
                            title: this.$t("question5"),
                            text: this.$t("answer5")
                        }, {
                            title: this.$t("question6"),
                            text: this.$t("answer6")
                        }, {
                            title: this.$t("question7"),
                            text: this.$t("answer7")
                        }, {
                            title: this.$t("question8"),
                            text: this.$t("answer8")
                        }, {
                            title: this.$t("question9"),
                            text: this.$t("answer9")
                        }]
                    }
                }
            }
              , ye = xe
              , ke = (t(6969),
            (0,
            T.Z)(ye, we, ve, !1, null, "f0d20430", null))
              , Ce = ke.exports;
            i["default"].use(Q.ZP);
            const Ne = [{
                path: "/",
                component: me
            }, {
                path: "/home",
                component: me
            }, {
                path: "/game",
                component: fe
            }, {
                path: "/question",
                component: Ce
            }]
              , Ie = new Q.ZP({
                mode: "hash",
                routes: Ne
            });
            var Se = Ie
              , $e = t(9742)
              , ze = t(7152)
              , De = {
                login: "登录",
                outlogin: "退出登录",
                home: "主页",
                game: "关于游戏",
                game_about: "关于游戏",
                game_features: "新的玩法",
                question: "常见问题",
                market: "市场",
                introduce: "介绍",
                hall: "大厅",
                content_title: "BeeFarm是一款基于区块链技术的模拟经营农场游戏",
                content_text: "玩家可以在市场内自由交易，已经拥有100万用户注册了BeeFarm",
                content_introduce: "BeeFarm打造了“社交游戏体验”的盈利模式",
                login_game: "登陆游戏",
                dowm_game: "下载APP",
                sell: "卖出",
                days: "天",
                months: "月",
                years: "年",
                market_tips: "开市时间 9:00-24:00 每天开盘时生成今日收购价",
                today_price: "售价",
                selling_price: "售价曲线图",
                greate_ffree_account: "创建账户",
                all_visitors: "总访客",
                all_withdrawal: "总提现金额",
                quarterly_new_users: "季度新增用户",
                gem: "宝石",
                shell_coin: "贝壳币",
                price_sold: "的价格出售了",
                order_to: "以",
                part: "份",
                der: "的",
                get_value: "获得价值",
                value: "价值",
                sell: "出货",
                buy: "收货",
                each: "每份",
                free_market: "可以在市场内自由交易",
                store_buy: "在商店购买种子或者幼崽",
                fram_pasture: "在农场或牧场经行种植或养殖",
                free_product: "获得的产品在市场自由交易",
                manor: "开启您的庄园之旅",
                trade: "进行交易",
                download_family: "下载移动版，去市场自由自在交易，与家族成员畅玩",
                superior: "上级",
                phone: "手机",
                email: "邮箱",
                area_code: "区号选择",
                please_phone: "请输入手机号",
                please_phone_sure: "请输入正确的手机号格式",
                verification_code: "验证码",
                please_code: "请输入验证码",
                please_code_sure: "请输入正确的验证码格式",
                get_again: "重新获取",
                get_code: "获取验证码",
                send_code: "已发送验证码",
                failed_send_code: "验证码发送失败",
                register_now: "立即注册",
                please_area_code: "请先选择区号",
                please_sure_email: "请输入正确的邮箱号",
                login_success: "登录成功",
                login_timeout: "登录超时，请重新登陆",
                login_ing: "当前已登录，请退出登录之后再操作！",
                please_install_wallet: "请安装MetaMask钱包",
                please_login_wallet: "请检查您的MetaMask钱包是否登录!",
                not_open: "功能暂未开放",
                announcement: "公告",
                determine: "确定",
                user: "用户",
                countries: "国家",
                volume: "季度交易量",
                illegal_connection: "非法链接,请重新获取链接",
                network_download: "当前网络不稳定，请更换网络后下载",
                activities_begin: "精彩活动开启",
                scene_map: "全新场景地图，去看看吧",
                features: "新的特色",
                operator_exception: "运营商信息异常，请联系管理员",
                channel_exception: "渠道ID异常，请联系管理员",
                record_present: "暂无交易记录",
                contact_administrator: "链接错误,请联系管理员",
                download_contact_administrator: "无法下载,请联系管理员",
                cultivation: "养殖",
                cultivation_text: "饲养可爱的幼崽，来生产丰富的畜牧产品。在市场售卖，赚取大量财产，打造你的庄园帝国",
                building: "建筑",
                building_text: "建造农田、牧场，升级小屋，并且不断升级来扩大庄园，解锁更多有趣的幼崽和种子。赶快加入我们吧！",
                cultivate: "培养",
                cultivate_text: "栽培农作物是一件非常重要的事情，农产品从种子中生长，收获的农产品不仅可以喂养动物，更可以在市场售卖换取巨额财富。",
                statue: "神像",
                statue_text: "劳动是一件非常光荣圣神的事情，在各种神像的庇佑下，庄园会日益壮大。升级神像，让我们的庄园快速发展吧！",
                family: "家族",
                family_text: "加入或者创建一个家族，和朋友们一起耕作养殖，在朋友中名列前茅，赚取千万佣金。",
                pasture: "牧场",
                pasture_text: "为动物们打造的舒适家园。只有在牧场里，动物们才会快乐的茁壮成长，生产大量优质的畜牧产品。",
                farm: "农场",
                farm_text: "种植各种农作物的地方，能供为农作物提供肥沃的土地，更高级的土地能够种植更高级的农作物。",
                animal: "动物",
                animal_text: "各种动物幼崽通过饲养成长，并且生产对应的畜牧产品，比如可爱的小牛长大后会生产甜美的牛奶。",
                plant: "植物",
                plant_text: "种植这些植物，精心照料他们，等到他们成熟，也就意味着丰收也将来临。",
                question1: "1.什么是蜜蜂庄园？",
                answer1: "蜜蜂世界是一款面向全球的元宇宙模拟经营庄园游戏。玩家可以打造自己的豪华庄园，不断升级，在市场赚取大量财富。也可以和好友一起组建团队，不断发展壮大，并且获得巨大财富。",
                question2: "2.如何加入蜜蜂庄园？",
                answer2: "要加入我们的蜜蜂庄园，您需要下载我们的游戏或者在我们的网页端进行游戏。",
                question3: "3.如何升级我的农场小屋？",
                answer3: "收集各种农产品和畜牧产品就可以获得农场小屋，当经验满足条件就可以升级啦！",
                question4: "4.什么是异常状态？",
                answer4: "当植物缺水、长杂草、生害虫以及动物饥饿、受到蚊虫骚扰等。",
                question5: "5.我种的植物缺水了怎么办？",
                answer5: "点击植物，在屏幕下方选择水桶进行浇水就可以啦。当植物处于异常状态，将会停止生长，所以为了保证收益需要尽快处理。",
                question6: "6.什么是贝壳币、宝石？",
                answer6: "贝壳币是游戏中非常重要的货币，能够购买珍贵的幼崽和种子，并且赚取的贝壳币可以获得大量的USDT。宝石是游戏中的一种通用货币，可以通过贝壳币兑换获得，是升级土地的重要货币。",
                question7: "7.什么是市场？",
                answer7: "市场是在特定时间开盘的，给玩家提供自由交易的场所。玩家可以通过在市场售卖农牧产品赚取大量贝壳币，也可以使用贝壳币在市场购买心仪的商品。",
                question8: "8.佣金是什么？",
                answer8: "佣金是您的团队业绩和对应的返佣系数相乘然后减去所有的直属团队业绩乘以对应返佣系数的积的一个差值。",
                question9: "9.家族是什么？如何加入好友的家族？",
                answer9: "家族是众多玩家一起游戏团结合作的一个团体，能够互相拜访庄园，帮助清除动植物的异常状态等等。可以通过好友的邀请加入好友的家族。"
            }
              , Be = {
                login: "Sign In",
                outlogin: "Sign Out",
                home: "Homepage",
                game: "ABOUT US",
                game_about: "About Game",
                game_features: "New Gamemodes",
                question: "FAQ",
                market: "Market",
                about_game: "About Game",
                about_game_title: "Game",
                common_problem: "Common Question",
                common_problem_title: "Question",
                introduce: "Introduction",
                hall: "Lobby",
                content_title: "BeeFarm is a blockchain-based farming simulator.",
                content_text: "The player can use the in-game market to trade freely. Up until now, there are more than 1 million users registered in BeeFarm",
                content_introduce: "BeeFarm enables a “SOCIAL NETWORK GAME EXPERIENCE” profit model",
                login_game: "Play Now",
                dowm_game: "Download App",
                sell: "Sell",
                days: "Day",
                months: "Month",
                years: "Year",
                market_tips: "Opening Time: 9:00 - 0:00 The Buy Price will be generated daily when the market opens",
                today_price: "Selling Price",
                selling_price: "Selling Price Curve",
                greate_ffree_account: "Create Account",
                all_visitors: "Total Visitors",
                all_withdrawal: "Total Withdrawal",
                quarterly_new_users: "Season New Users",
                gem: "Gem",
                shell_coin: "Shell",
                price_sold: "sold at the price of",
                deal_order: "%s sold %s%s at the price of %s[%i], getting %s of the value %s [%i].",
                order_to: "sold",
                part: "at the price of",
                der: "getting",
                of_value: "of the value",
                get_value: "Get value",
                value: "Value",
                sell: "Shipping",
                buy: "Receipt",
                each: "Per Serving",
                free_market: "Free trade at the market",
                store_buy: "Buying Seeds or Livestock from the store",
                fram_pasture: "Planting and breeding at the farm and ranch",
                free_product: "The harvested product can be freely traded at the market",
                manor: "BUILD YOUR FARM NOW",
                trade: "TRADE NOW",
                download_family: "Download the mobile version to trade and play with your friends now",
                superior: "Back",
                phone: "Mobile",
                email: "Email",
                area_code: "Area Code",
                please_phone: "Enter Mob. Num",
                please_phone_sure: "Please enter a correct mobile number",
                verification_code: "Verification Code",
                please_code: "Please enter the verification code",
                please_code_sure: "Please enter a correct verification code",
                get_again: "Resend",
                get_code: "Code",
                send_code: "Sent",
                failed_send_code: "Failed to send",
                register_now: "Register Now",
                please_area_code: "Please select an area code",
                please_sure_email: "Please enter the correct email number",
                login_success: "Signed in successfully",
                login_timeout: "Sign-in timed out, please sign in again",
                login_ing: "You have already signed in previously, please sign out and try again!",
                please_install_wallet: "Please install MetaMask",
                please_login_wallet: "Please check if you have signed in to MetaMask!",
                not_open: "Function is not available yet",
                announcement: "Notification",
                determine: "Confirm",
                user: "User",
                countries: "Country",
                volume: "Season Trading Volume",
                illegal_connection: "Invalid link, please obtain the link again",
                network_download: "Your current network is unstable, please try downloading again with a different network",
                activities_begin: "New Events available",
                scene_map: "Check out the new scenes and maps now",
                features: "New Features",
                operator_exception: "Operator info error, please contact the admin",
                channel_exception: "Channel ID error, please contact the admin",
                record_present: "No trade record yet",
                contact_administrator: "Link error, please contact the admin",
                download_contact_administrator: "Unable to download, please contact the admin",
                cultivation: "Breed",
                cultivation_text: "Breed some cute livestock to make some livestock product. Sell a lot of wealth at the market to build your own manor empire",
                building: "Building",
                building_text: "Construct a farm and upgrade your hut at the ranch to continue upgrading and expanding manor, while unlocking more interesting livestock and seeds! Join Us Now!",
                cultivate: "Cultivate",
                cultivate_text: "Farming crops is a very important work. The crops will grow from the seeds. The harvested crops can be used to feed livestock and even be traded at the market for a great sum of wealth.",
                statue: "Statue",
                statue_text: "Working is a very sacred and glorious matter. Under the blessing of the statue, the manor will grow even stronger. Upgrade the statue to let our manor grow even faster!",
                family: "Family",
                family_text: "Join or create a family and farm with your friends to earn millions of commissions, reaching the top tier in the leaderboard.",
                pasture: "Pasture",
                pasture_text: "A comfortable home for animals. Only in pastures do animals thrive happily and produce large quantities of high-quality livestock products.",
                farm: "Farm",
                farm_text: "Where a variety of crops are grown, fertile land is available for crops, and more advanced land can be used to grow more advanced crops.",
                animal: "Livestock",
                animal_text: "The cute livestock cubs and can grow through feeding and they will produce equivalent livestock product. For example, the cute calf can produce sweet and juicy milk when they are mature.",
                plant: "Crops",
                plant_text: "Plant these crops and take good care of them. When they are ripe, it means a good harvest has come.",
                question1: "1. What is BeeFarm?",
                answer1: "BeeFarm is a metaverse farming manor simulator that is open to the players across the globe. The player can create their own beautiful manor and keep upgrading them to earn a great profit at the market. They can also team up with their friends to build up new team to continuously expand and earn wealth.",
                question2: "2. How to join BeeFarm?",
                answer2: "To join BeeFarm, just simply download our game or play the game from the webpage.",
                question3: "3. How to upgrade my farm cottage?",
                answer3: "You can collect various crops and livestock products to earn experiences. When the cottage has accumulated enough experiences, you will meet the conditions to upgrade!",
                question4: "4. What is a Status Effect?",
                answer4: "Status effect is a problematic condition when the crops are suffering from water shortage, weeds, bugs or when the livestock is suffering from hunger or the harassment of pest.",
                question5: "5. What should I do if my plant needs more water?",
                answer5: "Tap on the water bucket at the bottom of the screen to water the crops. When in a status effect, the crops will stop growing. So you must take care of them as soon as possible to maximize your profit.",
                question6: "6. What are the shells and gems?",
                answer6: "The shells are a type of very important currency in the game, which can be used to purchase precious livestock and seeds. The shells you have earned can be exchanged into a great deal of USDT. Gems are common currency in the game that can be exchanged from shells. It is a very important currency used to upgrade the land.",
                question7: "7. What is a market?",
                answer7: "The market will be open at a specific time for the players to trade freely. The player can sell the crops and livestock product at the market for shells and spend the shells to buy the items they want.",
                question8: "8. The commission is a difference value you get when you deduct the sum of all associate teams performance multiplied by equivalent rebate coefficient from the sum of your team performance multiplied by equivalent rebate coefficient.?",
                answer8: "Commission is the difference between your team's performance and the corresponding rebate coefficient multiplied by the product of all direct team performance multiplied by the corresponding rebate coefficient.",
                question9: "9.  What is a family? How to join my friend's family?",
                answer9: "The family is a community for many players to work together. The family members can visit each other's farm and help them deal with the status effect at their farm. You can join your friend's family through invitation."
            }
              , Le = {
                login: "Log in",
                outlogin: "Log out",
                home: "Beranda",
                game: "Tentang Game",
                game_about: "Tentang Game",
                game_features: "Permainan Baru",
                question: "Masalah Umum",
                market: "Pasar",
                introduce: "Introduksi",
                hall: "Lobi",
                content_title: "BeeFarm adalah sebuah game simulasi pertanian dengan teknologi blockchain",
                content_text: "Pemain bisa melakukan transaksi bebas di pasar yang sudah memiliki 1 Juta pengguna yang sudah mendaftar di BeeFarm",
                content_introduce: 'BeeFarm menciptakan mode monetisasi dari "Mencoba Komunitas Game"',
                login_game: "Log in Game",
                dowm_game: "Unduh aplikasi",
                sell: "Jual",
                days: "Hari",
                months: "Bulan",
                years: "Tahun",
                market_tips: "Waktu buka 09:00-24:00. Harga beli hari ini akan terbentuk saat buka pasar di setiap hari",
                today_price: "Harga Jual",
                selling_price: "Grafik Harga Jual",
                greate_ffree_account: "Membuat Akun",
                all_visitors: "Total Pengunjung",
                all_withdrawal: "Total Tarik Tunai",
                quarterly_new_users: "Pengguna Baru Triwulanan",
                gem: "Permata",
                shell_coin: "Cangkang",
                price_sold: "的价格出售了",
                order_to: "以",
                part: "份",
                der: "的",
                get_value: "获得价值",
                value: "价值",
                sell: "Jual",
                buy: "收货",
                each: "每份",
                free_market: "Bisa melakukan transaksi bebas di pasar",
                store_buy: "Beli benih atau anak hewan di toko",
                fram_pasture: "Bercocok tanam atau beternak di ladang atau lahan ternak",
                free_product: "Produk yang diperoleh bisa transaksi secara bebas di pasar",
                manor: "Mulailah kehidupan perkebunan Anda",
                trade: "Transaksi",
                download_family: "Unduh versi mobile dan mainkan transaksi bebas dengan anggota keluarga",
                superior: "Kembali",
                phone: "Ponsel",
                email: "Kotak surat",
                area_code: "Pilih kode pos",
                please_phone: "Silakan masukkan nomor ponsel",
                please_phone_sure: "Silakan masukkan format nomor ponsel yang benar",
                verification_code: "Kode Verifikasi",
                please_code: "Silakan masukkan kode verifikasi",
                please_code_sure: "Silakan masukkan format kode verifikasi yang valid",
                get_again: "Kirim Ulang",
                get_code: "Code",
                send_code: "Sudah kirim kode verifikasi",
                failed_send_code: "Gagal kirim kode verifikasi",
                register_now: "Register Sekarang",
                please_area_code: "Silakan pilih kode pos",
                please_sure_email: "Silahkan masukkan nomor email yang benar",
                login_success: "Berhasil log in",
                login_timeout: "Log in melebihi waktu ditentukan. Silakan log in ulang",
                login_ing: "Sudah log in, silakan lakukan setelah log out!",
                please_install_wallet: "Silakan instal dompet MetaMask",
                please_login_wallet: "Silakan periksa apakah dompet MetaMask Anda sudah log in atau belum!",
                not_open: "Fitur belum tersedia",
                announcement: "Pengumuman",
                determine: "Konfirmasi",
                user: "Pengguna",
                countries: "Negara",
                volume: "Jumlah Transaksi Triwulanan",
                illegal_connection: "Tautan ilegal. Silakan dapatkan ulang tautan",
                network_download: "Jaringan internet tidak stabil. Silakan unduh setelah ganti jaringan",
                activities_begin: "Event seru tersedia",
                scene_map: "Coba lihat tempat dan peta baru",
                features: "Fitur baru",
                operator_exception: "Kesalahan info operator. Silakan hubungi admin",
                channel_exception: "Kesalahan channel ID. Silakan hubungi admin",
                record_present: "Tidak ada riwayat transaksi",
                contact_administrator: "Tautan eror. Silakan hubungi admin",
                download_contact_administrator: "Tidak bisa unduh. Silakan hubungi admin",
                cultivation: "Beternak",
                cultivation_text: "Memelihara anak hewan yang lucu untuk menghasilkan banyak produk hewan. Jual di pasar untuk menghasilkan banyak keuntungan, ciptakanlah kerajaan perkebunanmu",
                building: "Konstruksi",
                building_text: "Membangun ladang dan lahan ternak, upgrade rumah dan terus upgrade untuk memperluas perkebunan, membuka lebih banyak anak hewan dan benih yang menarik. Cepat bergabung dengan kami!",
                cultivate: "Bertanam",
                cultivate_text: "Menanam dan merawat tanaman adalah sebuah hal yang sangat penting, produk pertanian dari hasil panen tanaman bisa dijadikan sebagai pangan hewan dan juga bisa dijual di pasar untuk mendapat keuntungan besar.",
                statue: "Patung",
                statue_text: "Bekerja adalah sebuah hal yang sangat mulia, perkebunan akan menjadi semakin besar dalam perlindungan berbagai patung. Upgrade patung agar perkebunan kita bisa berkembang dengan cepat!",
                family: "Keluarga",
                family_text: "Bergabung atau membuat sebuah keluarga, bercocok tanam dan beternak bersama teman-teman, dapatkan banyak komisi jika bisa berada di peringkat depan.",
                pasture: "Lahan Ternak",
                pasture_text: "Membangun rumah yang nyaman untuk para hewan. Para hewan merasa senang dan tumbuh dengan kuat di lahan ternak untuk menghasilkan banyak produk hewan berkualitas tinggi.",
                farm: "Ladang",
                farm_text: "Tempat untuk menanam berbagai tanaman, menyediakan lahan subur untuk tanaman, tanah level tinggi bisa menghasilkan produk pertanian yang lebih bagus.",
                animal: "Hewan",
                animal_text: "Berbagai anak hewan tumbuh besar setelah dipelihara dan menghasikan produk hewan relevan, contohnya sapi kecil yang lucu ini akan menghasilkan susu manis setelah tumbuh dewasa.",
                plant: "Tanaman",
                plant_text: "Menanam tanaman ini dan merawat mereka dengan baik. Setelah mamtang, itu artinya sudah bisa panen.",
                question1: "1. Apa itu BeeFarm?",
                answer1: "BeeFarm adalah sebuah game simulasi mengelola perkebunan yang bersifat metamesta global. Pemain bisa menciptakan perkebunan mewah milik sendiri, terus upgrade dan dapatkan banyak keuntungan di pasar. Selain itu, juga bisa membentuk tim dengan teman untuk mengembangkannya dan mendapat banyak keuntungan.",
                question2: "2.Bagaimana cara bergabung dengan BeeFarm?",
                answer2: "Jika ingin bergabung dengan BeeFarm, Anda perlu unduh game kami atau mainkan game di halaman web kami.",
                question3: "3. Bagaimana cara upgrade rumahku?",
                answer3: "Koleksi berbagai produk hewan dan produk pertanian agar bisa memenuhi persyaratan upgrade rumah!",
                question4: "4.Apa itu status abnormal?",
                answer4: "Saat tanaman kekurangan air, tumbuh gulma, hama, hewan kelaparan, diganggu nyamuk dan lainnya",
                question5: "5.Bagaimana jika tanaman kekurangan air?",
                answer5: "Tekan tanaman dan pilih ember di bawah untuk menyiram. Saat tanaman muncul status abnormal akan berhenti tumbuh, pastikan diurus untuk memastikan profit.",
                question6: "6.Apa itu Cangkang dan Permata?",
                answer6: "Cangkang adalah mata uang yang sangat penting di dalam game, bisa membeli anak hewan dan benih yang berharga, Cangkang yang diperoleh bisa mendapat banyak USDT. Permata adalah mata uang umum di dalam game, bisa mendapatkannya dengan cara menukar Cangkang. Permata merupakan mata uang penting untuk upgrade tanah.",
                question7: "7. Apa itu pasar?",
                answer7: "Pasar adalah tempat transaksi bebas yang dibuka pada waktu tertentu untuk pemain. Pemain bisa mendapatkan banyak Cangkang dengan cara menjual produk di pasar, juga bisa menggunakan Cangkang untuk membeli produk favorit di pasar.",
                question8: "8.Apa itu komisi?",
                answer8: "Komisi adalah selisih nilai prestasi tim Anda dikalikan dengan koefisien komisi relevan lalu mengurangi semua prestasi tim langsung dan dikalikan dengan koefisien komisi relevan.",
                question9: "9. Apa itu keluarga? Bagaimana cara bergabung ke keluarga baik?",
                answer9: "Keluarga adalah sebuah tim yang terbentuk dari hasil kerja sama para pemain, bisa saling mengunjungi perkebunan untuk menghilangkan status abnormal tanaman dan lainnya. Bisa bergabung ke keluarga teman dengan cara diundang oleh teman."
            }
              , Ue = {
                login: "Iniciar Sesión",
                outlogin: "Cerrar Sesión",
                home: "Página Inicial",
                game: "Sobre el Juego",
                game_about: "Sobre el Juego",
                game_features: "Nuevo Modo de Juego",
                question: "FAQ",
                market: "Mercado",
                about_game: "About Game",
                about_game_title: "Game",
                common_problem: "Common Question",
                common_problem_title: "Question",
                introduce: "Introducción",
                hall: "Lobby",
                content_title: "BeeFarm es un simulador agrícola basado en blockchain.",
                content_text: "El jugador puede usar el mercado en línea para negociar libremente. Hasta ahora, hay más de 1 millón de usuarios registrados en BeeFarm",
                content_introduce: "BeeFarm permite un modelo de ganancias de “EXPERIENCIA DE JUEGO DE RED SOCIAL”",
                login_game: "Juega Ahora",
                dowm_game: "Bajar Aplicación",
                sell: "Vender",
                days: "Día",
                months: "Mes",
                years: "Año",
                market_tips: "Hora de Apertura: 9:00-24:00 El Precio de Compra será generado diariamente cuando el mercado se abre",
                today_price: "Precio de Venta",
                selling_price: "Curva de Precio de Venta",
                greate_ffree_account: "Crear Cuenta",
                all_visitors: "Visitantes Totales",
                all_withdrawal: "Monto de Retirada Total",
                quarterly_new_users: "Nuevos Usuarios de Temporada",
                gem: "Joya",
                shell_coin: "Concha",
                price_sold: "vendió para a un valor ",
                deal_order: "%s sold %s%s at the price of %s[%i], getting %s of the value %s [%i].",
                order_to: "con",
                part: "pedido",
                der: "de",
                of_value: "of the value",
                get_value: "Valor Obtenido",
                value: "Valor",
                sell: "Vender",
                buy: "Adquirir",
                each: "Cada Pedido",
                free_market: "Negociación libre en el mercado",
                store_buy: "Comprando Semillas o Ganado de la tienda",
                fram_pasture: "Plantando y criando en la hacienda y rancho",
                free_product: "El producto cosechado puede ser libremente negociado en el mercado",
                manor: "CONSTRUYE TU HACIENDA AHORA",
                trade: "NEGOCIA AHORA",
                download_family: "Descarga la aplicación móvil para negociar y jugar con tus amigos ahora",
                superior: "Regresar",
                phone: "Móvil",
                email: "Dirección",
                area_code: "Código de Área",
                please_phone: "Ingresar Tel. Número",
                please_phone_sure: "Por favor ingresa un número de teléfono correcto",
                verification_code: "Código de Verificación",
                please_code: "Por favor ingresa el código de verificación",
                please_code_sure: "Por favor ingresa un código de verificación correcto",
                get_again: "Reenviar",
                get_code: "Code",
                send_code: "Enviado",
                failed_send_code: "Falla al enviar",
                register_now: "Registrar Ahora",
                please_area_code: "Por favor selecciona un código de área",
                please_sure_email: "Por favor, introduzca un número de correo electrónico correcto",
                login_success: "Sesión iniciada con éxito",
                login_timeout: "Tiempo de sesión expirado, por favor inicia sesión otra vez",
                login_ing: "Ya has iniciado sesión antes, ¡por favor cierra la sesión e intenta nuevamente!",
                please_install_wallet: "Por favor descarga MetaMask",
                please_login_wallet: "Por favor verifica si has iniciado sesión en MetaMask!",
                not_open: "Función todavía no disponible",
                announcement: "Notificación",
                determine: "Confirmar",
                user: "Usuario",
                countries: "País",
                volume: "Volumen de Negociación de Temporada",
                illegal_connection: "Enlace inválido, por favor obtén el enlace otra vez",
                network_download: "Tu red actual es instable, por favor intenta descargar otra vez en una red diferente",
                activities_begin: "Nuevos Eventos disponibles",
                scene_map: "Verifica las nuevas escenas y mapas ahora",
                features: "Nuevas Funciones",
                operator_exception: "Error de información de operador, por favor contacta el administrador",
                channel_exception: "Error de ID de canal, por favor contacta el administrador",
                record_present: "No hay registro de negociación todavía",
                contact_administrator: "Error de enlace, por favor contacta el administrador",
                download_contact_administrator: "No es posible descargar, por favor contacta el administrador",
                cultivation: "Criar",
                cultivation_text: "Cría unos lindos ganados para hacer unos productos de ganado. Vende un montón de riqueza en el mercado para construir tu mismo imperio de mansión",
                building: "Construyendo",
                building_text: "Construye una hacienda y mejora tu cabaña en el rancho para continuar mejorando y expandiendo la mansión, mientras desbloqueas más ganado y semillas interesantes! ¡Únete a nosotros ahora!",
                cultivate: "Cultivar",
                cultivate_text: "La agricultura de cultivos es un trabajo muy importante. Los cultivos van a crecer de las semillas. Los cultivos cosechados pueden ser usados para alimentar ganado y hasta ser negociados por una gran suma de dinero.",
                statue: "Estatua",
                statue_text: "Trabajar es un asunto muy sagrado y serio. Bajo la bendición de la estatua, la mansión va a crecer aún más fuerte. ¡Mejora la estatua para hacer crecer nuestra mansión aún más rápido!",
                family: "Familia",
                family_text: "Únete o crea una familia y cultiva con tus amigos para ganar millones de comisiones, alcanzando las gradas del topo de la tabla de clasificación.",
                pasture: "Rancho",
                pasture_text: "Crea una casa confortable para el ganado. El ganado solamente puede crecer libre y feliz cuando vive en el rancho, produciendo un grande monto de producto de ganado.",
                farm: "Hacienda",
                farm_text: "El lugar dónde plantas cualquier semilla. Puede proveer suelo fértil para que crezcan los cultivos. La tierra de cultivo de alto nivel hasta permite que plantes unos cultivos más avanzados.",
                animal: "Ganado",
                animal_text: "Los lindos cachorros de ganado pueden crecer a través de la alimentación y producirán productos de ganado correspondientes. Por ejemplo, el lindo becerro puede producir leche dulce y jugosa cuando sea maduro.",
                plant: "Cultivos",
                plant_text: "Planta estos cultivos y cuídalos bien. Cuando estén maduros, significa que una buena cosecha va a venir.",
                question1: "1. Qué es BeeFarm?",
                answer1: "BeeFarm es un simulador de mansión de agricultura del metaverso que es abierto a los jugadores de todo el mundo. El jugador puede crear su misma hermosa mansión y seguir mejorándola para obtener una buena ganancia en el mercado. También pueden hacer equipo con sus amigos para construir un grupo para expandirse continuamente y ganar riqueza.",
                question2: "2. Cómo unirse al BeeFarm?",
                answer2: "Para unirte al BeeFarm, simplemente baja nuestro juego o juega el juego desde la página principal.",
                question3: "3. Cómo mejorar mi cabaña de hacienda?",
                answer3: "Puedes recoger varios productos de cultivo y ganado para ganar experiencias. ¡Cuando la cabaña haya acumulado suficientes experiencias, cumplirás los requerimientos para mejorarla!",
                question4: "4. Qué es un Efecto de Estatus?",
                answer4: "Efectos de Estatus son condiciones problemáticas cuando los cultivos sufren falta de agua, malas hierbas, insectos o cuando el ganado sufre hambre o el acoso de plagas.",
                question5: "5. Qué debo hacer si mi planta necesita más agua?",
                answer5: "Toca el balde de agua en la parte inferior de la pantalla para regar los cultivos. Cuando estén bajo un efecto de estatus, los cultivos dejarán de crecer. Entonces debes cuidarlos lo más pronto posible para maximizar tu ganancia.",
                question6: "6. Qué son las conchas y joyas?",
                answer6: "Las conchas son un tipo de moneda muy importante en el juego, que pueden ser usadas para comprar ganado y semillas preciosas. Las conchas que adquiriste pueden ser intercambiadas por unos buenos USDT. Joyas son una fuente común en el juego que puede ser intercambiada por las conchas. Es una moneda muy importante usada para mejorar la tierra.",
                question7: "7. Qué es un mercado?",
                answer7: "El mercado abre a una hora específica para que los jugadores negocien libremente. El jugador puede vender el producto de cultivos y ganado en el mercado por conchas y gastar las conchas para comprar los artículos que quiera.",
                question8: "8. Qué es la comisión?",
                answer8: "La comisión es la diferencia que recibes cuando deduces la suma del desempeño de todos los equipos asociados multiplicada por el coeficiente de descuento equivalente de la suma del desempeño de tu equipo multiplicada por el coeficiente de descuento equivalente.",
                question9: "9. Qué es una familia? ¿Cómo puedo unirme a la familia de mi amigo?",
                answer9: "La familia es una comunidad de varios jugadores que trabajan juntos. Los miembros de la familia pueden visitar las haciendas de los otros miembros y ayudarlos a lidiar con los efectos de estatus en sus haciendas. Puedes unirte a la familia de tu amigo a través de una invitación."
            }
              , Te = t(1877)
              , qe = t(9903)
              , Oe = t(4566)
              , Ge = t(5571);
            i["default"].use(ze.Z);
            const Me = {
                zh_cn: Object.assign(Te["default"], De),
                en_us: Object.assign(qe.Z, Be),
                in_hi: Object.assign(Oe.Z, Le),
                es_es: Object.assign(Ge.Z, Ue)
            }
              , Ae = new ze.Z({
                locale: sessionStorage.getItem("local"),
                messages: Me,
                silentTranslationWarn: !0
            });
            i["default"].locale = ()=>{}
            ;
            var Ve = Ae;
            b().Dialog.props.lockScroll["default"] = !1,
            i["default"].prototype.$echarts = Y,
            i["default"].config.productionTip = !1,
            i["default"].use(Q.ZP),
            i["default"].use($e),
            i["default"].config.productionTip = !1,
            i["default"].prototype.Web3 = r(),
            i["default"].use(b(), {
                i18n: (e,a)=>Ve.t(e, a)
            }),
            i["default"].prototype.$http = p(),
            new i["default"]({
                el: "#app",
                router: Se,
                Base64: $e,
                i18n: Ve,
                echarts: Y,
                render: e=>e(J)
            })
        },
        636: function(e, a, t) {
            var i = t(3266);
            i.__esModule && (i = i.default),
            "string" === typeof i && (i = [[e.id, i, ""]]),
            i.locals && (e.exports = i.locals);
            var o = t(4402).Z;
            o("01871b2f", i, !0, {
                sourceMap: !1,
                shadowMode: !1
            })
        },
        9219: function(e, a, t) {
            var i = t(1156);
            i.__esModule && (i = i.default),
            "string" === typeof i && (i = [[e.id, i, ""]]),
            i.locals && (e.exports = i.locals);
            var o = t(4402).Z;
            o("18b4c297", i, !0, {
                sourceMap: !1,
                shadowMode: !1
            })
        },
        7421: function(e, a, t) {
            var i = t(2537);
            i.__esModule && (i = i.default),
            "string" === typeof i && (i = [[e.id, i, ""]]),
            i.locals && (e.exports = i.locals);
            var o = t(4402).Z;
            o("916fc6ca", i, !0, {
                sourceMap: !1,
                shadowMode: !1
            })
        },
        348: function(e, a, t) {
            var i = t(5441);
            i.__esModule && (i = i.default),
            "string" === typeof i && (i = [[e.id, i, ""]]),
            i.locals && (e.exports = i.locals);
            var o = t(4402).Z;
            o("4a00bc47", i, !0, {
                sourceMap: !1,
                shadowMode: !1
            })
        },
        8747: function(e, a, t) {
            var i = t(4169);
            i.__esModule && (i = i.default),
            "string" === typeof i && (i = [[e.id, i, ""]]),
            i.locals && (e.exports = i.locals);
            var o = t(4402).Z;
            o("082ae5bd", i, !0, {
                sourceMap: !1,
                shadowMode: !1
            })
        },
        152: function(e, a, t) {
            var i = t(9029);
            i.__esModule && (i = i.default),
            "string" === typeof i && (i = [[e.id, i, ""]]),
            i.locals && (e.exports = i.locals);
            var o = t(4402).Z;
            o("8e3d6f26", i, !0, {
                sourceMap: !1,
                shadowMode: !1
            })
        },
        9835: function(e, a, t) {
            var i = t(5799);
            i.__esModule && (i = i.default),
            "string" === typeof i && (i = [[e.id, i, ""]]),
            i.locals && (e.exports = i.locals);
            var o = t(4402).Z;
            o("590ac30c", i, !0, {
                sourceMap: !1,
                shadowMode: !1
            })
        },
        6969: function(e, a, t) {
            var i = t(9459);
            i.__esModule && (i = i.default),
            "string" === typeof i && (i = [[e.id, i, ""]]),
            i.locals && (e.exports = i.locals);
            var o = t(4402).Z;
            o("3b3ef627", i, !0, {
                sourceMap: !1,
                shadowMode: !1
            })
        },
        6270: function(e) {
            "use strict";
            e.exports = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAwAAAAMCAIAAADZF8uwAAAAGUlEQVQYV2M4gwH+YwCGIasIUwhT25BVBADtzYNYrHvv4gAAAABJRU5ErkJggg=="
        }
    }
      , a = {};
    function t(i) {
        var o = a[i];
        if (void 0 !== o)
            return o.exports;
        var n = a[i] = {
            id: i,
            exports: {}
        };
        return e[i].call(n.exports, n, n.exports, t),
        n.exports
    }
    t.m = e,
    function() {
        t.amdD = function() {
            throw new Error("define cannot be used indirect")
        }
    }(),
    function() {
        t.amdO = {}
    }(),
    function() {
        var e = [];
        t.O = function(a, i, o, n) {
            if (!i) {
                var s = 1 / 0;
                for (u = 0; u < e.length; u++) {
                    i = e[u][0],
                    o = e[u][1],
                    n = e[u][2];
                    for (var r = !0, l = 0; l < i.length; l++)
                        (!1 & n || s >= n) && Object.keys(t.O).every((function(e) {
                            return t.O[e](i[l])
                        }
                        )) ? i.splice(l--, 1) : (r = !1,
                        n < s && (s = n));
                    if (r) {
                        e.splice(u--, 1);
                        var d = o();
                        void 0 !== d && (a = d)
                    }
                }
                return a
            }
            n = n || 0;
            for (var u = e.length; u > 0 && e[u - 1][2] > n; u--)
                e[u] = e[u - 1];
            e[u] = [i, o, n]
        }
    }(),
    function() {
        t.n = function(e) {
            var a = e && e.__esModule ? function() {
                return e["default"]
            }
            : function() {
                return e
            }
            ;
            return t.d(a, {
                a: a
            }),
            a
        }
    }(),
    function() {
        t.d = function(e, a) {
            for (var i in a)
                t.o(a, i) && !t.o(e, i) && Object.defineProperty(e, i, {
                    enumerable: !0,
                    get: a[i]
                })
        }
    }(),
    function() {
        t.g = function() {
            if ("object" === typeof globalThis)
                return globalThis;
            try {
                return this || new Function("return this")()
            } catch (e) {
                if ("object" === typeof window)
                    return window
            }
        }()
    }(),
    function() {
        t.o = function(e, a) {
            return Object.prototype.hasOwnProperty.call(e, a)
        }
    }(),
    function() {
        t.r = function(e) {
            "undefined" !== typeof Symbol && Symbol.toStringTag && Object.defineProperty(e, Symbol.toStringTag, {
                value: "Module"
            }),
            Object.defineProperty(e, "__esModule", {
                value: !0
            })
        }
    }(),
    function() {
        t.p = "/"
    }(),
    function() {
        t.b = document.baseURI || self.location.href;
        var e = {
            143: 0
        };
        t.O.j = function(a) {
            return 0 === e[a]
        }
        ;
        var a = function(a, i) {
            var o, n, s = i[0], r = i[1], l = i[2], d = 0;
            if (s.some((function(a) {
                return 0 !== e[a]
            }
            ))) {
                for (o in r)
                    t.o(r, o) && (t.m[o] = r[o]);
                if (l)
                    var u = l(t)
            }
            for (a && a(i); d < s.length; d++)
                n = s[d],
                t.o(e, n) && e[n] && e[n][0](),
                e[n] = 0;
            return t.O(u)
        }
          , i = self["webpackChunkfarm"] = self["webpackChunkfarm"] || [];
        i.forEach(a.bind(null, 0)),
        i.push = a.bind(null, i.push.bind(i))
    }();
    var i = t.O(void 0, [998], (function() {
        return t(8537)
    }
    ));
    i = t.O(i)
}
)();
